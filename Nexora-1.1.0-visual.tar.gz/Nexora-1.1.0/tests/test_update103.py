"""Offline routing/transport tests. Fixture prose is NOT a real model quality evaluation."""
import asyncio
import copy
import io
import json
import unittest
from unittest.mock import AsyncMock, patch
from test_nexora import n, BotTests, Network, message, CID, UID, BOT, DATA, PNG


class IntentNetwork(Network):
    def __init__(self):
        super().__init__()
        self.route=n.intent_plan(['image_generation'],'Кот на обычном столе',confidence=.96)
        self.caption_error=None
        self.caption='Рада, что всё нормально. Вот яблоко для конкурса.'
        self.image_text='Вот яблоко на столе.'
        self.image_response=None
    async def call(self,url,data=None,key='',timeout=65):
        if url.endswith('/chat/completions'):
            system=data['messages'][0]['content']
            if system==n.INTENT_RULES:
                self.calls.append((url,data,key))
                return {'choices':[{'message':{'content':json.dumps({'answer':'','memories':[],'route':self.route})}}], 'usage':{'cost':.0001}}
            if n.CAPTION_RULES in system:
                self.calls.append((url,data,key))
                if self.caption_error:raise self.caption_error
                return {'choices':[{'message':{'content':json.dumps({'answer':self.caption,'memories':[]})}}], 'usage':{'cost':.0001}}
            if data.get('modalities'):
                result=await super().call(url,data,key,timeout)
                if self.image_response is not None:return copy.deepcopy(self.image_response)
                result['choices'][0]['message']['content']=self.image_text
                return result
        return await super().call(url,data,key,timeout)
    def images(self):return [p for p in self.paid() if p.get('modalities')]
    def routes(self):return [p for p in self.paid() if p['messages'][0]['content']==n.INTENT_RULES]
    def captions(self):return [p for p in self.paid() if n.CAPTION_RULES in p['messages'][0]['content']]


class MultiIntentTests(unittest.IsolatedAsyncioTestCase):
    fixture_setup=BotTests.setUp
    def setUp(self):
        self.fixture_setup()
        self.net=IntentNetwork();self.app=n.Nexora(self.db,self.net,self.app.token,self.app.brain.key)
        self.app.me,self.app.username=BOT,'NexoraTestBot'
    tearDown=BotTests.tearDown
    update=BotTests.update

    async def visual(self,text,mid=1,reply=None,photo=None):
        with patch.object(n,'send_image',new_callable=AsyncMock,return_value=message('',mid=200,uid=BOT,photo='created')) as send,patch.object(n,'download_photo',new_callable=AsyncMock,return_value=DATA) as down:
            await self.update(message(text,mid=mid,reply=reply,photo=photo),mid)
        return send,down

    async def test_plain_conversation_no_classifier_or_image(self):
        await self.update(message('@NexoraTestBot Как твои дела?'))
        self.assertEqual(len(self.net.paid()),1);self.assertFalse(self.net.routes());self.assertFalse(self.net.images())
        self.assertEqual(self.net.sends()[-1]['text'],'4.')

    async def test_all_six_positive_examples_locally_visual(self):
        examples=('Нарисуй яблоко','Можешь сделать картинку яблока?','Мне нужна фотография яблока на столе','Сгенерируй что-нибудь','Привет, как дела? И сделай, пожалуйста, картинку кота','Я нормально, кстати, можешь нарисовать дом?')
        for i,text in enumerate(examples,1):
            with self.subTest(text=text):
                # Independent input scenarios, not six images against one daily budget.
                self.db.c.execute('DELETE FROM usage');self.db.c.execute('DELETE FROM image_jobs')
                self.app.rate.clear()
                send,_=await self.visual('@NexoraTestBot '+text,mid=i)
                send.assert_awaited_once()
        self.assertEqual(len(self.net.images()),6);self.assertFalse(self.net.routes())

    async def test_all_negative_examples_no_generation(self):
        for i,text in enumerate(('Ты умеешь рисовать?','Почему ты не сделала картинку вчера?','Мне нравится эта картинка','Расскажи, как работает генерация изображений'),1):
            self.app.rate.clear();send,_=await self.visual('@NexoraTestBot '+text,mid=i)
            send.assert_not_awaited()
        self.assertFalse(self.net.images());self.assertFalse(self.net.routes())

    async def test_indirect_name_address_does_not_spend_on_gate(self):
        send,_=await self.visual('Нексора, мне нужна фотография яблока на столе')
        send.assert_awaited_once();self.assertEqual(len(self.net.paid()),1)

    async def test_multi_conversation_caption_one_telegram_result(self):
        text='Я в целом нормально. Слушай, можешь сделать картинку яблока на столе? Мне для конкурса.'
        send,_=await self.visual('@NexoraTestBot '+text)
        send.assert_awaited_once();self.assertFalse(self.net.sends());self.assertEqual(len(self.net.images()),1)
        self.assertEqual(send.await_args.kwargs['caption'],self.net.caption)
        ctx=json.loads(self.net.captions()[0]['messages'][1]['content'][0]['text'])
        self.assertEqual(ctx['question'],text);self.assertTrue(ctx['executed']['image_received'])
        visual=json.loads(self.net.images()[0]['messages'][1]['content'][0]['text'].split('\n')[0])
        self.assertIn('яблока на столе',visual['visual_task']);self.assertNotIn('нормально',visual['visual_task'])
        self.assertEqual(visual['original_request'],text)

    async def test_question_plus_image_answers_once(self):
        self.net.caption='4. Вот яблоко.'
        send,_=await self.visual('@NexoraTestBot Сколько будет 2+2? И нарисуй яблоко.')
        self.assertEqual(len(self.net.images()),1);self.assertEqual(len(self.net.captions()),1)
        self.assertEqual(send.await_args.kwargs['caption'],'4. Вот яблоко.');self.assertFalse(self.net.sends())

    async def test_attachment_edit_keeps_source_and_qualified_caption(self):
        send,down=await self.visual('@NexoraTestBot убери человека справа',photo='source')
        down.assert_awaited_once_with(self.app,'source')
        self.assertEqual(self.net.images()[0]['messages'][1]['content'][1]['image_url']['url'],DATA)
        self.assertIn('справа',send.await_args.kwargs['caption']);self.assertFalse(self.net.sends())

    async def test_edit_reply_and_followup_owned_chain(self):
        original=message('фото',mid=19,uid=UID,photo='original')
        send,down=await self.visual('@NexoraTestBot Замени фон на белый',reply=original)
        send.assert_awaited_once();down.assert_awaited_once_with(self.app,'original')
        self.app.rate.clear()
        send,down=await self.visual('Сделай ещё ярче',mid=3,reply=message('вариант',mid=200,uid=BOT,photo='created'))
        send.assert_awaited_once();down.assert_awaited_once_with(self.app,'created')
        self.assertEqual(len(self.net.images()),2)
        self.assertEqual(self.db.one('SELECT owner_id FROM dialogues WHERE message_id=200')['owner_id'],UID)

    async def test_conversation_plus_edit_stays_one_photo(self):
        self.net.caption='Хорошо. Вот вариант с новым фоном.'
        send,_=await self.visual('@NexoraTestBot Я нормально. Замени фон на белый.',photo='source')
        send.assert_awaited_once();self.assertFalse(self.net.sends());self.assertEqual(len(self.net.images()),1)
        self.assertEqual(send.await_args.kwargs['caption'],self.net.caption)

    async def test_analysis_plus_edit_attaches_both_images_to_caption_model(self):
        self.net.caption='На фото человек у окна. Вот вариант без человека.'
        send,_=await self.visual('@NexoraTestBot Опиши фотографию. И убери человека справа.',photo='source')
        send.assert_awaited_once();parts=self.net.captions()[0]['messages'][1]['content']
        self.assertEqual(len(parts),3);self.assertEqual(parts[1]['image_url']['url'],DATA)
        self.assertEqual(parts[2]['image_url']['url'],DATA)
        self.assertFalse(self.net.sends())

    async def test_analysis_only_uses_main_vision_no_generation(self):
        send,_=await self.visual('@NexoraTestBot Опиши фотографию',photo='source')
        send.assert_not_awaited();self.assertFalse(self.net.images())
        self.assertEqual(self.net.paid()[-1]['messages'][1]['content'][1]['image_url']['url'],DATA)

    async def test_unknown_colloquial_typo_routes_once_by_background_model(self):
        send,_=await self.visual('@NexoraTestBot Сбацай каритнку кота на столе')
        send.assert_awaited_once();self.assertEqual(len(self.net.routes()),1);self.assertEqual(len(self.net.images()),1)
        self.assertEqual(self.net.routes()[0]['model'],self.db.group(CID)[1]['background_model'])
        self.assertEqual(self.db.one("SELECT purpose FROM usage WHERE purpose='intent_route'")['purpose'],'intent_route')
        self.assertAlmostEqual(self.app.brain.costs(CID)['background'],.0001)

    async def test_invalid_classifier_results_fail_closed_not_paid_images(self):
        invalid=[None,[],{},n.intent_plan(['music'],'Кот'),n.intent_plan(['image_generation'],'Кот',confidence=True),n.intent_plan(['image_generation'],'Кот',confidence=float('nan')),n.intent_plan(['image_generation'],'Кот',confidence=.2),n.intent_plan(['image_edit'],'Убери человека'),n.intent_plan(['image_generation','image_edit'],'Кот'),n.intent_plan(['image_generation'],'Кот')|{'extra':'unexpected'}]
        for i,route in enumerate(invalid,1):
            self.app.rate.clear();self.net.route=route
            send,_=await self.visual('@NexoraTestBot Сбацай каритнку кота',mid=i)
            send.assert_not_awaited()
        self.assertFalse(self.net.images());self.assertEqual(len(self.net.routes()),len(invalid))

    async def test_duplicate_update_one_image_no_text_duplicate(self):
        with patch.object(n,'send_image',new_callable=AsyncMock,return_value=message('',mid=200,uid=BOT,photo='new')) as send:
            update={'update_id':7,'message':message('@NexoraTestBot Нарисуй яблоко')}
            await self.app.handle(update);await self.app.handle(update)
        send.assert_awaited_once();self.assertEqual(len(self.net.images()),1)

    async def test_paid_timeout_no_regeneration_and_stage_log_no_secrets(self):
        self.net.error=n.Fault('HTTP','timeout',operation='OpenRouter.chat')
        with self.assertLogs('nexora',level='WARNING') as logs:
            send,_=await self.visual('@NexoraTestBot Нарисуй яблоко')
        send.assert_not_awaited();self.assertEqual(len(self.net.images()),1)
        self.assertIn('stage=generation','\n'.join(logs.output));self.assertNotIn('Нарисуй','\n'.join(logs.output))
        self.assertGreater(float(self.db.one("SELECT cost FROM usage WHERE purpose='image'")['cost']),0)

    async def test_caption_failure_still_sends_existing_image_no_regeneration(self):
        self.net.caption_error=n.Fault('HTTP','timeout')
        send,_=await self.visual('@NexoraTestBot Я нормально. Нарисуй яблоко.')
        send.assert_awaited_once();self.assertEqual(len(self.net.images()),1);self.assertFalse(self.net.sends())
        self.assertIn('Текстовую часть',send.await_args.kwargs['caption'])

    async def test_upload_failure_does_not_call_generator_again(self):
        with patch.object(n,'send_image',new_callable=AsyncMock,side_effect=n.Fault('Telegram','timeout')) as send,self.assertLogs('nexora',level='WARNING') as logs:
            await self.update(message('@NexoraTestBot Нарисуй яблоко'))
        send.assert_awaited_once();self.assertEqual(len(self.net.images()),1)
        self.assertIn('stage=upload','\n'.join(logs.output))
        self.assertEqual(len(self.net.sends()),1,'only one failure notice')

    async def test_bad_optional_usage_not_discard_valid_image(self):
        self.net.image_response={'choices':[{'message':{'images':[{'image_url':DATA}], 'content':'Вот яблоко.'}}],'usage':{'cost':None,'prompt_tokens':None,'completion_tokens':'invalid'}}
        send,_=await self.visual('@NexoraTestBot Нарисуй яблоко')
        send.assert_awaited_once();self.assertEqual(self.db.one("SELECT estimated FROM usage WHERE purpose='image'")['estimated'],1)

    async def test_provider_error_body_not_mistaken_for_missing_image(self):
        self.net.image_response={'error':{'message':'sensitive response '+self.app.token,'code':503}}
        with self.assertLogs('nexora',level='WARNING') as logs:
            send,_=await self.visual('@NexoraTestBot Нарисуй яблоко')
        send.assert_not_awaited();self.assertIn('OpenRouter:503','\n'.join(logs.output))
        self.assertNotIn(self.app.token,'\n'.join(logs.output));self.assertEqual(len(self.net.images()),1)

    async def test_capability_question_has_actual_bot_instructions_no_image(self):
        await self.update(message('@NexoraTestBot Ты умеешь рисовать?'))
        self.assertFalse(self.net.images());payload=self.net.paid()[-1]
        self.assertIn(n.CAPABILITY_RULES,payload['messages'][0]['content'])
        self.assertNotIn('executed',json.loads(payload['messages'][1]['content']))
        # Proves instructions/delivery, not a semantic guarantee for real weak LLMs.

    async def test_schedule_edit_not_photo_edit_when_prior_image_cached(self):
        self.db.c.execute('INSERT INTO nexora_images VALUES(?,?,?,?,?,?)',(CID,UID,20,'previous',n.time.time(),n.time.time()+7200))
        send,down=await self.visual('@NexoraTestBot Измени расписание на завтра')
        send.assert_not_awaited();down.assert_not_awaited();self.assertFalse(self.net.images())

    async def test_classifier_never_imports_pending_memory_or_changes_settings(self):
        before=self.db.group(CID)[1];self.net.route=n.intent_plan(['text_answer'])
        await self.update(message('@NexoraTestBot Что за каритнка получилась?'))
        self.assertEqual(self.db.group(CID)[1],before);self.assertFalse(self.db.all('SELECT * FROM memories'))

    async def test_multipart_caption_utf16_limit(self):
        caption='🍎'*700
        result={'ok':True,'result':message('',mid=200,uid=BOT,photo='created')}
        with patch.object(n.urllib.request,'urlopen',return_value=io.BytesIO(json.dumps(result).encode())) as opened:
            await n.send_image(self.app,CID,PNG,'image/png',1,caption=caption)
        sent=opened.call_args.args[0].data
        limited=n.caption_limit(caption)
        self.assertLessEqual(len(limited.encode('utf-16-le'))//2,1000)
        self.assertIn(limited.encode(),sent);self.assertNotIn(caption.encode(),sent)

    async def test_upload_json_and_timeout_distinct_no_replay(self):
        for body,code in ((b'{not json','invalid_json'),(b'[]','invalid_image_response')):
            with patch.object(n.urllib.request,'urlopen',return_value=io.BytesIO(body)) as opened:
                with self.assertRaises(n.Fault) as caught:await n.send_image(self.app,CID,PNG,'image/png',1)
            self.assertEqual(caught.exception.code,code);self.assertEqual(opened.call_count,1)
        with patch.object(n.urllib.request,'urlopen',side_effect=TimeoutError()) as opened:
            with self.assertRaises(n.Fault) as caught:await n.send_image(self.app,CID,PNG,'image/png',1)
        self.assertEqual(caught.exception.code,'timeout');self.assertEqual(opened.call_count,1)

    async def test_explicit_temporary_429_retries_api_not_whole_workflow(self):
        await self.app.brain.catalog()
        http=n.HTTP();self.app.brain.http=http
        result={'choices':[{'message':{'images':[{'image_url':{'url':DATA}}],'content':'Вот яблоко.'}}], 'usage':{'cost':.04}}
        with patch.object(http,'_once',new_callable=AsyncMock,side_effect=[n.Fault('HTTP','429',1,status=429),result]) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock),patch.object(n,'send_image',new_callable=AsyncMock,return_value=message('',mid=200,uid=BOT,photo='new')) as send:
            await self.update(message('@NexoraTestBot Нарисуй яблоко'))
        self.assertEqual(once.await_count,2);send.assert_awaited_once()
        self.assertEqual(len(self.db.all("SELECT * FROM usage WHERE purpose='image'")),1)
        self.assertAlmostEqual(float(self.db.one("SELECT cost FROM usage WHERE purpose='image'")['cost']),.04)

    async def test_no_image_response_never_triggers_paid_retry(self):
        self.net.image_response={'choices':[{'message':{'content':'не удалось'}}], 'usage':{'cost':.002}}
        with self.assertLogs('nexora',level='WARNING') as logs:
            send,_=await self.visual('@NexoraTestBot Нарисуй яблоко')
        send.assert_not_awaited();self.assertEqual(len(self.net.images()),1)
        self.assertIn('no_image_returned','\n'.join(logs.output))

    async def test_ambiguous_followup_uses_owned_previous_image(self):
        self.db.c.execute('INSERT INTO nexora_images VALUES(?,?,?,?,?,?)',(CID,UID,20,'own-previous',n.time.time(),n.time.time()+7200))
        self.net.route=n.intent_plan(['image_edit'],'Замени яблоко грушей',confidence=.95)
        send,down=await self.visual('@NexoraTestBot А теперь пусть будет груша')
        send.assert_awaited_once();down.assert_awaited_once_with(self.app,'own-previous')
        self.assertEqual(len(self.net.routes()),1);self.assertEqual(len(self.net.images()),1)

    async def test_non_catalogue_subject_uses_classifier_instead_of_text_model(self):
        self.net.route=n.intent_plan(['image_generation'],'Обычный пейзаж',confidence=.94)
        send,_=await self.visual('@NexoraTestBot Сделай пейзаж')
        send.assert_awaited_once();self.assertEqual(len(self.net.routes()),1)
        self.assertEqual(len(self.net.images()),1)

    async def test_analysis_and_edit_same_clause_uses_validated_classifier(self):
        self.net.route=n.intent_plan(['image_analysis','image_edit'],'Убери человека справа',confidence=.97)
        send,_=await self.visual('@NexoraTestBot Опиши что на фото и убери человека справа',photo='source')
        send.assert_awaited_once();self.assertEqual(len(self.net.routes()),1)
        self.assertEqual(len(self.net.captions()[0]['messages'][1]['content']),3)



del BotTests
if __name__=='__main__':unittest.main()
