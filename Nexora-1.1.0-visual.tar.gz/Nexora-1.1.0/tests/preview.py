"""Local UI exercise with labelled fixtures. No Telegram polling or paid API.
Run from project root: python tests/preview.py
Only listens on loopback. Do not deploy this fixture server.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(__file__).resolve().parent))
import asyncio,json,tempfile,time,urllib.parse,os
import main as n
import personal as p
from miniapp import Server,ROOT
from test_personal1100 import init_data
import test_nexora as f

class Preview(Server):
    async def request(self,reader,writer):
        # Only fixture server adds signed test initData. Production has no auth bypass.
        prefix=await reader.readuntil(b'\r\n')
        target=prefix.split(b' ')[1]
        if target==b'/preview-auth.js':
            await reader.readuntil(b'\r\n\r\n')
            script='window.Telegram={WebApp:{initData:'+json.dumps(init_data(token=f.TOKEN))+',colorScheme:"dark",ready(){},expand(){},onEvent(){},BackButton:{hide(){},show(){},onClick(){}}}};'
            await self.respond(writer,200,script.encode(),'text/javascript');return
        if target==b'/':
            await reader.readuntil(b'\r\n\r\n')
            html=(ROOT/'index.html').read_text().replace('https://telegram.org/js/telegram-web-app.js','/preview-auth.js')
            await self.respond(writer,200,html.encode(),'text/html; charset=utf-8');return
        reader._buffer[:0]=prefix  # Restore one parsed fixture request line, not used by production.
        await super().request(reader,writer)

async def main():
    os.environ["MINIAPP_URL"]="http://127.0.0.1:8765"  # Fixture same-origin POSTs only.
    with tempfile.TemporaryDirectory() as temp:
        db=n.Store(Path(temp)/'preview.db');n.prepare_store(db)
        app=n.Nexora(db,f.Network(),f.TOKEN,'fixture-only');app.preview=True;app.me=f.BOT;app.username='NexoraTestBot'
        db.group(f.CID,'Ночная смена');db.group(f.CID-1,'Quiet Mile · разработка')
        p.profile(db,f.UID)
        server=await Preview(app).start('127.0.0.1',8765)
        print('LOCAL FIXTURE http://127.0.0.1:8765',flush=True)
        try:await asyncio.Event().wait()
        finally:await server.close();db.c.close()
if __name__=='__main__':asyncio.run(main())
