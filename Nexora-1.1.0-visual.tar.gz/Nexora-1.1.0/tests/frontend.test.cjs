// Offline interaction checks against the actual app.js with minimal DOM/API doubles.
// These do not render CSS/SMIL and are NOT a browser or Telegram integration test.
// Run: node --test tests/frontend.test.cjs (Node 18+; no packages/network required).
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
const clone=x=>JSON.parse(JSON.stringify(x));

class Element {
 constructor(){this.innerHTML='';this.textContent='';this.dataset={};this.attrs={};this.listeners={};this.open=false;this.styles={};this.offsetWidth=190;
  this.style={setProperty:(k,v)=>{this.styles[k]=v}};
  const values=new Set();this.classList={add:v=>values.add(v),remove:v=>values.delete(v),contains:v=>values.has(v),toggle:(v,on)=>{on??=!values.has(v);on?values.add(v):values.delete(v)}};
 }
 setAttribute(k,v){this.attrs[k]=v} getAttribute(k){return this.attrs[k]}
 addEventListener(k,fn){(this.listeners[k]??=[]).push(fn)}
 emit(k,event={}){for(const fn of this.listeners[k]||[])fn(event)}
 closest(){return this} querySelectorAll(){return []}
 showModal(){this.open=true} close(){this.open=false;this.emit('close')}
 pauseAnimations(){this.paused=true} unpauseAnimations(){this.paused=false} setCurrentTime(v){this.time=v}
}
function harness({authorized=true,onboarded=true,reduced=false,light=false}={}){
 const ids=Object.fromEntries(['app','sheet','sheet-body','sheet-close','sheet-toast','toast','confirm-action','retry','theme'].map(k=>[k,new Element()]));
 const body=new Element(),root=new Element(),svg=new Element(),events={},media={},calls=[],haptics=[];
 let data={version:'1.1.0',test_mode:true,suggested_name:'Лёша',catalog_checked:true,memory_enabled:true,notes:[],
  profile:{name:'Лёша',model:'flash',tier:'free',onboarded,cross_chat:false,preferences:{tone:'balanced',humor:'classic'}},
  models:[{id:'flash',name:'DeepSeek V4.1 Flash',available:true,locked:false,description:'Быстрая модель'},
   {id:'pro',name:'DeepSeek V4 Pro',available:true,locked:true,description:'Сложные задачи'}],
  quotas:{flash:{remaining:7,limit:10,window_seconds:18000,reset_at:Date.now()/1000+3600,held:0}}};
 const group={id:-100,title:'Команда <тест>',active:true,images_enabled:true,search_mode:'auto',settings:{initiative:false,archive:false,background:true,tone:'balanced',humor:'classic',profanity_level:'off'}};
 const doc={body,documentElement:root,hidden:false,querySelector:s=>s.startsWith('#')?ids[s.slice(1)]:ids.theme,
  querySelectorAll:()=>ids.app.innerHTML.includes('class="mascot"')?[svg]:[],addEventListener:(k,fn)=>{(events[k]??=[]).push(fn)}};
 const back={visible:false,hide(){this.visible=false},show(){this.visible=true},onClick(fn){this.click=fn}};
 const tg={initData:authorized?'fixture-signature':'',colorScheme:light?'light':'dark',safeAreaInset:{top:12},contentSafeAreaInset:{bottom:18},BackButton:back,
  onEvent:(k,fn)=>{events['tg:'+k]=[fn]},ready(){},expand(){},HapticFeedback:{impactOccurred:v=>haptics.push(v)}};
 let failure=null,deferred=null;
 const fetch=async(url,opt)=>{
  const payload=opt.body===undefined?undefined:JSON.parse(opt.body);calls.push({url,opt,body:payload});
  if(deferred)await deferred;if(failure)throw new Error(failure);
  if(url==='/api/profile'&&payload){data.profile={...data.profile,...payload}}
  if(url==='/api/memory'&&payload)data.notes.push({id:3,value:payload.value});
  if(url==='/api/memory/delete')data.notes=data.notes.filter(n=>n.id!==payload.id);
  if(url==='/api/memory/permission')data.memory_enabled=payload.enabled;
  if(url==='/api/groups/-100'&&payload){Object.assign(group,{...payload,settings:{...group.settings,...payload.settings}})}
  const result=url==='/api/groups'?{groups:[group]}:url==='/api/groups/-100'?group:url==='/api/groups/-100/memory'?{memories:[]}:data;
  return {ok:true,json:async()=>clone(result)};
 };
 let timer=0;const timers=new Map();
 const ctx=vm.createContext({window:{Telegram:{WebApp:tg},addEventListener(){},scrollTo(){}},document:doc,fetch,
  matchMedia:q=>media[q]??=(Object.assign(new Element(),{matches:q.includes('reduced')?reduced:light})),
  AbortController,Date,console,FormData:class{constructor(f){this.f=f}get(k){return this.f.fields[k]}},
  setTimeout:fn=>{timers.set(++timer,fn);return timer},clearTimeout:id=>timers.delete(id)});
 vm.runInContext(source,ctx);
 const settle=async()=>{for(let i=0;i<12;i++)await new Promise(resolve=>setImmediate(resolve))};
 const emit=async(type,event)=>{for(const fn of events[type]||[])fn(event);await settle()};
 const click=async(dataset,checked)=>{const el=new Element();el.dataset=dataset;if(checked!==undefined)el.attrs['aria-checked']=String(checked);await emit('click',{target:el});return el};
 return {ids,body,root,svg,tg,back,media,calls,haptics,data,group,doc,ctx,settle,emit,click,
  change:async(key,value)=>emit('change',{target:{dataset:{select:key},value}}),
  submit:async(id,fields)=>emit('submit',{preventDefault(){},target:{id,fields}}),
  fail:value=>{failure=value},hold:promise=>{deferred=promise},eval:code=>vm.runInContext(code,ctx)};
}

test('home uses authenticated API state and escapes profile names',async()=>{
 const h=harness();await h.settle();assert.equal(h.calls[0].url,'/api/me');assert.equal(h.calls[0].opt.headers.Authorization,'tma fixture-signature');
 assert.match(h.ids.app.innerHTML,/<strong>7<\/strong>/);assert.match(h.ids.app.innerHTML,/из 10 доступно/);
 h.data.profile.name='<script>unsafe</script>';await h.click({do:'refresh'});assert.match(h.ids.app.innerHTML,/&lt;script&gt;/);assert.doesNotMatch(h.ids.app.innerHTML,/<script>unsafe/);
});
test('unauthorized page makes no API request and respects reduced motion',async()=>{
 const h=harness({authorized:false,reduced:true});await h.settle();assert.equal(h.calls.length,0);assert.match(h.ids.app.innerHTML,/Открой эту панель из Telegram/);assert.equal(h.svg.paused,true);assert.equal(h.svg.time,0);
});
test('onboarding saves real profile payload',async()=>{
 const h=harness({onboarded:false});await h.settle();assert.match(h.ids.app.innerHTML,/Как мне к тебе обращаться/);
 await h.submit('name-form',{name:'Лёша'});assert.deepEqual(h.calls.find(c=>c.url==='/api/profile').body,{name:'Лёша',onboarded:true});assert.match(h.ids.app.innerHTML,/Твои запросы/);
});
test('theme changes and Telegram safe areas reach CSS variables',async()=>{
 const h=harness();await h.settle();h.tg.colorScheme='light';h.tg.contentSafeAreaInset={top:30,left:8,right:9,bottom:25};await h.emit('tg:themeChanged');
 assert.equal(h.body.classList.contains('light'),true);assert.equal(h.ids.theme.attrs.content,'#d8c8e7');assert.equal(h.root.styles['--safe-top'],'30px');assert.equal(h.root.styles['--safe-left'],'8px');assert.equal(h.root.styles['--safe-bottom'],'25px');
});
test('model picker preserves two models and shows Pro restriction inside dialog',async()=>{
 const h=harness();await h.settle();await h.click({do:'models'});assert.equal(h.ids.sheet.open,true);assert.equal((h.ids['sheet-body'].innerHTML.match(/data-model=/g)||[]).length,2);
 const before=h.calls.length;await h.click({model:'pro'});assert.equal(h.calls.length,before);assert.match(h.ids['sheet-toast'].textContent,/доступна в Pro/);
});
test('available model selection persists via existing profile endpoint',async()=>{
 const h=harness();await h.settle();await h.click({do:'models'});await h.click({model:'flash'});
 assert.deepEqual(h.calls.find(c=>c.url==='/api/profile').body,{model:'flash'});assert.equal(h.ids.sheet.open,false);
});
test('group navigation escapes title, keeps active tab and Telegram back route',async()=>{
 const h=harness();await h.settle();await h.click({nav:'groups'});assert.match(h.ids.app.innerHTML,/Команда &lt;тест&gt;/);
 await h.click({group:'-100'});assert.match(h.ids.app.innerHTML,/data-nav="groups" aria-current="page"/);assert.equal(h.back.visible,true);
 h.back.click();await h.settle();assert.equal(h.body.dataset.page,'groups');h.back.click();await h.settle();assert.equal(h.body.dataset.page,'home');assert.equal(h.back.visible,false);
});
test('group switch saves group state, never user model',async()=>{
 const h=harness();await h.settle();await h.click({group:'-100'});await h.click({toggle:'g-initiative'},false);
 assert.deepEqual(h.calls.find(c=>c.url==='/api/groups/-100'&&c.body).body,{settings:{initiative:true}});assert.equal(h.group.settings.initiative,true);assert.equal(h.calls.filter(c=>c.url==='/api/profile').length,0);
});
test('settings preserve other preferences when saving one select',async()=>{
 const h=harness();await h.settle();await h.click({nav:'settings'});await h.change('tone','casual');
 assert.deepEqual(h.calls.find(c=>c.url==='/api/profile').body,{preferences:{tone:'casual',humor:'classic'}});assert.match(h.ids.app.innerHTML,/<option value="casual" selected>/);
});
test('personal memory saves and deletion waits for confirmation',async()=>{
 const h=harness();await h.settle();await h.click({nav:'settings'});await h.submit('memory-form',{value:'Люблю краткие примеры кода.'});
 assert.match(h.ids.app.innerHTML,/Люблю краткие примеры кода/);await h.click({deleteNote:'3'});assert.equal(h.calls.filter(c=>c.url==='/api/memory/delete').length,0);
 await h.ids['confirm-action'].onclick();assert.deepEqual(h.calls.find(c=>c.url==='/api/memory/delete').body,{id:3,confirm:true});assert.equal(h.data.notes.length,0);
});
test('network failure preserves navigation and gives readable error',async()=>{
 const h=harness();await h.settle();h.fail('Failed to fetch');await h.click({do:'refresh'});
 assert.match(h.ids.toast.textContent,/Потеряла соединение/);assert.match(h.ids.app.innerHTML,/Твои запросы/);assert.equal(h.ids.app.attrs['aria-busy'],'false');
});
test('failed group loading has home and retry actions',async()=>{
 const h=harness();await h.settle();h.fail('Failed to fetch');await h.click({nav:'groups'});
 assert.match(h.ids.app.innerHTML,/Не получилось проверить группы/);assert.match(h.ids.app.innerHTML,/data-nav="home"/);assert.match(h.ids.app.innerHTML,/data-nav="groups"/);
});
test('double click does not duplicate pending profile write',async()=>{
 const h=harness();await h.settle();let release;h.hold(new Promise(r=>{release=r}));
 await h.click({toggle:'cross_chat'},false);await h.click({toggle:'cross_chat'},false);
 assert.equal(h.calls.filter(c=>c.url==='/api/profile').length,1);release();await h.settle();assert.equal(h.data.profile.cross_chat,true);
});
test('refreshed quota uses server count and recovery time',async()=>{
 const h=harness();await h.settle();h.data.quotas.flash.remaining=0;await h.click({do:'refresh'});
 assert.match(h.ids.app.innerHTML,/<strong>0<\/strong>/);assert.match(h.ids.app.innerHTML,/Следующее место через/);assert.match(h.ids.app.innerHTML,/data-progress="0"/);
});
test('mascot morph has compatible distinct closed cubic contours',async()=>{
 const h=harness();await h.settle();const shapes=JSON.parse(h.eval('JSON.stringify(shapes)'));
 assert.equal(new Set(shapes).size,3);const commands=s=>s.match(/[a-z]/gi).join('');
 for(const s of shapes){assert.equal(commands(s),'MCCCCCCCCZ');assert.equal((s.match(/-?\d+(?:\.\d+)?/g)||[]).length,50)}
 const html=h.eval('mascot()');assert.match(html,/attributeName="d"/);assert.match(html,/dur="18s"/);assert.match(html,/calcMode="spline"/);assert.ok(html.includes([...shapes,shapes[0]].join(';')));
});
test('reduced motion and background visibility pause actual SVG timeline hooks',async()=>{
 const h=harness();await h.settle();assert.equal(h.svg.paused,false);h.doc.hidden=true;await h.emit('visibilitychange');assert.equal(h.svg.paused,true);
 h.doc.hidden=false;await h.emit('visibilitychange');assert.equal(h.svg.paused,false);
 const m=h.media['(prefers-reduced-motion:reduce)'];m.matches=true;m.emit('change');assert.equal(h.svg.paused,true);assert.equal(h.svg.time,0);
});
test('mascot touch is local, has no paid/API effect and obeys motion preference',async()=>{
 const h=harness();await h.settle();const before=h.calls.length;const el=await h.click({do:'mascot'});assert.equal(el.classList.contains('greet'),true);assert.equal(h.calls.length,before);assert.deepEqual(h.haptics,['soft']);
 h.media['(prefers-reduced-motion:reduce)'].matches=true;await h.click({do:'mascot'});assert.equal(h.haptics.length,1);
});
test('Telegram back closes sheet before leaving page and clears its status',async()=>{
 const h=harness();await h.settle();await h.click({nav:'settings'});await h.click({do:'models'});await h.click({model:'pro'});
 h.back.click();await h.settle();assert.equal(h.ids.sheet.open,false);assert.equal(h.body.dataset.page,'settings');assert.equal(h.ids['sheet-toast'].textContent,'');
});
test('secondary text on top gradient and cards has at least 4.5 contrast in both themes',()=>{
 const css=fs.readFileSync(path.join(__dirname,'../web/style.css'),'utf8');
 const luminance=hex=>hex.match(/../g).map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);
 for(const selector of [':root','body.light']){
  const block=css.slice(css.indexOf(selector+'{')).split('}')[0];
  const value=k=>block.match(new RegExp('--'+k+':#([a-f0-9]{6})'))[1];
  for(const [ink,bg] of [['hero-muted','top'],['muted','surface']]){
   const [low,high]=[luminance(value(ink)),luminance(value(bg))].sort((a,b)=>a-b);
   assert.ok((high+.05)/(low+.05)>=4.5,`${selector}: ${ink} on ${bg}`);
  }
 }
});
