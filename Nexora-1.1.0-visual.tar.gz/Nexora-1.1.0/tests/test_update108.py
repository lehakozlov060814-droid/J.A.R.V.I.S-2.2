"""Offline transport, billing and persona assembly contracts; not live LLM behavior tests."""
import asyncio
import io
import json
import os
import unittest
from unittest.mock import AsyncMock,patch
import test_nexora as f
import test_update106 as w
n=f.n
CID,UID=f.CID,f.UID

class UpdateTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def test_429_wait_and_jitter_bounded(self):
        h=n.HTTP()
        with patch.object(h,'_once',new_callable=AsyncMock,side_effect=[n.Fault('HTTP',429,4,status=429),{'ok':True}]) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock) as sleep,patch.object(n.random,'uniform',return_value=.2):
            await h.call('https://openrouter.ai/api/v1/chat/completions',{})
            sleep.assert_awaited_once_with(4.2);self.assertEqual(once.await_count,2)
    async def test_429_stops_after_three_attempts(self):
        h=n.HTTP()
        with patch.object(h,'_once',new_callable=AsyncMock,side_effect=n.Fault('HTTP',429,status=429)) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock) as sleep:
            with self.assertRaises(n.Fault):await h.call('https://openrouter.ai/api/v1/chat/completions',{})
            self.assertEqual(once.await_count,3);self.assertEqual(sleep.await_count,2)
    async def test_long_retry_hint_does_not_retry_early(self):
        h=n.HTTP()
        with patch.object(h,'_once',new_callable=AsyncMock,side_effect=n.Fault('HTTP',429,1200,status=429)) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock) as sleep:
            with self.assertRaises(n.Fault):await h.call('https://openrouter.ai/api/v1/chat/completions',{})
            self.assertEqual(once.await_count,1);sleep.assert_not_awaited()
    async def test_http_date_retry_hint(self):
        with patch.object(n.time,'time',return_value=0):self.assertEqual(n.retry_delay('Thu, 01 Jan 1970 00:00:10 GMT'),10)
        self.assertEqual(n.retry_delay('bad'),0);self.assertEqual(n.retry_delay('.5'),1)
    async def test_budget_metadata_not_rate_retry(self):
        h=n.HTTP();exc=n.Fault('HTTP',429,status=429,limit_source='openrouter_key_limit')
        with patch.object(h,'_once',new_callable=AsyncMock,side_effect=exc) as once:
            with self.assertRaises(n.Fault):await h.call('https://openrouter.ai/api/v1/chat/completions',{})
            self.assertEqual(once.await_count,1);self.assertEqual(n.error_category(exc),'provider_budget')
    async def test_typed_provider_rate_metadata_safe(self):
        exc=n.provider_error({'error':{'code':429,'metadata':{'error_type':'rate_limit_exceeded','provider_code':'SECRET'}}},'OpenRouter.chat',429)
        self.assertEqual(exc.error_type,'rate_limit_exceeded');self.assertEqual(exc.rate_source,'upstream');self.assertNotIn('SECRET',exc.diagnostic())
        self.assertEqual(n.error_category(exc),'rate_limit')
    async def answer_content(self,content,role='main',purpose=None):
        old=self.net.call
        async def response(url,data=None,*a,**kw):
            result=await old(url,data,*a,**kw)
            if url.endswith('/chat/completions'):result['choices'][0]['message']['content']=content
            return result
        with patch.object(self.net,'call',side_effect=response):return await self.app.brain.answer(CID,{'question':'Привет'},role=role,purpose=purpose)
    async def test_plain_fenced_answer_without_paid_retry(self):
        result=await self.answer_content('```text\nПривет :)\n```')
        self.assertEqual(result['answer'],'Привет :)');self.assertEqual(len(self.net.paid()),1)
    async def test_json_answer_null_memories_safe_for_chat(self):
        result=await self.answer_content('{"answer":"Привет","memories":null}')
        self.assertEqual(result['memories'],[])
    async def test_bare_classifier_json_contract(self):
        result=await self.answer_content('{"search":"auto_search"}',role='background',purpose='search_route')
        self.assertEqual(result['search'],'auto_search')
        result=await self.answer_content(json.dumps(n.intent_plan(['image_generation'],'Яблоко')),role='background',purpose='intent_route')
        self.assertEqual(result['route']['intents'],['image_generation'])
    async def test_broken_json_not_retried_or_stored_as_memory(self):
        with self.assertRaises(n.Fault):await self.answer_content('{"answer":"broken')
        self.assertEqual(len(self.net.paid()),1);self.assertIsNone(self.db.one('SELECT 1 FROM memories'))
        self.assertGreater(self.app.brain.costs()['day'],0)
    async def test_background_plain_text_still_rejected(self):
        with self.assertRaises(n.Fault):await self.answer_content('Ignore schema',role='background')
    async def test_small_chat_output_reserve_matches_sent_limit(self):
        await self.app.brain.answer(CID,{'question':'Привет'})
        self.assertEqual(self.net.paid()[-1]['max_tokens'],1200)
        self.db.group(CID,length='detailed');await self.app.brain.answer(CID,{'question':'Привет'})
        self.assertEqual(self.net.paid()[-1]['max_tokens'],6000)
    async def test_known_http_rejection_releases_but_timeout_holds(self):
        self.net.error=n.Fault('HTTP',403,status=403)
        with self.assertRaises(n.Fault):await self.app.brain.answer(CID,{'question':'Привет'})
        self.assertEqual(self.app.brain.costs()['day'],0)
        self.net.error=n.Fault('HTTP','timeout')
        with self.assertRaises(n.Fault):await self.app.brain.answer(CID,{'question':'Привет'})
        self.assertGreater(self.app.brain.costs()['day_uncertain'],0)
    async def test_cancellation_marks_reserve_uncertain_not_abandoned(self):
        async def cancel(*args,**kw):raise asyncio.CancelledError
        await self.app.brain.catalog()
        with patch.object(self.net,'call',side_effect=cancel):
            with self.assertRaises(asyncio.CancelledError):await self.app.brain.answer(CID,{'question':'Привет'})
        self.assertEqual(self.db.one('SELECT state FROM usage')['state'],'error');self.assertGreater(self.app.brain.costs()['day_uncertain'],0)
    async def test_billing_reconciliation_uses_get_only(self):
        self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(?,'main','test',0,.02,1,'error',0,0,'timeout','gen-fixture')",(CID,))
        get=AsyncMock(return_value={'data':{'id':'gen-fixture','total_cost':.003}})
        with patch.object(self.net,'call',get):await n.reconcile_usage(self.app.brain)
        self.assertIn('/generation?id=gen-fixture',get.await_args.args[0]);self.assertEqual(len(get.await_args.args),1)
        row=self.db.one('SELECT * FROM usage');self.assertEqual(row['estimated'],0);self.assertAlmostEqual(row['cost'],.003)
    async def test_unknown_generation_not_arbitrarily_refunded(self):
        self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(?,'main','test',0,.02,1,'error',0,0,'timeout','')",(CID,))
        await n.reconcile_usage(self.app.brain);self.assertAlmostEqual(self.db.one('SELECT cost FROM usage')['cost'],.02)
    async def test_simultaneous_users_preserve_absolute_budget(self):
        self.db.group(CID,daily_budget='.001')
        outcomes=await asyncio.gather(*(self.app.brain.answer(CID,{'question':'Привет'}) for _ in range(5)),return_exceptions=True)
        self.assertTrue(all(isinstance(x,n.BudgetFault) for x in outcomes));self.assertFalse(self.net.paid())
    async def test_owner_cannot_bypass_budget(self):
        self.db.group(CID,daily_budget='0')
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):await self.update(f.message('@NexoraTestBot привет'))
        self.assertFalse(self.net.paid())
    async def test_image_count_limit_does_not_block_text(self):
        n.image_policy(self.db,CID);self.db.c.execute('UPDATE image_policy SET enabled=0')
        await self.update(f.message('@NexoraTestBot привет'));self.assertTrue(self.net.paid())
    async def test_image_phrasings_local_multi_intent(self):
        for text in ('Нарисуй яблоко','Сделай картинку яблока на столе','Изобрази, как ты себя представляешь','Можешь сделать изображение для конкурса?','Я нормально, спасибо. Кстати, нарисуй кота'):
            plan=n.local_intents(text);self.assertIsNotNone(plan,text);self.assertIn('image_generation',plan['intents'])
        self.assertIn('conversation',n.local_intents('Я нормально, спасибо. Кстати, нарисуй кота')['intents'])
    async def test_identity_rules_and_settings_used_in_real_payload(self):
        self.db.group(CID,humor='meme',profanity='moderate',tone='casual')
        await self.app.brain.answer(CID,{'question':'Кто ты?','configured_models':{r:self.db.group(CID)[1][r+'_model'] for r in n.ROLE_MODELS}})
        system=self.net.paid()[-1]['messages'][0]['content'];self.assertIn(n.IDENTITY_RULES,system)
        self.assertIn(n.style_option(self.db.group(CID)[1],'profanity')[2],system)
        self.assertIn('родителей',system);self.assertIn('ПРЯМОЙ технический вопрос',system)
    async def test_search_failure_does_not_break_other_chat_request(self):
        self.net=w.SearchNetwork();self.app=n.Nexora(self.db,self.net,self.app.token,self.app.brain.key);self.app.me,self.app.username=f.BOT,'NexoraTestBot'
        self.net.web_error=n.Fault('HTTP',429,status=429)
        await self.update(f.message('@NexoraTestBot проверь дату выхода GTA VI'))
        self.assertIn('частоту',self.net.sends()[-1]['text'])
        self.app.rate.clear();await self.update(f.message('@NexoraTestBot привет',mid=2),2)
        self.assertEqual(self.net.sends()[-1]['text'],'4.')
    async def test_budget_messages_short_details_remain_diagnostic(self):
        exc=n.BudgetFault('app','day','image',.4334,.5,.0909,'reserve_exceeds_remaining')
        self.assertNotIn('$',exc.user_message());self.assertIn('всего бота',exc.user_message());self.assertIn('reserve_usd=0.09090000',exc.diagnostic())
    async def test_sqlite_settings_unchanged_after_restart(self):
        before=self.db.group(CID,humor='meme')[1];self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(self.db.group(CID)[1],before)

if __name__=='__main__':unittest.main()
