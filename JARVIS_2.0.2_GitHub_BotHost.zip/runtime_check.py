"""Offline build/runtime check. No tokens, database credentials or network calls."""

import importlib
import importlib.metadata
import sqlite3
import sys
from pathlib import Path

IMPORTS = {
    "aiogram": "aiogram",
    "SQLAlchemy": "sqlalchemy",
    "asyncpg": "asyncpg",
    "pydantic": "pydantic",
    "pydantic-settings": "pydantic_settings",
    "httpx": "httpx",
    "aiosqlite": "aiosqlite",
    "snowballstemmer": "snowballstemmer",
    "tzdata": "tzdata",
    "socksio": "socksio",
}


def check_runtime(verbose=True):
    if sys.version_info < (3, 11):
        raise RuntimeError("J.A.R.V.I.S. requires Python 3.11 or newer")
    versions = {}
    for package, module in IMPORTS.items():
        try:
            importlib.import_module(module)
            versions[package] = importlib.metadata.version(package)
        except (ImportError, importlib.metadata.PackageNotFoundError):
            raise RuntimeError(
                f"Missing {package} in {sys.executable}; rebuild with this Python's -m pip"
            ) from None
    with sqlite3.connect(":memory:") as conn:
        conn.execute("CREATE VIRTUAL TABLE check_fts USING fts5(body)")
        conn.execute("SELECT json('{}')").fetchone()
    from zoneinfo import ZoneInfo

    ZoneInfo("Asia/Yakutsk")
    if verbose:
        print(f"JARVIS runtime OK: Python {sys.version.split()[0]}; executable={sys.executable}", flush=True)
        print(
            "Dependencies: " + ", ".join(f"{name}={version}" for name, version in versions.items()),
            flush=True,
        )
        print(
            f"SQLAlchemy location: {Path(importlib.import_module('sqlalchemy').__file__).resolve()}",
            flush=True,
        )
        print(f"SQLite {sqlite3.sqlite_version}: FTS5 + JSON available", flush=True)
    return versions


if __name__ == "__main__":
    try:
        check_runtime()
    except Exception as exc:
        raise SystemExit(f"Runtime check failed: {type(exc).__name__}: {exc}") from None
