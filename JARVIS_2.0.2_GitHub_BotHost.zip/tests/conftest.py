"""Real repository + mocked HTTP boundaries. No production API is substituted in app code."""

import json
import os
import time
from types import SimpleNamespace

import httpx
import pytest
from aiogram import Bot
from aiogram.client.session.base import BaseSession
from aiogram.types import ChatMemberAdministrator, ChatMemberMember, ChatMemberOwner, File, Message, User

from ai import OpenRouter
from config import Settings
from database import Base, Database
from main import App

BOT_ID = 987654321
CHAT = -1001234567890
ADMIN = 42


def model_item(mid="fixture/main", vision=False, embedding=False, structured=True):
    return {
        "id": mid,
        "name": mid,
        "context_length": 128000,
        "architecture": {
            "input_modalities": ["text", "image"] if vision else ["text"],
            "output_modalities": ["embeddings"] if embedding else ["text"],
        },
        "supported_parameters": ["structured_outputs"] if structured else [],
        "pricing": {"prompt": "0.0000001", "completion": "0.0000002", "request": "0"},
    }


class RouterHTTP:
    def __init__(self):
        self.requests = []
        self.status = 200
        self.answer = "4, сэр."
        self.memories = []
        self.raw_text = None
        self.reported_cost = "0.0001"
        self.network_error = False
        self.omit_usage = False

    def __call__(self, request):
        self.requests.append(request)
        if self.network_error:
            raise httpx.ReadTimeout("fixture timeout", request=request)
        if self.status != 200:
            return httpx.Response(self.status, json={"error": {"message": "secret must not leak"}})
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "data": [
                        model_item(),
                        model_item("fixture/second"),
                        model_item("fixture/background"),
                        model_item("fixture/bg-second"),
                        model_item("fixture/vision", vision=True),
                        model_item("fixture/plain", structured=False),
                        model_item("fixture/embedding", embedding=True),
                    ]
                },
            )
        payload = json.loads(request.content)
        usage = {"prompt_tokens": 120, "completion_tokens": 10}
        if self.reported_cost is not None:
            usage["cost"] = self.reported_cost
        if self.omit_usage:
            usage = {}
        if request.url.path.endswith("/embeddings"):
            return httpx.Response(
                200,
                json={
                    "data": [
                        {"index": i, "embedding": [0.5, 0.1, 0.3]} for i, _ in enumerate(payload["input"])
                    ],
                    "usage": usage,
                },
            )
        content = (
            self.raw_text
            if self.raw_text is not None
            else json.dumps({"answer": self.answer, "memories": self.memories})
        )
        return httpx.Response(
            200,
            json={"id": "fixture-generation", "choices": [{"message": {"content": content}}], "usage": usage},
        )


class TelegramSession(BaseSession):
    def __init__(self):
        super().__init__()
        self.requests = []
        self.status = "administrator"
        self.counter = 1000
        self.bot = None
        self.deny_notice = False

    async def close(self):
        pass

    async def stream_content(self, *args, **kwargs):
        yield b"fixture-jpeg"

    async def make_request(self, bot, method, timeout=None):
        self.requests.append(method)
        name = type(method).__name__
        if name == "DeleteWebhook":
            return True
        if name == "GetMe":
            return User(id=BOT_ID, is_bot=True, first_name="Jarvis", username="JarvisFixtureBot")
        if name == "GetFile":
            return File(
                file_id="fixture-photo",
                file_unique_id="fixture-unique",
                file_path="photo/test.jpg",
                file_size=100,
            )
        if name == "GetChatMember":
            user = User(id=method.user_id, is_bot=False, first_name="Admin")
            if self.status == "creator":
                return ChatMemberOwner(user=user, is_anonymous=False)
            if self.status == "administrator":
                return ChatMemberAdministrator(
                    user=user,
                    is_anonymous=False,
                    can_be_edited=False,
                    can_manage_chat=True,
                    can_delete_messages=False,
                    can_manage_video_chats=False,
                    can_restrict_members=False,
                    can_promote_members=False,
                    can_change_info=True,
                    can_invite_users=True,
                    can_post_stories=False,
                    can_edit_stories=False,
                    can_delete_stories=False,
                    can_send_welcome_messages=False,
                )
            return ChatMemberMember(user=user)
        if name in {"SendMessage", "EditMessageText", "SendDocument"}:
            if self.deny_notice and name == "SendMessage" and method.chat_id == CHAT:
                from aiogram.exceptions import TelegramForbiddenError

                raise TelegramForbiddenError(method=method, message="fixture forbidden")
            self.counter += 1
            return make_message(
                bot,
                getattr(method, "text", "document"),
                mid=self.counter,
                uid=BOT_ID,
                private=int(method.chat_id) > 0,
                chat_id=int(method.chat_id),
                is_bot=True,
            )
        if name == "AnswerCallbackQuery":
            return True
        raise AssertionError(f"Unexpected Telegram method: {name}")


def make_message(
    bot,
    body="/jarvis 2+2",
    mid=1,
    uid=ADMIN,
    private=False,
    chat_id=None,
    reply=None,
    is_bot=False,
    photo=False,
):
    value = {
        "message_id": mid,
        "date": int(time.time()),
        "chat": {
            "id": chat_id if chat_id is not None else uid if private else CHAT,
            "type": "private" if private else "supergroup",
            "title": "Fixture group",
        },
        "from": {"id": uid, "is_bot": is_bot, "first_name": f"User{uid}"},
    }
    if photo:
        value["caption"] = body
        value["photo"] = [
            {
                "file_id": "fixture-photo",
                "file_unique_id": "fixture-unique",
                "width": 100,
                "height": 100,
                "file_size": 100,
            }
        ]
    else:
        value["text"] = body
    if reply:
        value["reply_to_message"] = reply.model_dump(mode="json", exclude_none=True)
    return Message.model_validate(value, context={"bot": bot})


@pytest.fixture
async def env(tmp_path):
    # TEST_DATABASE_URL must point at a disposable database: the fixture drops its schema.
    url = os.getenv("TEST_DATABASE_URL") or f"sqlite+aiosqlite:///{tmp_path / 'test.db'}"
    config = Settings(
        _env_file=None,
        database_url=url,
        default_main_model="fixture/main",
        default_background_model="fixture/background",
        default_embedding_model="fixture/embedding",
        openrouter_api_key="fixture-key",
        bot_owner_id=ADMIN,
    )
    db = Database(config)
    if db.pg:
        async with db.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
    await db.initialize()
    await db.ensure_group(CHAT, "Fixture group")
    http = RouterHTTP()
    client = httpx.AsyncClient(base_url=OpenRouter.BASE, transport=httpx.MockTransport(http))
    ai = OpenRouter(config, db, client)
    session = TelegramSession()
    bot = Bot(f"{BOT_ID}:" + "x" * 35, session=session)
    app = App(config, db, ai, bot, BOT_ID, "JarvisFixtureBot")
    group, values = await db.group(CHAT)
    try:
        yield SimpleNamespace(
            db=db,
            config=config,
            ai=ai,
            http=http,
            app=app,
            bot=bot,
            telegram=session,
            values=values,
            chat=CHAT,
            admin=ADMIN,
        )
    finally:
        await ai.close()
        await bot.session.close()
        await db.close()


async def archive(env, mid, text_value, uid=ADMIN, chat=None, reply=None, date=None, meaningful=True):
    chat = chat or env.chat
    await env.db.settings(chat, archive=True)
    return await env.db.store_message(
        chat,
        mid,
        uid,
        date or time.time(),
        text_value,
        "text",
        reply,
        {},
        invoked=False,
        meaningful=meaningful,
    )


def candidate(mid=1, quote="Решили назвать проект Quiet Mile", kind="project", subjects=None):
    return {
        "kind": kind,
        "value": quote,
        "subject_ids": subjects or [],
        "evidence": [{"message_id": mid, "quote": quote}],
        "confidence": 0.95,
        "event_date": "",
    }
