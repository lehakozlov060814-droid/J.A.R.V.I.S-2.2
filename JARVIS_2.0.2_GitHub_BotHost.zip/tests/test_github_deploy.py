"""GitHub/BotHost regressions: real startup/settings/SQLite, mocked network only."""

import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

import pytest
from conftest import CHAT, archive, candidate

from ai import JARVIS_PERSONALITY, AIError
from config import DEFAULT_DATABASE_URL, Settings
from database import Database

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    "host_name,file_name",
    [("BOT_TOKEN", "TELEGRAM_BOT_TOKEN"), ("TELEGRAM_BOT_TOKEN", "BOT_TOKEN"), ("API_TOKEN", "BOT_TOKEN")],
)
def test_environment_token_beats_old_dotenv_alias(tmp_path, monkeypatch, host_name, file_name):
    for name in ("BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "API_TOKEN"):
        monkeypatch.delenv(name, raising=False)
    envfile = tmp_path / ".env"
    envfile.write_text(f"{file_name}=stale-file-token\n")
    monkeypatch.setenv(host_name, "  host-token  ")
    assert Settings(_env_file=envfile).telegram_bot_token.get_secret_value() == "host-token"
    assert (
        Settings(_env_file=envfile, telegram_bot_token="explicit-token").telegram_bot_token.get_secret_value()
        == "explicit-token"
    )


def test_bothost_token_has_priority_when_all_aliases_present(monkeypatch):
    monkeypatch.setenv("BOT_TOKEN", "host-token")
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "old-token")
    monkeypatch.setenv("API_TOKEN", "other-token")
    assert Settings(_env_file=None).telegram_bot_token.get_secret_value() == "host-token"


def test_default_database_independent_of_working_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert Path(DEFAULT_DATABASE_URL.split("///", 1)[1]) == ROOT / "data" / "jarvis.db"


async def test_auto_selection_is_catalog_only_and_fills_roles_separately(env):
    env.config.default_main_model = env.config.default_background_model = ""
    values = await env.db.settings(CHAT, main_model="", background_model="")
    model = await env.ai.model("")
    assert model.id in await env.ai.catalog() and model.compatible("main")
    assert all(request.method == "GET" for request in env.http.requests)
    assert (await env.db.group(CHAT))[1]["main_model"] == ""
    await env.ai.generate(CHAT, values, {}, {"question": "2+2"})
    updated = (await env.db.group(CHAT))[1]
    assert updated["main_model"] == model.id and updated["background_model"] == ""
    await env.ai.generate(CHAT, updated, {}, {"question": "extract memory"}, purpose="background")
    updated = (await env.db.group(CHAT))[1]
    assert updated["main_model"] == model.id and updated["background_model"]
    other = Database(env.config)
    try:
        assert (await other.group(CHAT))[1]["main_model"] == model.id
        assert (await other.group(CHAT))[1]["background_model"] == updated["background_model"]
    finally:
        await other.close()


async def test_auto_choice_rejects_expensive_unknown_and_incompatible_models(env):
    base = (await env.ai.catalog())["fixture/main"]
    cheap = replace(base, id="catalog/economy", pricing={"prompt": "0.00000001", "completion": "0.00000001"})
    expensive = replace(base, id="catalog/expensive", pricing={"prompt": "1", "completion": "1"})
    unknown = replace(base, id="catalog/unknown", pricing={})
    image_only = replace(base, id="catalog/image", outputs=("image",))
    tiny = replace(base, id="catalog/tiny", context=4096)
    free = replace(base, id="catalog/free", pricing={"prompt": "0", "completion": "0"})
    env.ai.cache = {m.id: m for m in (expensive, unknown, image_only, tiny, free, cheap)}
    env.ai.catalog_at = time.monotonic()
    assert (await env.ai.model("")).id == cheap.id
    env.ai.cache.pop(cheap.id)
    assert (await env.ai.model("")).id == free.id
    env.ai.cache.pop(free.id)
    with pytest.raises(AIError, match="no_compatible_default_model"):
        await env.ai.model("")
    assert not [r for r in env.http.requests if r.method == "POST"]


async def test_auto_choice_does_not_overwrite_concurrent_admin_selection(env, monkeypatch):
    stale = await env.db.settings(CHAT, main_model="")
    original = env.ai.automatic_model

    async def choose(role):
        model = await original(role)
        await env.db.settings(CHAT, main_model="fixture/second", tone="casual")
        return model

    monkeypatch.setattr(env.ai, "automatic_model", choose)
    await env.ai.generate(CHAT, stale, {}, {"question": "2+2"})
    post = json.loads(next(r.content for r in env.http.requests if r.method == "POST"))
    assert post["model"] == "fixture/second"
    assert "разговорный" in post["messages"][0]["content"]
    assert JARVIS_PERSONALITY in post["messages"][0]["content"]


async def test_missing_explicit_model_never_silently_resets_to_auto(env):
    settings = await env.db.settings(CHAT, main_model="missing/removed")
    with pytest.raises(AIError, match="model_missing_from_catalog"):
        await env.ai.generate(CHAT, settings, {}, {"question": "2+2"})
    assert (await env.db.group(CHAT))[1]["main_model"] == "missing/removed"
    assert not [r for r in env.http.requests if r.method == "POST"]


async def test_background_worker_autoselects_and_retains_validated_memory(env):
    from memory import MemoryEngine

    env.config.default_background_model = ""
    await env.db.settings(CHAT, background_model="", threshold=1)
    await archive(env, 1, "Решили назвать проект Quiet Mile")
    env.http.memories = [candidate()]
    engine = MemoryEngine(env.db, env.ai, env.config)
    assert await engine.process(CHAT, force=True)
    assert (await env.db.group(CHAT))[1]["background_model"]
    assert (await env.db.memories(CHAT, status=None))[0].kind == "project"
    assert (await env.db.messages(CHAT))[0].queue_state == "done"
    assert Decimal((await env.db.expenses(CHAT, "UTC"))["today"]) > 0


def test_startup_with_only_two_settings_and_restart(tmp_path):
    # Fresh copy: default DB path follows the deployed modules, not the caller's CWD.
    deployed = tmp_path / "app"
    deployed.mkdir()
    for name in ("main.py", "ai.py", "config.py", "database.py", "memory.py", "runtime_check.py"):
        shutil.copy2(ROOT / name, deployed / name)
    unrelated = tmp_path / "unrelated"
    unrelated.mkdir()
    environ = os.environ.copy()
    for name, field in Settings.model_fields.items():
        environ.pop(name.upper(), None)
        environ.pop(name, None)
    for name in ("TELEGRAM_BOT_TOKEN", "API_TOKEN", "TEST_DATABASE_URL"):
        environ.pop(name, None)
    environ.update(BOT_TOKEN="987654321:" + "x" * 35, OPENROUTER_API_KEY="fixture-key")
    script = r"""
import asyncio, json, sys
from pathlib import Path
sys.path[:0] = [sys.argv[1], sys.argv[2]]
import httpx
import main
from aiogram import Bot, Dispatcher
from aiogram.types import Update
from conftest import TelegramSession, RouterHTTP, make_message, CHAT
from database import Database
settings = main.Settings()
assert settings.bot_owner_id == 0 and not settings.default_main_model
assert not settings.default_embedding_model and not settings.group_defaults()["semantic"]
assert not settings.group_defaults()["archive"]
real_ai = main.OpenRouter
network = RouterHTTP()
telegram = TelegramSession()
bot = Bot(settings.telegram_bot_token.get_secret_value(), session=telegram)
main.Bot = lambda token: bot
main.OpenRouter = lambda cfg, db: real_ai(cfg, db, httpx.AsyncClient(base_url=real_ai.BASE, transport=httpx.MockTransport(network)))
round_number = 0
async def poll(self, target, **kwargs):
    global round_number
    assert type(telegram.requests[-1]).__name__ == "DeleteWebhook"
    assert telegram.requests[-1].drop_pending_updates is False
    await self.feed_update(target, Update(update_id=100 + round_number, message=make_message(target, "/start", private=True, mid=100 + round_number)))
    sent = [r for r in telegram.requests if type(r).__name__ == "SendMessage"][-1]
    assert sent.reply_markup and "панель управления" in sent.text
    assert not [r for r in network.requests if r.method == "POST"] or round_number == 1
    if round_number == 0:
        await self.feed_update(target, Update(update_id=200, message=make_message(target, "/jarvis 2+2", mid=200)))
        sent = [r for r in telegram.requests if type(r).__name__ == "SendMessage"][-1]
        assert sent.text == "4, сэр.", sent.text
        assert Path(sys.argv[1], "data", "jarvis.db").is_file()
    round_number += 1
Dispatcher.start_polling = poll
async def verify():
    await main.run()
    await main.run()
    db = Database(main.Settings())
    try:
        group, values = await db.group(CHAT)
        assert values["main_model"] and not values["archive"]
        assert (await db.expenses(CHAT, "UTC"))["requests"] == 1
    finally:
        await db.close()
asyncio.run(verify())
print("START_AND_GROUP_REPLY_AND_RESTART_OK")
"""
    result = subprocess.run(
        [sys.executable, "-c", script, str(deployed), str(ROOT / "tests")],
        cwd=unrelated,
        env=environ,
        text=True,
        capture_output=True,
        timeout=30,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "START_AND_GROUP_REPLY_AND_RESTART_OK" in result.stdout
    assert "fixture-key" not in result.stdout + result.stderr
