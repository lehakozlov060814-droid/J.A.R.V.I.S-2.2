"""Recovery regression. Network fixture results are not evidence of live provider operation."""
import asyncio
import ast
import json
import logging
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock,patch
import test_nexora as f
import test_update106 as web
n=f.n
CID,UID,BOT=f.CID,f.UID,f.BOT

class RecoveryTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        f.BotTests.setUp(self)
        self.net=web.SearchNetwork();self.app=n.Nexora(self.db,self.net,self.app.token,self.app.brain.key)
        self.app.me,self.app.username=BOT,'NexoraTestBot'
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    def policy(self,mode='manual',cap=10):
        n.search_policy(self.db,CID);self.db.c.execute('UPDATE search_policy SET mode=?,daily_cap=? WHERE chat_id=?',(mode,cap,CID))
    async def request(self,text='Проверь дату выхода гта 6',mid=1,reply=True):
        self.app.rate.clear()
        m=f.message(text,mid=mid,reply=f.message('Обсудим обновление.',mid=90,uid=BOT) if reply else None)
        await self.update(m,mid);return m
    async def run_web(self,q='Проверь дату выхода гта 6',mid=1):
        return await n.web_context(self.app,f.message(q,mid=mid),q,'direct')
    def main_requests(self):
        return [p for p in self.net.paid() if not p.get('tools') and p['model'] in {n.personal.FLASH,n.DEFAULTS['main_model']}]
    def events(self):return [r['event'] for r in self.app.trace_records]
    async def test_incident_exact_reply_in_manual_mode_searches_and_attaches(self):
        self.policy();await self.request()
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(len(self.main_requests()),1)
        ctx=json.loads(self.main_requests()[0]['messages'][1]['content'])
        self.assertEqual(ctx['web']['sources'][0]['url'],web.URL);self.assertEqual(ctx['web']['status'],'ok')
        self.assertEqual(self.net.sends()[-1]['reply_markup']['inline_keyboard'][0][0]['url'],web.URL)
        self.assertEqual(self.net.web_calls[0]['messages'][1]['content'],'Проверь дату выхода GTA VI')
    async def test_incident_named_direct_call(self):
        self.policy();await self.request('Нексора, проверь дату выхода гта 6',reply=False)
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(len(self.main_requests()),1)
    async def test_exact_reported_examples_routed(self):
        for q in ('Проверь дату выхода гта 6','Поищи в интернете последние новости про Minecraft','Найди официальный источник даты выхода GTA 6'):
            self.assertEqual(n.search_decision(q),'forced_search')
        for q in ('Нексора, когда выйдет GTA VI?','Какая сегодня погода в Москве?','Что нового произошло сегодня?'):
            self.assertEqual(n.search_decision(q),'auto_search')
    async def test_all_direct_search_variants(self):
        for q in ('Проверь дату выхода GTA VI','Уточни дату релиза GTA 6','Найди свежие новости про OpenAI','Проверь, правда ли это','Поищи в интернете','Загугли это','Найди официальный источник'):
            self.assertEqual(n.search_decision(q),'forced_search',q)
    async def test_plain_cases_no_classifier_or_search(self):
        for q in ('Привет, Нексора','Сколько будет 34 + 33?','Придумай название для игры','Расскажи анекдот','Нарисуй банан','Надо улучшить Нексору'):
            self.assertEqual(n.search_decision(q),'no_search',q)
    async def test_alias_filter_matches_english_evidence_not_invented_fact(self):
        annotations=web.response()['choices'][0]['message']
        for q in ('Проверь дату выхода гта 6','Проверь дату выхода GTA6','Когда выйдет Grand Theft Auto VI?'):
            result,stale=n.verified_sources(annotations,q,'announcement')
            self.assertEqual(result[0]['url'],web.URL);self.assertIsNone(result[0]['published_at'])
        self.assertEqual(n.normalized_search_text('гта 6'),'GTA VI')
    async def test_ordinary_text_no_web_dispatch(self):
        await self.request('Нексора, привет',reply=False)
        self.assertFalse(self.net.web_calls);self.assertEqual(len(self.main_requests()),1)
    async def test_third_person_no_search_or_answer(self):
        await self.request('Надо улучшить Нексору',reply=False)
        self.assertFalse(self.net.paid());self.assertFalse(self.net.sends())
    async def test_manual_mode_still_blocks_automatic(self):
        self.policy();await self.request('Нексора, когда выйдет GTA VI?',reply=False)
        self.assertFalse(self.net.paid());self.assertIn('Автоматический поиск выключен',self.net.sends()[-1]['text'])
    async def test_disabled_search_exact_reason(self):
        self.policy('off');await self.request()
        self.assertFalse(self.net.paid());self.assertIn('в этой группе выключен',self.net.sends()[-1]['text'])
    async def test_exhausted_quota_not_financial_error(self):
        self.policy(cap=5)
        for mid in range(10,15):n.reserve_search(self.db,CID,mid)
        await self.request();self.assertFalse(self.net.web_calls)
        self.assertIn('лимит интернет-поиска',self.net.sends()[-1]['text'])
        self.assertNotIn('расход',self.net.sends()[-1]['text'])
    async def test_missing_key_is_configuration_not_no_feature(self):
        self.app.brain.key='';await self.request()
        self.assertFalse(self.net.web_calls);self.assertFalse(self.main_requests())
        self.assertIn('не настроен',self.net.sends()[-1]['text'])
        self.assertIsNone(self.db.one('SELECT 1 FROM search_jobs'));self.assertIsNone(self.db.one('SELECT 1 FROM usage'))
    async def test_provider_timeout_local_error_no_main_fallback(self):
        self.net.web_error=n.Fault('HTTP','timeout',operation='OpenRouter.chat')
        await self.request();self.assertEqual(len(self.net.web_calls),1);self.assertFalse(self.main_requests())
        self.assertIn('Не получилось проверить информацию',self.net.sends()[-1]['text'])
        self.assertEqual(n.search_stats(self.db,CID)['held'],1)
    async def test_auth_access_balance_distinct(self):
        for i,(status,expected) in enumerate(((401,'search_auth_failed'),(403,'search_access_denied'),(402,'search_balance')),1):
            self.net.web_error=n.Fault('HTTP',status,status=status)
            r=await self.run_web(mid=i);self.assertEqual(r['reason'],expected)
        self.assertEqual(self.app.brain.costs()['day'],0);self.assertEqual(n.search_stats(self.db,CID)['held'],0)
    async def test_empty_result_does_not_call_main(self):
        self.net.web_response=web.response(sources=[]);await self.request()
        self.assertEqual(len(self.net.web_calls),1);self.assertFalse(self.main_requests());self.assertEqual(n.search_stats(self.db,CID)['used'],1)
    async def test_real_urls_only_not_raw_model_urls(self):
        await self.request()
        self.assertEqual(self.net.sends()[-1]['reply_markup']['inline_keyboard'][0][0]['url'],web.URL)
        self.assertNotIn('https://evil',n.web_answer('Ответ https://evil.example/fake',{'status':'ok'}))
    async def test_provider_count_zero_releases_quantity_keeps_llm_cost(self):
        self.net.web_response=web.response(count=0,cost=.0001)
        r=await self.run_web();self.assertEqual(r['reason'],'search_not_executed')
        self.assertEqual(n.search_stats(self.db,CID),{'used':0,'held':0});self.assertAlmostEqual(self.app.brain.costs()['day'],.0001)
    async def test_no_silent_fallback_after_invalid_classifier(self):
        self.net.search_route='unexpected'
        await self.request('Нексора, выясни планы издателя',reply=False)
        self.assertFalse(self.net.web_calls);self.assertFalse(self.main_requests())
        self.assertIn('определить',self.net.sends()[-1]['text'])
    async def test_preflight_unavailable_catalog_refunds_quantity(self):
        self.net.error=n.Fault('HTTP','network_error')
        old=self.net.call
        async def unavailable(url,*args,**kw):
            if url.endswith('/models'):raise n.Fault('HTTP','network_error')
            return await old(url,*args,**kw)
        self.net.call=unavailable
        await self.run_web();self.assertEqual(n.search_stats(self.db,CID)['held'],0)
        self.assertFalse(self.net.web_calls);self.assertEqual(self.app.brain.costs()['day'],0)
    async def test_restart_releases_prepared_keeps_dispatched_uncertain(self):
        n.reserve_search(self.db,CID,1);n.reserve_search(self.db,CID,2)
        self.db.c.execute("UPDATE search_jobs SET state='pending' WHERE message_id=2")
        n.prepare_search(self.db)
        states={r['message_id']:r['state'] for r in self.db.all('SELECT * FROM search_jobs')}
        self.assertEqual(states,{1:'failed',2:'uncertain'});self.assertEqual(n.search_stats(self.db,CID)['held'],1)
    async def test_cancellation_before_dispatch_does_not_spend_quantity(self):
        async def cancel(*args,**kwargs):raise asyncio.CancelledError
        with patch.object(self.app.brain,'model',side_effect=cancel):
            with self.assertRaises(asyncio.CancelledError):await self.run_web()
        self.assertEqual(n.search_stats(self.db,CID)['held'],0);self.assertFalse(self.net.web_calls)
    async def test_duplicate_telegram_update_not_second_dispatch(self):
        self.policy();m=await self.request();await self.update(m,1)
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(n.search_stats(self.db,CID)['used'],1)
    async def test_parallel_budget_reservations_remain_enforced(self):
        self.db.group(CID,daily_budget='0.02');self.net.web_error=n.Fault('HTTP','timeout')
        r=await asyncio.gather(*(self.run_web(mid=i) for i in range(6)))
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(sum(x['reason']=='budget' for x in r),5)
    async def test_compound_real_workflow_one_search_image_caption(self):
        self.policy();self.net.caption='Ответ по источникам. Аватарка готова.'
        with patch.object(n,'send_image',new_callable=AsyncMock,return_value=f.message('',mid=200,uid=BOT,photo='generated')) as send:
            await self.request('Нексора, проверь дату выхода гта 6 и сделай аватарку по этой игре',reply=False)
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(len(self.net.images()),1);send.assert_awaited_once()
        self.assertEqual(send.await_args.kwargs['sources'][0][0]['url'],web.URL);self.assertFalse(self.net.sends())
    async def test_capability_denial_after_success_not_published_as_truth(self):
        answer=n.web_answer('Извините, у меня нет доступа к интернет-поиску.',{'status':'ok','sources':[{'url':web.URL}]})
        self.assertNotIn('нет доступа',answer);self.assertIn('Поиск выполнен',answer)
        self.assertNotIn('2026',answer)
    async def test_runtime_capability_is_application_state(self):
        await self.request('Нексора, привет',reply=False)
        system=self.main_requests()[0]['messages'][0]['content']
        self.assertIn('отдельным адаптером',system);self.assertIn('"configured":true',system)
        self.assertIn('"performed":false',system)
    async def test_search_state_comes_from_config_not_prompt(self):
        self.policy('off')
        await self.app.brain.answer(CID,{'question':'Тест','search_capability':{'configured':True,'mode':'auto'}})
        system=self.main_requests()[0]['messages'][0]['content'];self.assertIn('"mode":"off"',system)
    async def test_bare_search_uses_direct_reply_or_asks_without_spending(self):
        for q in ('Поищи в интернете','Загугли это','Найди официальный источник','Проверь, правда ли это'):
            self.assertTrue(n.search_is_referential(q),q)
        await self.update(f.message('Поищи в интернете',reply=f.message('Когда выйдет GTA VI?',mid=90,uid=BOT)))
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(len(self.main_requests()),1)
        # A separate bare request with no reply/topic needs a subject.
        self.db.c.execute('DELETE FROM search_topics');r=await self.run_web('Найди официальный источник',mid=2)
        self.assertEqual(r['reason'],'search_needs_query');self.assertEqual(len(self.net.web_calls),1)
    async def test_unknown_policy_fails_closed_without_reset(self):
        self.policy('broken');r=await self.run_web()
        self.assertEqual(r['reason'],'search_invalid_policy');self.assertFalse(self.net.web_calls)
        self.assertEqual(n.search_policy(self.db,CID)['mode'],'broken')
        await self.app.panel(UID,{'v':'web_search','c':CID});self.assertIn('Ошибка настройки',self.net.sends()[-1]['text'])
    async def test_saved_modes_and_caps_survive_restart(self):
        self.policy('manual',20);before=self.db.group(CID)[1]
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(n.search_policy(self.db,CID)['mode'],'manual');self.assertEqual(n.search_policy(self.db,CID)['daily_cap'],20)
        self.assertEqual(self.db.group(CID)[1],before)
    async def test_old_groups_manual_new_groups_auto_unchanged(self):
        self.db.c.execute("DELETE FROM single_meta WHERE key='search106'");n.prepare_search(self.db)
        self.assertEqual(n.search_policy(self.db,CID)['mode'],'manual')
        self.assertEqual(n.search_policy(self.db,CID-1)['mode'],'auto')
    async def test_cache_payload_validation_not_trusted_blindly(self):
        await self.run_web('Когда выйдет GTA VI?')
        self.db.c.execute("UPDATE search_cache SET payload='{}'")
        await self.run_web('Когда выйдет GTA VI?',mid=2);self.assertEqual(len(self.net.web_calls),2)
    async def test_all_required_diagnostic_events_on_success(self):
        self.app.trace_until=n.time.time()+60;await self.request()
        events=self.events()
        for event in ('message_received','activation_decision','search_decision','search_provider_selected','search_started','search_completed','search_results_attached','response_generated','response_sent'):
            self.assertIn(event,events)
        self.assertLess(events.index('activation_decision'),events.index('search_decision'))
        self.assertLess(events.index('search_completed'),events.index('search_results_attached'))
        self.assertEqual(len({r['trace'] for r in self.app.trace_records}),1)
    async def test_diagnostics_off_by_default(self):
        await self.request();self.assertFalse(self.app.trace_records)
    async def test_skipped_reason_and_error_stage_traced(self):
        self.app.trace_until=n.time.time()+60;await self.request('Нексора, привет',reply=False)
        self.assertTrue(any(r.get('reason')=='not_required' for r in self.app.trace_records))
        self.net.web_error=n.Fault('HTTP','timeout');await self.request(mid=2)
        failure=[r for r in self.app.trace_records if r['event']=='search_failed'][-1]
        self.assertEqual(failure['reason'],'timeout');self.assertEqual(failure['exception'],'Fault')
    async def test_trace_never_contains_query_tokens_or_private_ids(self):
        self.app.trace_until=n.time.time()+60
        with self.assertLogs('nexora',level=logging.INFO) as logs:await self.request('Нексора, проверь дату выхода GTA VI PRIVATE_SENTINEL',reply=False)
        content='\n'.join(logs.output)+json.dumps(self.app.trace_records)
        for secret in ('PRIVATE_SENTINEL',str(CID),self.app.token,self.app.brain.key,web.URL):self.assertNotIn(secret,content)
        for record in self.app.trace_records:
            self.assertFalse({'user_id','chat_id','message_id','uid','cid'} & record.keys())
            self.assertNotIn(UID,[v for v in record.values() if type(v) is int])
    async def test_hidden_trace_control_only_owner(self):
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID+1)}):
            await n.owner_diagnostics(self.app,UID,'/diag trace on');self.assertEqual(self.app.trace_until,0)
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):
            await n.owner_diagnostics(self.app,UID,'/diag trace on');self.assertGreater(self.app.trace_until,n.time.time())
            await n.owner_diagnostics(self.app,UID,'/diag trace off');self.assertEqual(self.app.trace_until,0)
    async def test_fingerprint_in_owner_diag_matches_loaded_file(self):
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):await n.owner_diagnostics(self.app,UID)
        self.assertIn(n.BUILD_FINGERPRINT,self.net.sends()[-1]['text'])
        self.assertEqual(n.BUILD_FINGERPRINT,n.hashlib.sha256(Path(n.__file__).read_bytes()).hexdigest()[:16])
    async def test_trace_context_isolated_between_parallel_groups(self):
        self.app.trace_until=n.time.time()+60
        self.db.group(CID-1,'Other group')
        await asyncio.gather(self.update(f.message('Нексора, привет',mid=1),1),self.update(f.message('Нексора, привет',mid=2,cid=CID-1),2))
        self.assertEqual(len({r['trace'] for r in self.app.trace_records}),2)
        self.assertEqual(len(self.main_requests()),2)
        self.assertIsNone(n.REQUEST_TRACE.get())
    async def test_malformed_provider_annotations_do_not_escape_as_programmer_error(self):
        self.net.web_response=web.response(sources={'wrong':'type'})
        r=await self.run_web();self.assertEqual(r['reason'],'search_empty');self.assertFalse(self.main_requests())
    async def test_zero_money_limit_blocks_before_paid_search(self):
        self.db.group(CID,daily_budget='0');r=await self.run_web()
        self.assertEqual(r['reason'],'budget');self.assertIn('ограничения расходов',r['message'])
        self.assertFalse(self.net.web_calls);self.assertEqual(n.search_stats(self.db,CID)['held'],0)
    async def test_no_hardcoded_release_date_and_stdlib_only(self):
        tree=ast.parse(Path(n.__file__).read_text())
        fn=next(x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name=='normalized_search_text')
        literals=[x.value for x in ast.walk(fn) if isinstance(x,ast.Constant) and isinstance(x.value,str)]
        self.assertFalse(any('2026' in x or 'ноября' in x for x in literals))
        import sys
        modules={x.names[0].name.split('.')[0] for x in ast.walk(tree) if isinstance(x,ast.Import)}|{x.module.split('.')[0] for x in ast.walk(tree) if isinstance(x,ast.ImportFrom)}
        self.assertFalse(modules-sys.stdlib_module_names-{'personal','miniapp','live','telegram_context'})

    async def test_publisher_word_is_not_mistaken_for_release_date(self):
        self.assertEqual(n.search_decision('Выясни планы издателя'),'ambiguous')
    async def test_weather_english_excerpts_survive_russian_query(self):
        self.net.web_response=web.response(sources=[{'type':'url_citation','url_citation':{'url':'https://example.org/weather/moscow','title':'Moscow weather','content':'Moscow weather forecast from the provider.'}}])
        await self.request('Нексора, какая сегодня погода в Москве?',reply=False)
        self.assertEqual(len(self.net.web_calls),1);self.assertEqual(len(self.main_requests()),1)
        self.assertEqual(self.net.sends()[-1]['reply_markup']['inline_keyboard'][0][0]['url'],'https://example.org/weather/moscow')
    async def test_cyrillic_brand_without_space_normalized(self):
        self.assertEqual(n.normalized_search_text('гта6'),'GTA VI')

    async def test_permanent_request_error_not_described_as_temporary_outage(self):
        self.net.web_error=n.Fault('HTTP','400',status=400)
        r=await self.run_web();self.assertEqual(r['reason'],'search_request_rejected')
        self.assertEqual(n.search_stats(self.db,CID)['held'],0)
    async def test_trace_preserves_underlying_network_exception(self):
        self.app.trace_until=n.time.time()+60
        self.net.web_error=n.Fault('HTTP','timeout',exception_type='TimeoutError',operation='OpenRouter.chat')
        await self.request()
        record=[r for r in self.app.trace_records if r['event']=='search_failed'][-1]
        self.assertEqual(record['exception'],'TimeoutError');self.assertEqual(record['operation'],'OpenRouter.chat')


@unittest.skipUnless(os.getenv('NEXORA_LIVE_SEARCH')=='1' and bool(os.getenv('OPENROUTER_API_KEY','').strip()),'Real paid search requires explicit NEXORA_LIVE_SEARCH=1 and OPENROUTER_API_KEY; no live credentials here')
class LiveSearchTest(unittest.IsolatedAsyncioTestCase):
    async def test_real_provider_then_main_synthesis(self):
        class CountHTTP(n.HTTP):
            def __init__(self):super().__init__();self.search_sent=0;self.main_received_sources=False
            async def call(self,url,data=None,*args,**kwargs):
                if data and data.get('tools'):self.search_sent+=1
                elif data and url.endswith('/chat/completions'):
                    ctx=json.loads(data['messages'][1]['content']);self.main_received_sources=bool(ctx.get('web',{}).get('sources'))
                return await super().call(url,data,*args,**kwargs)
        with tempfile.TemporaryDirectory() as folder:
            db=n.Store(Path(folder)/'live.db');n.prepare_store(db)
            try:
                http=CountHTTP();app=n.Nexora(db,http,'',os.environ['OPENROUTER_API_KEY']);db.group(CID,'isolated-live-test')
                m=f.message('Проверь дату выхода GTA VI и дай официальный источник')
                result=await n.web_context(app,m,m['text'],'direct')
                self.assertEqual(result['status'],'ok',result.get('reason'));self.assertEqual(http.search_sent,1)
                self.assertTrue(all(n.source_url(x['url']) for x in result['sources']))
                answer=await app.brain.answer(CID,{'question':m['text'],'web':{k:v for k,v in result.items() if not k.startswith('_')}})
                self.assertTrue(http.main_received_sources);self.assertTrue(answer['answer'].strip())
                print('LIVE search and synthesis completed. Sources:',[s['url'] for s in result['sources']])
                print('LIVE total confirmed/estimated USD:',app.brain.costs()['day'])
                # No hardcoded release-date assertion: factual/semantic assessment still requires review.
            finally:db.c.close()

if __name__=='__main__':unittest.main()
