"""Offline regression: no live image fidelity or personality claims."""
import unittest
from unittest.mock import AsyncMock,patch
from datetime import datetime,timezone
import test_nexora as f
import test_update103 as multi
n=f.n
class Recovery109(unittest.IsolatedAsyncioTestCase):
    fixture_setup=f.BotTests.setUp
    setUp=multi.MultiIntentTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def test_exact_edit_reply_passes_actual_source(self):
        with patch.object(n,'download_photo',new_callable=AsyncMock,return_value=f.DATA) as down,patch.object(n,'send_image',new_callable=AsyncMock,return_value=f.message('',mid=200,uid=f.BOT,photo='out')) as send:
            await self.update(f.message('@NexoraTestBot Добавь рядом с фурри на кровати куклу',reply=f.message('',mid=90,uid=f.BOT,photo='room')))
        down.assert_awaited_once_with(self.app,'room');send.assert_awaited_once()
        self.assertIn('Вариант',send.await_args.kwargs['caption'])
        self.assertIn(f.DATA,str(self.net.images()[0]['messages']))
    async def test_followup_resumes_edit_not_new_generation(self):
        with patch.object(n,'download_photo',new_callable=AsyncMock,return_value=f.DATA) as down,patch.object(n,'send_image',new_callable=AsyncMock,return_value=f.message('',mid=200,uid=f.BOT,photo='out')):
            await self.update(f.message('@NexoraTestBot Добавь рядом куклу',reply=f.message('',mid=90,uid=f.BOT,photo='room')))
            self.app.rate.clear()
            await self.update(f.message('@NexoraTestBot Сделай изображение по этому запросу',mid=2),2)
        self.assertEqual([c.args[1] for c in down.await_args_list],['room','room'])
        self.assertIn('куклу',str(self.net.images()[-1]));self.assertIn(f.DATA,str(self.net.images()[-1]))
    async def test_missing_original_no_paid_work(self):
        await self.update(f.message('@NexoraTestBot Добавь рядом с фурри куклу'))
        self.assertFalse(self.net.paid());self.assertIn('фотографию',self.net.sends()[-1]['text'])
    async def test_unlinked_followup_asks_source(self):
        await self.update(f.message('@NexoraTestBot Сделай изображение по этому запросу'))
        self.assertFalse(self.net.paid());self.assertIn('фотографию',self.net.sends()[-1]['text'])
    async def test_download_failure_no_generation_and_no_quota_used(self):
        with patch.object(n,'download_photo',new_callable=AsyncMock,side_effect=n.Fault('media','image_download_failed')):
            await self.update(f.message('@NexoraTestBot Добавь рядом куклу',photo='room'))
        self.assertFalse(self.net.images());self.assertEqual(n.quota_stats(self.db,f.CID),{'used':0,'held':0})
    async def test_initiative_nonquestion_and_caps(self):
        a=n.tick_activity(self.db,f.CID);self.db.c.execute('UPDATE nexora_activity SET messages=20')
        a=n.tick_activity(self.db,f.CID)
        m=f.message('Вот это смешная и абсурдная история про наш проект, который опять сломался')
        self.assertTrue(n.initiative_candidate(m,a))
        self.net.gate='respond';await self.update(m)
        self.assertFalse(self.net.images());self.assertTrue(self.net.sends())
        self.app.rate.clear();await self.update(f.message(m['text'],mid=2),2)
        self.assertEqual(len(self.net.sends()),1)
    async def test_initiative_disabled(self):
        self.db.group(f.CID,initiative=False);self.db.c.execute('INSERT INTO nexora_activity(chat_id,day,messages) VALUES(?,?,99)',(f.CID,n.quota_day()))
        await self.update(f.message('Смешная и абсурдная история нашего проекта опять произошла сегодня'))
        self.assertFalse(self.net.paid())
    async def test_style_three_modes_survive_payload_and_restart(self):
        for v in ('off','moderate','context'):
            await self.app.operate(f.UID,{'c':f.CID,'op':'style','key':'profanity','value':v})
            await self.app.brain.answer(f.CID,{'question':'Нексора, ты тупая'})
            self.assertIn(n.style_option(self.db.group(f.CID)[1],'profanity')[2],self.net.paid()[-1]['messages'][0]['content'])
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(n.style_value(self.db.group(f.CID)[1],'profanity'),'context')
    async def test_social_rules_stable_under_model_switch(self):
        before=n.build_system(self.db.group(f.CID)[1])
        self.db.group(f.CID,main_model='google/gemini-2.5-flash-lite')
        self.assertEqual(before,n.build_system(self.db.group(f.CID)[1]));self.assertIn(n.SOCIAL_RULES,before)
    async def test_reset_uses_utc_actual_time(self):
        self.assertEqual(n.reset_wait(datetime(2026,10,30,20,36,tzinfo=timezone.utc)),'3 ч 24 мин')
    async def test_user_group_quota_messages_distinct(self):
        n.image_policy(self.db,f.CID);self.db.c.execute('UPDATE image_policy SET user_cap=2')
        self.assertIn('Твой',n.image_limit_message(self.db,f.CID,f.UID,'user_image_limit'))
        self.assertIn('этой группы',n.image_limit_message(self.db,f.CID,f.UID,'group_image_limit'))
    async def test_pending_edit_personal_erasure(self):
        self.db.c.execute('INSERT INTO nexora_edit_tasks VALUES(?,?,?,?,?,?)',(f.CID,f.UID,1,'room','Правка',n.time.time()+600))
        await self.app.operate(f.UID,{'op':'erase'})
        self.assertIsNone(self.db.one('SELECT * FROM nexora_edit_tasks'))
if __name__=='__main__':unittest.main()
