"""1.0.10 offline pipeline/storage tests, not live model-quality tests."""
import json
import sqlite3
import unittest
from pathlib import Path
from unittest.mock import AsyncMock,patch
import test_nexora as f
import test_update103 as multi
n=f.n

class Recovery110(unittest.IsolatedAsyncioTestCase):
    fixture_setup=f.BotTests.setUp
    setUp=multi.MultiIntentTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def image(self,text,reply=None,document=False,mid=1):
        m=f.message('@NexoraTestBot '+text,mid=mid,reply=reply)
        if document:m['document']={'file_id':'document-source','mime_type':'image/png','file_size':len(f.PNG)}
        with patch.object(n,'download_photo',new_callable=AsyncMock,return_value=f.DATA) as down,patch.object(n,'send_image',new_callable=AsyncMock,return_value=f.message('',mid=200+mid,uid=f.BOT,photo='result-'+str(mid))) as send:
            await self.update(m,mid)
        return down,send
    def remember(self,text,value='Решили выпускать проект Nexora каждую пятницу',kind='decision',supersedes=None,mid=1):
        self.db.group(f.CID,archive=True)
        m=f.message(text,mid=mid);self.db.put(m,self.db.group(f.CID)[1],True)
        row=self.db.one('SELECT * FROM messages WHERE chat_id=? AND message_id=?',(f.CID,mid))
        self.app.brain.remember(f.CID,{'memories':[dict(kind=kind,value=value,message_id=mid,quote=text,confidence=.95,title='План релизов',reason='Согласованное расписание',supersedes=supersedes)]},[row] if row else [],self.db.group(f.CID)[0]['epoch'])
        return self.db.all('SELECT * FROM memories ORDER BY id')
    async def test_new_generation_without_reference(self):
        down,send=await self.image('Нарисуй кота на диване')
        down.assert_not_awaited();send.assert_awaited_once()
        self.assertFalse(any(p['type']=='image_url' for p in self.net.images()[0]['messages'][1]['content']))
    async def test_photo_reply_edit_actual_payload(self):
        down,send=await self.image('Добавь рядом куклу',f.message('',uid=f.BOT,mid=99,photo='room'))
        down.assert_awaited_once_with(self.app,'room')
        self.assertEqual(self.net.images()[0]['messages'][1]['content'][1]['image_url']['url'],f.DATA)
        self.assertNotIn('добавила',send.await_args.kwargs['caption'].lower())
    async def test_five_chins_is_edit_not_creation(self):
        down,_=await self.image('Сделай как будто у этого человека на фото пять подбородков',f.message('',uid=f.BOT,photo='person'))
        down.assert_awaited_once_with(self.app,'person');self.assertEqual(len(self.net.images()),1)
    async def test_document_edit(self):
        down,_=await self.image('Добавь смешную шляпу, сохрани лицо и фон',document=True)
        down.assert_awaited_once_with(self.app,'document-source');self.assertEqual(len(self.net.images()),1)
    async def test_reply_document(self):
        parent=f.message('',uid=f.BOT);parent['document']={'file_id':'doc','mime_type':'image/jpeg'}
        down,_=await self.image('Замени фон',parent);down.assert_awaited_once_with(self.app,'doc')
    async def test_unsupported_document_no_paid_work(self):
        m=f.message('@NexoraTestBot измени фото');m['document']={'file_id':'pdf','mime_type':'application/pdf'}
        await self.update(m);self.assertFalse(self.net.paid())
    async def test_second_edit_uses_result_and_stores_parent(self):
        await self.image('Добавь куклу',f.message('',mid=90,uid=f.BOT,photo='room'))
        self.app.rate.clear()
        down,_=await self.image('Теперь сделай фон темнее',f.message('',mid=201,uid=f.BOT,photo='result-1'),mid=2)
        down.assert_awaited_once_with(self.app,'result-1')
        r=self.db.one('SELECT * FROM image_versions WHERE message_id=202');self.assertEqual(r['parent_message_id'],201);self.assertEqual(r['operation'],'edit')
    async def test_text_clarification_preserves_task(self):
        await self.image('Добавь куклу',f.message('',mid=90,uid=f.BOT,photo='room'))
        self.app.rate.clear();down,_=await self.image('Да нет, сделай именно изображение',mid=2)
        down.assert_awaited_once_with(self.app,'room');self.assertIn('куклу',str(self.net.images()[-1]))
    async def test_missing_source_never_paid(self):
        await self.image('Сделай как будто у этого человека на фото пять подбородков')
        self.assertFalse(self.net.paid());self.assertEqual(n.quota_stats(self.db,f.CID),{'used':0,'held':0})
    async def test_missing_telegram_file_no_generation(self):
        with patch.object(n,'download_photo',new_callable=AsyncMock,side_effect=n.Fault('media','image_download_failed')):
            await self.update(f.message('@NexoraTestBot Замени фон',photo='lost'))
        self.assertFalse(self.net.images());self.assertEqual(n.quota_stats(self.db,f.CID)['held'],0)
    async def test_billing404_bounded_and_no_refund(self):
        rid=self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(1,'image','x',?,.04,1,'done',0,0,'','gen-test')",(n.time.time()-100,)).lastrowid
        call=AsyncMock(side_effect=n.Fault('HTTP','404',status=404,operation='OpenRouter.generation'))
        with patch.object(self.net,'call',call):
            for _ in range(8):
                self.app.brain.next_reconcile=0;self.db.c.execute('UPDATE billing_checks SET next_try=0')
                await n.reconcile_usage(self.app.brain)
        self.assertEqual(call.await_count,3);self.assertEqual(self.db.one('SELECT cost FROM usage WHERE id=?',(rid,))['cost'],.04)
    async def test_memory_useful_decision_structured(self):
        r=self.remember('Решили выпускать проект Nexora каждую пятницу после проверки тестов')[0]
        self.assertEqual(r['status'],'pending');self.assertEqual(r['title'],'План релизов');self.assertTrue(r['event_date']);self.assertEqual(json.loads(r['sources'])[0]['user_id'],f.UID)
    async def test_memory_jokes_rejected(self):
        for i,text in enumerate(['Оператор идёт бухать и сегодня не хочет ничего делать','Простите, я трахнул вашу жену, это просто шутка','Я люблю мультик про кота в космосе и другие истории'],1):
            self.assertFalse(self.remember(text,mid=i))
    async def test_memory_emotional_noise_rejected(self):
        self.assertFalse(self.remember('ААААААААААААААААААААААААААААААА'))
    async def test_memory_quote_not_fact(self):
        self.assertFalse(self.remember('Цитата: «Решили выпускать проект Nexora каждую пятницу»'))
    async def test_memory_hypothesis_not_decision(self):
        self.assertFalse(self.remember('Возможно, решили выпускать проект Nexora каждую пятницу'))
    async def test_memory_contact_filtered(self):
        for i,t in enumerate(['Решили отправлять отчёты проекта по адресу hello@example.com','Решили записать телефон участника +7 (999) 123-45-67','Решили обсудить диагноз участника и его лечение завтра'],1):self.assertFalse(self.remember(t,mid=i))
    async def test_memory_deduplication(self):
        text='Решили выпускать проект Nexora каждую пятницу после проверки тестов'
        self.remember(text);self.remember(text,mid=2);self.assertEqual(len(self.db.all('SELECT * FROM memories')),1)
    async def test_memory_update_pending_then_admin_confirmation(self):
        first=self.remember('Решили выпускать проект Nexora каждую пятницу после проверки тестов')[0]
        await self.app.operate(f.UID,{'c':f.CID,'op':'memory_confirm','id':first['id']})
        rows=self.remember('Решили выпускать проект Nexora каждую субботу после проверки тестов',value='Решили выпускать проект Nexora каждую субботу',supersedes=first['id'],mid=2)
        self.assertEqual(len(rows),2);self.assertEqual(rows[0]['status'],'confirmed');self.assertEqual(rows[1]['status'],'pending')
        await self.app.operate(f.UID,{'c':f.CID,'op':'memory_confirm','id':rows[1]['id']})
        self.assertEqual(self.db.one('SELECT status FROM memories WHERE id=?',(first['id'],))['status'],'superseded')
    async def test_memory_groups_isolated(self):
        self.remember('Решили выпускать проект Nexora каждую пятницу после проверки тестов')
        self.assertFalse(self.db.all('SELECT * FROM memories WHERE chat_id=?',(f.CID-1,)))
    async def test_memory_confirmation_requires_admin(self):
        r=self.remember('Решили выпускать проект Nexora каждую пятницу после проверки тестов')[0];self.net.status='member'
        with self.assertRaises(n.Fault):await self.app.operate(f.UID,{'c':f.CID,'op':'memory_confirm','id':r['id']})
        self.assertEqual(self.db.one('SELECT status FROM memories')['status'],'pending')
    async def test_delete_candidate(self):
        r=self.remember('Решили выпускать проект Nexora каждую пятницу после проверки тестов')[0]
        await self.app.operate(f.UID,{'c':f.CID,'op':'memory_delete','id':r['id']});self.assertFalse(self.db.all('SELECT * FROM memories'))
    async def test_no_paid_background_for_noise(self):
        self.db.group(f.CID,archive=True)
        for i in range(5):self.db.put(f.message('Оператор идёт бухать и больше не хочет сегодня работать',mid=i),self.db.group(f.CID)[1])
        await self.app.batch(f.CID,True);self.assertFalse(self.net.paid())
    async def test_memory_modes_persist_without_restarting(self):
        for label,expected in n.MEMORY_MODES.items():
            await self.app.operate(f.UID,{'c':f.CID,'op':'memory_mode','value':label})
            cfg=self.db.group(f.CID)[1];self.assertEqual((cfg['threshold'],cfg['interval_minutes']),expected)
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db);self.assertEqual(self.db.group(f.CID)[1]['threshold'],5)
    async def test_user_group_limits_independent_and_persist(self):
        n.image_policy(self.db,f.CID)
        self.db.c.execute('UPDATE image_policy SET user_cap=5,daily_cap=30 WHERE chat_id=?',(f.CID,))
        for key,value in [('user_cap',5),('daily_cap',30)]:
            with self.assertRaises(n.Fault):await self.app.operate(f.UID,{'c':f.CID,'op':'image_policy','key':key,'value':value})
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(n.image_policy(self.db,f.CID)['user_cap'],5);self.assertEqual(n.image_policy(self.db,f.CID)['daily_cap'],30)
    async def test_panel_no_technical_memory_controls(self):
        await self.app.panel(f.UID,{'v':'settings','c':f.CID});self.assertNotIn('Порог сообщений',str(self.net.sends()[-1]))
        await self.app.panel(f.UID,{'v':'memory_settings','c':f.CID});self.assertIn('Экономно',str(self.net.sends()[-1]))
    async def test_user_limit_disable_preserves_money_budget(self):
        before=self.db.group(f.CID)[1]['daily_budget']
        with self.assertRaises(n.Fault):await self.app.operate(f.UID,{'c':f.CID,'op':'image_policy','key':'user_cap','value':None})
        self.assertEqual(self.db.group(f.CID)[1]['daily_budget'],before)
    async def test_migration_backup_preserves_old_data(self):
        path=Path(self.temp.name)/'legacy.db';old=n.Store(path)
        old.c.execute("INSERT INTO single_meta VALUES('application','Nexora')");old.group(f.CID,'Old',archive=True,threshold=50)
        old.put(f.message('Случайная старая шутка в архиве группы'),old.group(f.CID)[1]);n.prepare_store(old)
        backup=path.with_name(path.name+'.pre-1.0.10.bak');self.assertTrue(backup.exists())
        self.assertEqual(old.group(f.CID)[1]['threshold'],50);self.assertEqual(len(old.all('SELECT * FROM messages')),1)
        before=backup.stat().st_mtime_ns;n.prepare_store(old);self.assertEqual(backup.stat().st_mtime_ns,before)
        with sqlite3.connect(backup) as b:self.assertEqual(b.execute('SELECT count(*) FROM messages').fetchone()[0],1)
        old.c.close()
    async def test_invalid_image_bytes_rejected(self):
        with self.assertRaises(n.Fault):n.image_bytes('data:image/png;base64,bm90LWltYWdl')
    async def test_model_configuration_unchanged(self):
        before={k:v for k,v in self.db.group(f.CID)[1].items() if k.endswith('_model')}
        n.prepare_store(self.db);self.assertEqual(before,{k:v for k,v in self.db.group(f.CID)[1].items() if k.endswith('_model')})
    async def test_source_is_not_telegram_secret_url(self):
        await self.image('Замени фон',f.message('',mid=90,uid=f.BOT,photo='room'))
        self.assertNotIn(f.TOKEN,str(self.net.images()));self.assertIn('data:image/png;base64,',str(self.net.images()))
    async def test_numeric_changes_not_deduplicated(self):
        self.assertEqual(n.memory_similarity(set('лимит проекта 5 изображений в день'.split()),set('лимит проекта 10 изображений в день'.split())),0)
    async def test_optout_no_lineage_persistence(self):
        self.db.c.execute('INSERT INTO privacy VALUES(?,1)',(f.UID,))
        await self.image('Замени фон',f.message('',mid=90,uid=f.BOT,photo='room'))
        self.assertFalse(self.db.all('SELECT * FROM image_versions'));self.assertFalse(self.db.all('SELECT * FROM nexora_edit_tasks'))
    async def test_memory_economy_threshold_uses_queue_not_batch_size(self):
        self.db.group(f.CID,archive=True,threshold=50,interval_minutes=120)
        for mid in range(50):self.db.put(f.message('Решили выпускать проект Nexora каждую пятницу после проверки тестов',mid=mid),self.db.group(f.CID)[1])
        await self.app.batch(f.CID)
        self.assertEqual(len(self.net.paid()),1)
        self.assertEqual(self.db.one("SELECT count(*) n FROM messages WHERE queue_state='done'")['n'],40)
    async def test_document_too_large_no_paid_classifier(self):
        m=f.message('@NexoraTestBot Добавь шляпу');m['document']={'file_id':'large','mime_type':'image/png','file_size':8000001}
        await self.update(m);self.assertFalse(self.net.paid())
    async def test_billing_backoff_not_polled_again_immediately(self):
        self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(1,'image','x',?,.04,1,'done',0,0,'','gen-backoff')",(n.time.time()-100,))
        call=AsyncMock(side_effect=n.Fault('HTTP','404',status=404))
        with patch.object(self.net,'call',call):
            await n.reconcile_usage(self.app.brain)
            for _ in range(4):
                self.app.brain.next_reconcile=0;self.app.brain.reconcile_cursor=0
                await n.reconcile_usage(self.app.brain)
        self.assertEqual(call.await_count,1)
    async def test_invalid_reference_no_reservation_or_paid_call(self):
        with self.assertRaises(n.Fault):await n.generate_image(self.app.brain,f.CID,'Правка',['https://example.com/not-actual-bytes'])
        self.assertFalse(self.net.paid());self.assertFalse(self.db.all('SELECT * FROM usage'))
    async def test_short_decision_is_not_lost(self):
        self.assertTrue(n.memory_source_eligible('Решили: релиз в пятницу.'))
    async def test_project_name_quotes_are_not_a_reported_quote(self):
        self.assertTrue(n.memory_source_eligible('Решили назвать проект «Нексора» и выпускать его по пятницам.'))
if __name__=='__main__':unittest.main()
