"""Compact SQLAlchemy repository: PostgreSQL or durable single-container SQLite."""

import asyncio
import hashlib
import re
import secrets
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

import snowballstemmer
from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Float,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    delete,
    event,
    func,
    or_,
    select,
    text,
    update,
)
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from ai import BudgetError

_stemming = threading.local()


def fts_normalize(value: str) -> str:
    """The same Russian Snowball stemming is applied at index and query time."""
    if not hasattr(_stemming, "russian"):
        _stemming.russian = snowballstemmer.stemmer("russian")
    words = re.findall(r"[^\W_]+", value.lower(), flags=re.UNICODE)
    return " ".join(_stemming.russian.stemWords(words))


class Base(DeclarativeBase):
    pass


class Group(Base):
    __tablename__ = "groups"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    title: Mapped[str] = mapped_column(String(255))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    settings: Mapped[dict] = mapped_column(JSON, default=dict)
    epoch: Mapped[int] = mapped_column(Integer, default=0)
    last_background: Mapped[float] = mapped_column(Float, default=0)
    worker_until: Mapped[float] = mapped_column(Float, default=0)
    worker_token: Mapped[str] = mapped_column(String(64), default="")
    diagnostic: Mapped[str] = mapped_column(String(500), default="")


class Participant(Base):
    __tablename__ = "participants"
    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    preferences: Mapped[dict] = mapped_column(JSON, default=dict)


class Privacy(Base):
    __tablename__ = "privacy"
    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    opted_out: Mapped[bool] = mapped_column(Boolean, default=False)


class ArchiveMessage(Base):
    __tablename__ = "messages"
    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    message_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    date: Mapped[float] = mapped_column(Float)
    text: Mapped[str] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(24), default="text")
    reply_to: Mapped[int | None] = mapped_column(BigInteger)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    permanent: Mapped[bool] = mapped_column(Boolean, default=False)
    expires_at: Mapped[float] = mapped_column(Float)
    queue_state: Mapped[str] = mapped_column(String(20), default="skip")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    retry_at: Mapped[float] = mapped_column(Float, default=0)
    __table_args__ = (
        Index("ix_message_chat_date", "chat_id", "date"),
        Index("ix_message_queue", "chat_id", "queue_state", "retry_at"),
        Index("ix_message_reply", "chat_id", "reply_to"),
    )


class Memory(Base):
    __tablename__ = "memories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    kind: Mapped[str] = mapped_column(String(24))
    value: Mapped[str] = mapped_column(Text)
    fingerprint: Mapped[str] = mapped_column(String(64))
    subject_ids: Mapped[list] = mapped_column(JSON, default=list)
    sources: Mapped[list] = mapped_column(JSON)
    confidence: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    created: Mapped[float] = mapped_column(Float)
    event_date: Mapped[str] = mapped_column(String(10), default="")
    valid_until: Mapped[float] = mapped_column(Float)
    embedding: Mapped[list | None] = mapped_column(JSON)
    embedding_model: Mapped[str] = mapped_column(String(255), default="")
    __table_args__ = (UniqueConstraint("chat_id", "fingerprint"),)


class Dialogue(Base):
    __tablename__ = "dialogues"
    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    message_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # bot reply
    owner_id: Mapped[int] = mapped_column(BigInteger)
    chain: Mapped[list] = mapped_column(JSON)
    expires_at: Mapped[float] = mapped_column(Float)


class Usage(Base):
    __tablename__ = "usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    purpose: Mapped[str] = mapped_column(String(20))
    model: Mapped[str] = mapped_column(String(255))
    created: Mapped[float] = mapped_column(Float, index=True)
    cost: Mapped[Decimal] = mapped_column(Numeric(18, 10))
    estimated: Mapped[bool] = mapped_column(Boolean, default=True)
    state: Mapped[str] = mapped_column(String(20), default="reserved")
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str] = mapped_column(String(80), default="")
    generation_id: Mapped[str] = mapped_column(String(200), default="")


class PanelToken(Base):
    __tablename__ = "panel_tokens"
    token: Mapped[str] = mapped_column(String(32), primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    action: Mapped[dict] = mapped_column(JSON)
    expires: Mapped[float] = mapped_column(Float)


class InputState(Base):
    __tablename__ = "input_states"
    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    action: Mapped[dict] = mapped_column(JSON)
    expires: Mapped[float] = mapped_column(Float)


class Favorite(Base):
    __tablename__ = "favorites"
    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    model_id: Mapped[str] = mapped_column(String(255), primary_key=True)


class Receipt(Base):
    __tablename__ = "update_receipts"
    update_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    expires: Mapped[float] = mapped_column(Float)


class Rate(Base):
    __tablename__ = "rate_limits"
    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    until: Mapped[float] = mapped_column(Float)


def message_dict(row: ArchiveMessage) -> dict:
    return {
        "id": row.message_id,
        "user_id": row.user_id,
        "date": datetime.fromtimestamp(row.date, ZoneInfo("UTC")).isoformat(),
        "text": row.text,
        "reply_to": row.reply_to,
        "kind": row.kind,
        "link": message_link(row.chat_id, row.message_id, row.metadata_json.get("username")),
    }


def message_link(chat_id: int, message_id: int, username: str | None = None) -> str:
    if username:
        return f"https://t.me/{username}/{message_id}"
    if str(chat_id).startswith("-100"):
        return f"https://t.me/c/{str(chat_id)[4:]}/{message_id}"
    return ""  # Basic groups do not have message permalinks.


class Database:
    def __init__(self, config):
        self.config = config
        url = make_url(config.database_url)
        self.pg = url.get_backend_name() == "postgresql"
        connect_args = {}
        if self.pg and "sslmode" in url.query:
            query = dict(url.query)
            connect_args["ssl"] = query.pop("sslmode")
            url = url.set(query=query)
        if not self.pg:
            if url.database and url.database != ":memory:":
                Path(url.database).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)
            connect_args["timeout"] = 30
        self.engine = create_async_engine(url, pool_pre_ping=True, connect_args=connect_args)
        self.sessions = async_sessionmaker(self.engine, expire_on_commit=False)
        if not self.pg:

            @event.listens_for(self.engine.sync_engine, "connect")
            def unicode_lower(connection, _record):
                # SQLite's builtin lower() only handles ASCII.
                connection.create_function(
                    "lower", 1, lambda value: value.lower() if isinstance(value, str) else value
                )
                connection.create_function("jarvis_fts", 1, fts_normalize)
                cursor = connection.cursor()
                cursor.execute("PRAGMA busy_timeout=30000")
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA synchronous=FULL")
                cursor.close()

        self._sqlite_lock = asyncio.Lock()

    def insert(self, table):
        return pg_insert(table) if self.pg else sqlite_insert(table)

    @asynccontextmanager
    async def transaction(self, global_lock=False):
        # PostgreSQL advisory transaction lock serializes application-wide monetary reservations.
        if not self.pg:
            await self._sqlite_lock.acquire()
        try:
            async with self.sessions.begin() as session:
                if global_lock and self.pg:
                    await session.execute(text("SELECT pg_advisory_xact_lock(74392001)"))
                elif not self.pg:
                    # FOR UPDATE is ignored by SQLite. A real write transaction serializes claims,
                    # callbacks and budgets across connections/processes before any state is read.
                    await session.execute(text("BEGIN IMMEDIATE"))
                yield session
        finally:
            if not self.pg:
                self._sqlite_lock.release()

    async def initialize(self):
        async with self.engine.begin() as conn:
            if self.pg:
                await conn.execute(text("SELECT pg_advisory_xact_lock(74392002)"))
            else:
                await conn.exec_driver_sql("PRAGMA journal_mode=WAL")
                await conn.exec_driver_sql("BEGIN IMMEDIATE")
            await conn.run_sync(Base.metadata.create_all)
            if self.pg:
                await conn.execute(
                    text(
                        "CREATE INDEX IF NOT EXISTS ix_message_fts ON messages USING gin "
                        "(to_tsvector('russian'::regconfig, text))"
                    )
                )
            else:
                existed = await conn.scalar(text("SELECT name FROM sqlite_master WHERE name='messages_fts'"))
                await conn.exec_driver_sql(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5("
                    "text, content='messages', content_rowid='rowid', tokenize='unicode61', prefix='2 3 4')"
                )
                if not existed:
                    await conn.exec_driver_sql(
                        "INSERT INTO messages_fts(rowid, text) SELECT rowid, jarvis_fts(text) FROM messages"
                    )
                for statement in (
                    "CREATE TRIGGER IF NOT EXISTS messages_fts_insert AFTER INSERT ON messages BEGIN "
                    "INSERT INTO messages_fts(rowid,text) VALUES(new.rowid,jarvis_fts(new.text)); END",
                    "CREATE TRIGGER IF NOT EXISTS messages_fts_delete AFTER DELETE ON messages BEGIN "
                    "INSERT INTO messages_fts(messages_fts,rowid,text) VALUES('delete',old.rowid,jarvis_fts(old.text)); END",
                    "CREATE TRIGGER IF NOT EXISTS messages_fts_update AFTER UPDATE OF text ON messages BEGIN "
                    "INSERT INTO messages_fts(messages_fts,rowid,text) VALUES('delete',old.rowid,jarvis_fts(old.text)); "
                    "INSERT INTO messages_fts(rowid,text) VALUES(new.rowid,jarvis_fts(new.text)); END",
                ):
                    await conn.exec_driver_sql(statement)
        # Schema v1. Subsequent incompatible changes must use an explicit migration.

    async def close(self):
        await self.engine.dispose()

    async def ensure_group(self, chat_id: int, title: str):
        async with self.transaction() as s:
            stmt = self.insert(Group).values(
                id=chat_id, title=title[:255], active=True, settings=self.config.group_defaults()
            )
            await s.execute(
                stmt.on_conflict_do_update(index_elements=["id"], set_={"title": title[:255], "active": True})
            )

    async def group(self, chat_id: int) -> tuple[Group, dict]:
        async with self.sessions() as s:
            group = await s.get(Group, chat_id)
            if not group:
                raise ValueError("Группа неизвестна боту")
            return group, self.config.group_defaults() | group.settings

    async def groups(self) -> list[Group]:
        async with self.sessions() as s:
            return list((await s.scalars(select(Group).where(Group.active).order_by(Group.title))).all())

    async def set_active(self, chat_id: int, active: bool):
        async with self.transaction() as s:
            await s.execute(
                update(Group)
                .where(Group.id == chat_id)
                .values(active=active, worker_until=0, epoch=Group.epoch + 1)
            )

    async def settings(self, chat_id: int, **changes) -> dict:
        async with self.transaction() as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            if group is None:
                raise ValueError("Группа неизвестна")
            values = self.config.group_defaults() | group.settings | changes
            group.settings = values
            if "archive" in changes or "retention_days" in changes:
                group.epoch += 1
                if "retention_days" in changes:
                    for row in (
                        await s.scalars(
                            select(ArchiveMessage).where(
                                ArchiveMessage.chat_id == chat_id, ArchiveMessage.permanent
                            )
                        )
                    ).all():
                        row.expires_at = min(row.expires_at, row.date + values["retention_days"] * 86400)
                    for row in (await s.scalars(select(Memory).where(Memory.chat_id == chat_id))).all():
                        row.valid_until = min(row.valid_until, row.created + values["retention_days"] * 86400)
                if not values["archive"]:
                    await s.execute(
                        update(ArchiveMessage)
                        .where(
                            ArchiveMessage.chat_id == chat_id,
                            ArchiveMessage.queue_state.in_(["pending", "processing"]),
                        )
                        .values(queue_state="skip")
                    )
            return values

    async def diagnostic(self, chat_id: int, code: str):
        async with self.transaction() as s:
            await s.execute(update(Group).where(Group.id == chat_id).values(diagnostic=code[:500]))

    async def apply_model_default(self, chat_id: int, role: str, model_id: str) -> dict:
        """Fill an unset role without overwriting a concurrently selected administrator model."""
        if role not in {"main", "background"}:
            raise ValueError("Unsupported automatic model role")
        async with self.transaction() as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            if not group:
                raise ValueError("Группа неизвестна")
            values = self.config.group_defaults() | group.settings
            key = role + "_model"
            if not values[key]:
                values[key] = model_id
                group.settings = values
            return values

    async def is_opted_out(self, user_id: int) -> bool:
        async with self.sessions() as s:
            row = await s.get(Privacy, user_id)
            return bool(row and row.opted_out)

    async def opt_in(self, user_id: int):
        async with self.transaction() as s:
            await s.execute(delete(Privacy).where(Privacy.user_id == user_id))

    async def preferences(self, chat_id: int, user_id: int, changes: dict | None = None) -> dict:
        async with self.transaction(global_lock=True) as s:
            privacy = await s.get(Privacy, user_id)
            if privacy and privacy.opted_out:
                return {}
            row = await s.get(Participant, (chat_id, user_id))
            if not row:
                row = Participant(chat_id=chat_id, user_id=user_id, preferences={})
                s.add(row)
            if changes is not None:
                row.preferences = row.preferences | changes
            return row.preferences

    async def resolve_nickname(self, chat_id: int, query: str) -> tuple[int | None, str]:
        async with self.sessions() as s:
            rows = (await s.scalars(select(Participant).where(Participant.chat_id == chat_id))).all()
            found = [
                (p.user_id, p.preferences.get("nickname", ""))
                for p in rows
                if p.preferences.get("nickname") and p.preferences["nickname"].lower() in query.lower()
            ]
            return found[0] if len(found) == 1 else (None, "")

    async def store_message(
        self,
        chat_id: int,
        message_id: int,
        user_id: int,
        date: float,
        body: str,
        kind: str,
        reply_to: int | None,
        metadata: dict,
        invoked: bool = False,
        meaningful: bool = False,
        requester_id: int | None = None,
        expected_epoch: int | None = None,
    ) -> bool:
        async with self.transaction(global_lock=True) as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            privacy = await s.get(Privacy, user_id)
            if not group or not group.active or (privacy and privacy.opted_out):
                return False
            if expected_epoch is not None and group.epoch != expected_epoch:
                return False
            if requester_id is not None:
                requester = await s.get(Privacy, requester_id)
                if requester and requester.opted_out:
                    return False
                metadata = metadata | {"requester_id": requester_id}
            values = self.config.group_defaults() | group.settings
            permanent = values["archive"]
            if not permanent and not invoked:
                return False
            queued = "skip"
            if permanent and values["background"] and meaningful:
                count = await s.scalar(
                    select(func.count())
                    .select_from(ArchiveMessage)
                    .where(
                        ArchiveMessage.chat_id == chat_id,
                        ArchiveMessage.queue_state.in_(["pending", "processing"]),
                    )
                )
                queued = "pending" if count < self.config.queue_max_size else "overflow"
            expiry = date + (
                values["retention_days"] * 86400 if permanent else self.config.transient_hours * 3600
            )
            stmt = self.insert(ArchiveMessage).values(
                chat_id=chat_id,
                message_id=message_id,
                user_id=user_id,
                date=date,
                text=body[:16000],
                kind=kind,
                reply_to=reply_to,
                metadata_json=metadata,
                permanent=permanent,
                expires_at=expiry,
                queue_state=queued,
                attempts=0,
                retry_at=0,
            )
            result = await s.execute(stmt.on_conflict_do_nothing(index_elements=["chat_id", "message_id"]))
            return bool(result.rowcount)

    async def edit_message(self, chat_id: int, message_id: int, body: str):
        async with self.transaction() as s:
            await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            row = await s.get(ArchiveMessage, (chat_id, message_id))
            if row:
                row.text = body[:16000]
                row.queue_state = "pending" if row.permanent else "skip"
                # Conservative invalidation: avoids trusting facts derived from outdated quotes.
                await s.execute(delete(Memory).where(Memory.chat_id == chat_id))
                await s.execute(update(Group).where(Group.id == chat_id).values(epoch=Group.epoch + 1))

    async def messages(
        self,
        chat_id: int,
        ids: list[int] | None = None,
        limit: int = 200,
        since: float | None = None,
        until: float | None = None,
        user_id: int | None = None,
    ) -> list[ArchiveMessage]:
        async with self.sessions() as s:
            query = select(ArchiveMessage).where(
                ArchiveMessage.chat_id == chat_id, ArchiveMessage.expires_at > time.time()
            )
            if ids is not None:
                query = query.where(ArchiveMessage.message_id.in_(ids))
            if since is not None:
                query = query.where(ArchiveMessage.date >= since)
            if until is not None:
                query = query.where(ArchiveMessage.date < until)
            if user_id is not None:
                query = query.where(ArchiveMessage.user_id == user_id)
            rows = list(
                (
                    await s.scalars(
                        query.order_by(ArchiveMessage.date.desc(), ArchiveMessage.message_id.desc()).limit(
                            limit
                        )
                    )
                ).all()
            )
            return list(reversed(rows))

    async def search(
        self,
        chat_id: int,
        query: str,
        limit: int = 40,
        since: float | None = None,
        until: float | None = None,
        user_id: int | None = None,
    ) -> list[ArchiveMessage]:
        if not query.strip():
            return await self.messages(chat_id, limit=limit, since=since, until=until, user_id=user_id)
        async with self.sessions() as s:
            statement = select(ArchiveMessage).where(
                ArchiveMessage.chat_id == chat_id,
                ArchiveMessage.permanent,
                ArchiveMessage.expires_at > time.time(),
            )
            if self.pg:
                vector = func.to_tsvector(text("'russian'::regconfig"), ArchiveMessage.text)
                terms = func.websearch_to_tsquery(text("'russian'::regconfig"), query[:500])
                statement = statement.where(vector.op("@@")(terms)).order_by(
                    func.ts_rank_cd(vector, terms).desc()
                )
            else:
                tokens = fts_normalize(query[:500]).split()[:12]
                if not tokens:
                    return []
                # SQL parameter binding AND quoted FTS tokens: user input is never FTS syntax.
                fts_query = " OR ".join('"' + token.replace('"', '""') + '"*' for token in tokens)
                statement = statement.where(
                    text(
                        "messages.rowid IN (SELECT rowid FROM messages_fts "
                        "WHERE messages_fts MATCH :fts_query)"
                    )
                ).params(fts_query=fts_query)
            if since is not None:
                statement = statement.where(ArchiveMessage.date >= since)
            if until is not None:
                statement = statement.where(ArchiveMessage.date < until)
            if user_id is not None:
                statement = statement.where(ArchiveMessage.user_id == user_id)
            return list((await s.scalars(statement.order_by(ArchiveMessage.date.desc()).limit(limit))).all())

    async def save_dialogue(
        self, chat_id: int, user_id: int, bot_mid: int, chain: list[int], expected_epoch: int | None = None
    ):
        async with self.transaction(global_lock=True) as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            privacy = await s.get(Privacy, user_id)
            if (
                not group
                or (privacy and privacy.opted_out)
                or (expected_epoch is not None and group.epoch != expected_epoch)
            ):
                return
            stmt = self.insert(Dialogue).values(
                chat_id=chat_id,
                message_id=bot_mid,
                owner_id=user_id,
                chain=list(dict.fromkeys(chain))[-80:],
                expires_at=time.time() + self.config.transient_hours * 3600,
            )
            await s.execute(stmt.on_conflict_do_nothing(index_elements=["chat_id", "message_id"]))

    async def dialogue(self, chat_id: int, user_id: int, reply_id: int | None = None) -> list[int]:
        async with self.sessions() as s:
            q = select(Dialogue).where(
                Dialogue.chat_id == chat_id, Dialogue.owner_id == user_id, Dialogue.expires_at > time.time()
            )
            if reply_id is not None:
                q = q.where(Dialogue.message_id == reply_id)
            row = await s.scalar(q.order_by(Dialogue.message_id.desc()).limit(1))
            return row.chain if row else []

    @staticmethod
    def fingerprint(kind: str, value: str) -> str:
        normalized = " ".join("".join(c.lower() if c.isalnum() else " " for c in value).split())
        return hashlib.sha256(f"{kind}:{normalized}".encode()).hexdigest()

    async def save_memories(self, chat_id: int, candidates: list[dict], epoch: int, session=None) -> int:
        if session is None:
            async with self.transaction() as s:
                return await self.save_memories(chat_id, candidates, epoch, s)
        s = session
        group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
        if not group or group.epoch != epoch or not group.active or not group.settings.get("archive"):
            return 0
        count = 0
        for candidate in candidates:
            subjects = candidate["subject_ids"]
            if subjects and await s.scalar(
                select(func.count())
                .select_from(Privacy)
                .where(Privacy.user_id.in_(subjects), Privacy.opted_out)
            ):
                continue
            values = dict(
                candidate,
                chat_id=chat_id,
                created=time.time(),
                status="pending",
                fingerprint=self.fingerprint(candidate["kind"], candidate["value"]),
                valid_until=time.time() + group.settings.get("retention_days", 90) * 86400,
            )
            stmt = self.insert(Memory).values(**values)
            result = await s.execute(stmt.on_conflict_do_nothing(index_elements=["chat_id", "fingerprint"]))
            count += result.rowcount
        return count

    async def memories(
        self, chat_id: int, status: str | None = "confirmed", query: str = "", limit: int = 100
    ) -> list[Memory]:
        async with self.sessions() as s:
            statement = select(Memory).where(Memory.chat_id == chat_id, Memory.valid_until > time.time())
            if status:
                statement = statement.where(Memory.status == status)
            if query:
                statement = statement.where(func.lower(Memory.value).contains(query.lower(), autoescape=True))
            return list((await s.scalars(statement.order_by(Memory.id.desc()).limit(limit))).all())

    async def memory_action(self, chat_id: int, memory_id: int, approve: bool):
        async with self.transaction() as s:
            await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            row = await s.get(Memory, memory_id)
            if not row or row.chat_id != chat_id:
                raise ValueError("Запись больше недоступна")
            if row.subject_ids and approve:
                raise ValueError(
                    "Персональные кандидаты может подтвердить только сам участник в «Личные данные»."
                )
            if approve:
                row.status = "confirmed"
            else:
                await s.delete(row)
            await s.execute(update(Group).where(Group.id == chat_id).values(epoch=Group.epoch + 1))

    async def set_embedding(self, chat_id: int, mid: int, model: str, vector: list):
        async with self.transaction() as s:
            await s.execute(
                update(Memory)
                .where(Memory.id == mid, Memory.chat_id == chat_id)
                .values(embedding=vector, embedding_model=model)
            )

    async def stats(self, chat_id: int) -> dict:
        async with self.sessions() as s:
            messages = dict(
                (
                    await s.execute(
                        select(ArchiveMessage.queue_state, func.count())
                        .where(ArchiveMessage.chat_id == chat_id, ArchiveMessage.expires_at > time.time())
                        .group_by(ArchiveMessage.queue_state)
                    )
                ).all()
            )
            memories = dict(
                (
                    await s.execute(
                        select(Memory.kind, func.count())
                        .where(Memory.chat_id == chat_id, Memory.valid_until > time.time())
                        .group_by(Memory.kind)
                    )
                ).all()
            )
            return {
                "messages": sum(messages.values()),
                "queue": messages,
                "memories": memories,
                "memory_total": sum(memories.values()),
            }

    async def clear(self, chat_id: int):
        async with self.transaction() as s:
            await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            for table in (ArchiveMessage, Memory, Dialogue):
                await s.execute(delete(table).where(table.chat_id == chat_id))
            await s.execute(
                update(Group).where(Group.id == chat_id).values(epoch=Group.epoch + 1, worker_until=0)
            )

    async def personal_data(self, user_id: int) -> dict:
        async with self.sessions() as s:
            prefs = (await s.scalars(select(Participant).where(Participant.user_id == user_id))).all()
            messages = (
                await s.scalars(select(ArchiveMessage).where(ArchiveMessage.user_id == user_id))
            ).all()
            # Derived memory can include other participants: own-subject records only.
            memories = (await s.scalars(select(Memory))).all()
            return {
                "user_id": user_id,
                "opted_out": await self.is_opted_out(user_id),
                "preferences": [{"chat_id": p.chat_id, "values": p.preferences} for p in prefs],
                "messages": [{"chat_id": m.chat_id, **message_dict(m)} for m in messages],
                "memories": [
                    {"id": m.id, "chat_id": m.chat_id, "value": m.value, "status": m.status}
                    for m in memories
                    if m.subject_ids == [user_id]
                ],
            }

    async def personal_memory(self, user_id: int, memory_id: int):
        async with self.transaction() as s:
            row = await s.get(Memory, memory_id)
            if not row or row.subject_ids != [user_id]:
                raise ValueError("Это не ваша персональная запись")
            row.status = "confirmed"

    async def erase_user(self, user_id: int):
        async with self.transaction(global_lock=True) as s:
            affected = set(
                (
                    await s.scalars(
                        select(ArchiveMessage.chat_id).where(
                            or_(
                                ArchiveMessage.user_id == user_id,
                                ArchiveMessage.metadata_json["requester_id"].as_integer() == user_id,
                            )
                        )
                    )
                ).all()
            )
            affected.update(
                (await s.scalars(select(Participant.chat_id).where(Participant.user_id == user_id))).all()
            )
            for memory in (await s.scalars(select(Memory))).all():
                if user_id in memory.subject_ids or any(
                    src.get("user_id") == user_id for src in memory.sources
                ):
                    affected.add(memory.chat_id)
            # Lock groups before derived rows, matching worker/memory mutation lock order.
            await s.execute(select(Group).where(Group.id.in_(affected)).order_by(Group.id).with_for_update())
            # Conservative purge of derived memory and sessions in affected groups: even unlabelled
            # summaries may contain this user's data. Others' raw archived messages remain intact.
            for cls in (Memory, Dialogue):
                await s.execute(delete(cls).where(cls.chat_id.in_(affected)))
            await s.execute(
                update(Group).where(Group.id.in_(affected)).values(epoch=Group.epoch + 1, worker_until=0)
            )
            await s.execute(
                delete(ArchiveMessage).where(
                    or_(
                        ArchiveMessage.user_id == user_id,
                        ArchiveMessage.metadata_json["requester_id"].as_integer() == user_id,
                    )
                )
            )
            await s.execute(delete(Participant).where(Participant.user_id == user_id))
            await s.execute(delete(Favorite).where(Favorite.user_id == user_id))
            await s.execute(delete(PanelToken).where(PanelToken.user_id == user_id))
            await s.execute(delete(InputState).where(InputState.user_id == user_id))
            stmt = self.insert(Privacy).values(user_id=user_id, opted_out=True)
            await s.execute(stmt.on_conflict_do_update(index_elements=["user_id"], set_={"opted_out": True}))

    def period_starts(self, timezone: str) -> tuple[float, float, float]:
        now = datetime.now(ZoneInfo(timezone))
        day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        return day.timestamp(), (day - timedelta(days=6)).timestamp(), day.replace(day=1).timestamp()

    async def reserve(self, chat_id: int, purpose: str, model: str, amount: Decimal, settings: dict) -> int:
        async with self.transaction(global_lock=True) as s:
            day, _, month = self.period_starts(settings["timezone"])
            app_day, _, app_month = self.period_starts(self.config.default_timezone)

            async def total(since, group=None, background=False):
                q = select(func.coalesce(func.sum(Usage.cost), 0)).where(Usage.created >= since)
                if group is not None:
                    q = q.where(Usage.chat_id == group)
                if background:
                    q = q.where(Usage.purpose.in_(["background", "embedding"]))
                return Decimal(await s.scalar(q))

            checks = [
                (await total(app_day), self.config.daily_budget_usd),
                (await total(app_month), self.config.monthly_budget_usd),
                (await total(day, chat_id), Decimal(settings["daily_budget"])),
                (await total(month, chat_id), Decimal(settings["monthly_budget"])),
            ]
            if purpose in {"background", "embedding"}:
                checks += [
                    (await total(day, chat_id, True), Decimal(settings["background_budget"])),
                    (await total(app_day, background=True), self.config.background_daily_budget_usd),
                ]
            if any(used + amount > limit for used, limit in checks):
                raise BudgetError("Лимит расходов достигнут с учётом незавершённых запросов.")
            row = Usage(chat_id=chat_id, purpose=purpose, model=model, created=time.time(), cost=amount)
            s.add(row)
            await s.flush()
            return row.id

    async def finish_usage(
        self,
        usage_id: int,
        cost: Decimal,
        incoming: int,
        outgoing: int,
        estimated: bool,
        error: str = "",
        generation_id: str = "",
    ):
        async with self.transaction(global_lock=True) as s:
            await s.execute(
                update(Usage)
                .where(Usage.id == usage_id)
                .values(
                    cost=cost,
                    state="finished",
                    estimated=estimated,
                    input_tokens=incoming,
                    output_tokens=outgoing,
                    error=error,
                    generation_id=generation_id,
                )
            )

    async def expenses(self, chat_id: int, timezone: str) -> dict:
        day, week, month = self.period_starts(timezone)
        async with self.sessions() as s:
            rows = (
                await s.scalars(
                    select(Usage).where(Usage.chat_id == chat_id, Usage.created >= min(week, month))
                )
            ).all()
            totals = {
                name: str(sum((r.cost for r in rows if r.created >= start), Decimal(0)))
                for name, start in (("today", day), ("week", week), ("month", month))
            }
            month_rows = [r for r in rows if r.created >= month]
            return totals | {
                "requests": len(month_rows),
                "input_tokens": sum(r.input_tokens for r in month_rows),
                "output_tokens": sum(r.output_tokens for r in month_rows),
                "estimated": sum(r.estimated for r in month_rows),
                "reserved": sum(r.state == "reserved" for r in month_rows),
                "by_purpose": {
                    p: str(sum((r.cost for r in month_rows if r.purpose == p), Decimal(0)))
                    for p in {r.purpose for r in month_rows}
                },
                "today_by_purpose": {
                    p: str(sum((r.cost for r in rows if r.purpose == p and r.created >= day), Decimal(0)))
                    for p in {r.purpose for r in rows}
                },
            }

    async def claim_batch(self, chat_id: int, force=False, batch_size=60) -> dict | None:
        async with self.transaction() as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update(skip_locked=True))
            now = time.time()
            if not group or not group.active or group.worker_until > now:
                return None
            settings = self.config.group_defaults() | group.settings
            if not settings["archive"] or (not settings["background"] and not force):
                return None
            # Lease expired after process death: reclaim only the abandoned batch.
            await s.execute(
                update(ArchiveMessage)
                .where(ArchiveMessage.chat_id == chat_id, ArchiveMessage.queue_state == "processing")
                .values(queue_state="pending")
            )
            q = select(ArchiveMessage).where(
                ArchiveMessage.chat_id == chat_id,
                ArchiveMessage.permanent,
                ArchiveMessage.expires_at > now,
                ArchiveMessage.queue_state == "pending",
                ArchiveMessage.retry_at <= now,
            )
            count = await s.scalar(select(func.count()).select_from(q.subquery()))
            oldest = await s.scalar(
                select(func.min(ArchiveMessage.date)).where(
                    ArchiveMessage.chat_id == chat_id,
                    ArchiveMessage.queue_state == "pending",
                    ArchiveMessage.retry_at <= now,
                )
            )
            if not count or (
                not force
                and count < settings["threshold"]
                and now - (oldest or now) < settings["interval_minutes"] * 60
            ):
                return None
            rows = list((await s.scalars(q.order_by(ArchiveMessage.date).limit(batch_size))).all())
            # Limit body size deterministically; messages omitted remain pending for next batch.
            selected, used = [], 0
            for row in rows:
                size = len(row.text.encode())
                if selected and used + size > 12000:
                    break
                selected.append(row)
                used += size
                row.queue_state = "processing"
                row.attempts += 1
            token = secrets.token_hex(16)
            group.worker_until, group.worker_token = now + 300, token
            return {
                "token": token,
                "epoch": group.epoch,
                "messages": [message_dict(r) for r in selected],
                "settings": settings,
            }

    async def finish_batch(
        self, chat_id: int, batch: dict, candidates: list[dict], error: str = "", budget=False
    ):
        async with self.transaction() as s:
            group = await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            if not group or group.worker_token != batch["token"]:
                return
            ids = [m["id"] for m in batch["messages"]]
            rows = (
                await s.scalars(
                    select(ArchiveMessage).where(
                        ArchiveMessage.chat_id == chat_id, ArchiveMessage.message_id.in_(ids)
                    )
                )
            ).all()
            for row in rows:
                if row.queue_state != "processing":
                    continue
                row.queue_state = (
                    ("failed" if row.attempts >= 3 and not budget else "pending") if error else "done"
                )
                row.retry_at = (
                    time.time() + (3600 if budget else min(3600, 60 * 2**row.attempts)) if error else 0
                )
                if budget:
                    row.attempts = max(0, row.attempts - 1)
            if not error:
                await self.save_memories(chat_id, candidates, batch["epoch"], s)
                group.last_background = time.time()
            group.worker_until, group.worker_token = 0, ""
            group.diagnostic = error[:500]

    async def retry_failed(self, chat_id: int):
        async with self.transaction() as s:
            await s.scalar(select(Group).where(Group.id == chat_id).with_for_update())
            queued = await s.scalar(
                select(func.count())
                .select_from(ArchiveMessage)
                .where(
                    ArchiveMessage.chat_id == chat_id,
                    ArchiveMessage.queue_state.in_(["pending", "processing"]),
                )
            )
            slots = max(0, self.config.queue_max_size - queued)
            rows = (
                await s.scalars(
                    select(ArchiveMessage)
                    .where(
                        ArchiveMessage.chat_id == chat_id,
                        ArchiveMessage.queue_state.in_(["failed", "overflow"]),
                    )
                    .order_by(ArchiveMessage.date)
                    .limit(slots)
                )
            ).all()
            for row in rows:
                row.queue_state, row.attempts, row.retry_at = "pending", 0, 0

    async def panel(self, user_id: int, actions: list[dict]) -> list[str]:
        async with self.transaction() as s:
            await s.execute(delete(PanelToken).where(PanelToken.user_id == user_id))
            tokens = []
            for action in actions:
                token = secrets.token_urlsafe(12)
                s.add(PanelToken(token=token, user_id=user_id, action=action, expires=time.time() + 900))
                tokens.append(token)
            return tokens

    async def consume_panel(self, token: str, user_id: int) -> dict | None:
        async with self.transaction() as s:
            row = await s.scalar(
                select(PanelToken)
                .where(
                    PanelToken.token == token, PanelToken.user_id == user_id, PanelToken.expires > time.time()
                )
                .with_for_update()
            )
            if not row:
                return None
            action = row.action
            await s.delete(row)
            return action

    async def input_state(self, user_id: int, action: dict | None = None, consume=False) -> dict | None:
        async with self.transaction() as s:
            if action is not None:
                stmt = self.insert(InputState).values(
                    user_id=user_id, action=action, expires=time.time() + 600
                )
                await s.execute(
                    stmt.on_conflict_do_update(
                        index_elements=["user_id"], set_={"action": action, "expires": time.time() + 600}
                    )
                )
                return action
            row = await s.get(InputState, user_id)
            value = row.action if row and row.expires > time.time() else None
            if row and consume:
                await s.delete(row)
            return value

    async def favorites(self, user_id: int, model_id: str | None = None) -> list[str]:
        async with self.transaction() as s:
            if model_id:
                row = await s.get(Favorite, (user_id, model_id))
                if row:
                    await s.delete(row)
                else:
                    s.add(Favorite(user_id=user_id, model_id=model_id))
                await s.flush()
            return list((await s.scalars(select(Favorite.model_id).where(Favorite.user_id == user_id))).all())

    async def receipt(self, update_id: int) -> bool:
        async with self.transaction() as s:
            result = await s.execute(
                self.insert(Receipt)
                .values(update_id=update_id, expires=time.time() + 7 * 86400)
                .on_conflict_do_nothing(index_elements=["update_id"])
            )
            return bool(result.rowcount)

    async def release_receipt(self, update_id: int):
        async with self.transaction() as s:
            await s.execute(delete(Receipt).where(Receipt.update_id == update_id))

    async def rate_allowed(self, key: str, seconds: int) -> bool:
        async with self.transaction(global_lock=True) as s:
            row = await s.get(Rate, key)
            now = time.time()
            if row and row.until > now:
                return False
            stmt = self.insert(Rate).values(key=key, until=now + seconds)
            await s.execute(stmt.on_conflict_do_update(index_elements=["key"], set_={"until": now + seconds}))
            return True

    async def cleanup(self):
        async with self.transaction() as s:
            now = time.time()
            for cls, condition in (
                (ArchiveMessage, ArchiveMessage.expires_at <= now),
                (Memory, Memory.valid_until <= now),
                (Dialogue, Dialogue.expires_at <= now),
                (PanelToken, PanelToken.expires <= now),
                (InputState, InputState.expires <= now),
                (Receipt, Receipt.expires <= now),
                (Rate, Rate.until <= now),
            ):
                await s.execute(delete(cls).where(condition))
            # No durable reservation is released blindly after a crash: it remains estimated cost.
            await s.execute(
                update(Usage)
                .where(Usage.state == "reserved", Usage.created < now - 600)
                .values(state="finished", estimated=True, error="interrupted_unknown_cost")
            )
