"""Budget regressions. No API credentials and no paid network calls.
Price fixture matches the public model catalogue fetched during investigation.
"""
import asyncio
import copy
import io
import json
import logging
import os
import unittest
from unittest.mock import AsyncMock, patch
import test_nexora as f
import test_update103 as multi
n=f.n
CID,UID,BOT=f.CID,f.UID,f.BOT
PRICES_25={'prompt':'0.0000003','completion':'0.0000025','image_output':'0.00003'}
PRICES_31={'prompt':'0.0000005','completion':'0.000003','image_output':'0.00006'}


class BudgetTests(unittest.IsolatedAsyncioTestCase):
    fixture_setup=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    def setUp(self):
        self.fixture_setup()
        self.net=multi.IntentNetwork()
        for m in self.net.models:
            if m['id']=='google/gemini-2.5-flash-image':m['pricing']=dict(PRICES_25)
            if m['id']=='google/gemini-3.1-flash-image-preview':m['pricing']=dict(PRICES_31)
        self.app=n.Nexora(self.db,self.net,self.app.token,self.app.brain.key)
        self.app.me,self.app.username=BOT,'NexoraTestBot'

    def charge(self,cost,cid=CID,estimated=0,state='done',purpose='image',created=None):
        self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(?,?,?,?,?,?,?,0,0,'','')",
            (cid,purpose,'fixture',n.time.time() if created is None else created,cost,estimated,state))

    async def visual(self,text='@NexoraTestBot Нарисуй банан'):
        with patch.object(n,'send_image',new_callable=AsyncMock,return_value=f.message('',mid=200,uid=BOT,photo='new')) as send:
            await self.update(f.message(text))
        return send

    async def test_reproduces_103_regression_and_104_allows_available_budget(self):
        model=next(m for m in self.net.models if m['id']==n.DEFAULTS['image_model'])
        prompt='Нарисуй банан'
        old=max(.06,(float(PRICES_25['prompt'])*len(prompt.encode())+max(float(PRICES_25['completion']),float(PRICES_25['image_output']))*8192)*1.5)
        new,cap=n.image_reservation(model,prompt,[])
        self.assertGreater(.2+old,.5,'1.0.3 rejects before API despite $0.30 remaining')
        self.assertLess(.2+new,.5);self.assertEqual(cap,8192)
        self.charge(.2)
        send=await self.visual();send.assert_awaited_once()
        self.assertEqual(len(self.net.images()),1);self.assertAlmostEqual(self.app.brain.costs(CID)['day'],.24)

    async def test_zero_expenses_25_and_31_are_allowed(self):
        n.personal.grant_pro(self.db,1,1,UID,1)  # This test isolates bot/group budgets; Free's personal USD cap is separately tested.
        for mid in n.ROLE_MODELS['image']:
            self.db.c.execute('DELETE FROM personal_jobs');self.db.c.execute('DELETE FROM usage');self.db.c.execute('DELETE FROM image_jobs');self.db.c.execute('DELETE FROM single_seen');self.app.rate.clear()
            self.db.group(CID,image_model=mid)
            send=await self.visual();send.assert_awaited_once()
        self.assertEqual(len(self.net.images()),2)
        model=next(m for m in self.net.models if m['id']==n.ROLE_MODELS['image'][1])
        old=max(float(x) for k,x in PRICES_31.items() if k in ('completion','image_output'))*8192*1.5
        self.assertGreater(old,.4,'Old per-request ceiling rejects even with zero spend')
        self.assertLess(n.image_reservation(model,'Банан',[])[0],.4)

    async def test_exhausted_application_budget_blocks_before_paid_post(self):
        self.charge(.5,cid=CID-1)
        before=self.db.all('SELECT * FROM usage')
        for _ in range(2):
            with self.assertRaises(n.BudgetFault) as caught:
                await n.generate_image(self.app.brain,CID,'Нарисуй банан',[])
            exc=caught.exception
            self.assertEqual((exc.scope,exc.period,exc.kind),('app','day','image'))
            self.assertIn('всего бота',exc.user_message());self.assertIn('used_usd=0.50000000',exc.diagnostic())
        self.assertFalse(self.net.images());self.assertEqual(before,self.db.all('SELECT * FROM usage'))

    async def test_group_daily_limit_has_correct_source_and_no_post(self):
        self.db.group(CID,daily_budget='.10');self.charge(.10)
        with self.assertLogs('nexora',level='WARNING') as logs:
            send=await self.visual()
        send.assert_not_awaited();self.assertFalse(self.net.images())
        self.assertIn('scope=group period=day kind=image','\n'.join(logs.output))
        self.assertIn('группы',self.net.sends()[-1]['text']);self.assertNotIn('OpenRouter',self.net.sends()[-1]['text'])

    async def test_remaining_lower_than_reserve_not_reported_as_spent_limit(self):
        self.db.group(CID,daily_budget='.10');self.charge(.03)
        with self.assertRaises(n.BudgetFault) as caught:await n.generate_image(self.app.brain,CID,'Банан',[])
        self.assertEqual(caught.exception.budget_reason,'reserve_exceeds_remaining')
        self.assertIn('Остатка',caught.exception.user_message());self.assertIn('remaining_usd=0.07000000',caught.exception.diagnostic())
        self.assertFalse(self.net.images())

    async def test_monthly_and_background_dimensions_distinguished(self):
        fixtures=[('month',{'day':0.,'month':10.,'background':0.},False,'app'),
                  ('background',{'day':.1,'month':.1,'background':.1},True,'app')]
        for period,costs,background,scope in fixtures:
            with patch.object(self.app.brain,'costs',return_value=costs):
                with self.db.tx(),self.assertRaises(n.BudgetFault) as caught:
                    n.enforce_budget(self.app.brain,CID,dict(n.DEFAULTS),.001,'background' if background else 'image',background)
            self.assertEqual((caught.exception.scope,caught.exception.period),(scope,period))
        app_costs={'day':0.,'month':0.,'background':0.};group_costs={'day':0.,'month':.2,'background':0.}
        cfg=dict(n.DEFAULTS,monthly_budget='.2')
        with patch.object(self.app.brain,'costs',side_effect=[app_costs,group_costs]):
            with self.db.tx(),self.assertRaises(n.BudgetFault) as caught:n.enforce_budget(self.app.brain,CID,cfg,.01,'image')
        self.assertEqual((caught.exception.scope,caught.exception.period),('group','month'))

    async def test_missing_none_empty_limits_use_defaults_without_changing_stored_settings(self):
        for value in (None,'','  '):
            self.db.c.execute('DELETE FROM personal_jobs');self.db.c.execute('DELETE FROM usage');self.db.c.execute('DELETE FROM image_jobs');self.db.c.execute('DELETE FROM single_seen');self.app.rate.clear()
            self.db.group(CID,daily_budget=value,monthly_budget=value)
            before=self.db.one('SELECT settings FROM groups WHERE id=?',(CID,))['settings']
            send=await self.visual();send.assert_awaited_once()
            self.assertEqual(before,self.db.one('SELECT settings FROM groups WHERE id=?',(CID,))['settings'])
        for key in n.BUDGET_BASELINE:
            self.assertEqual(n.budget_value({},key,'group','image',CID),n.BUDGET_BASELINE[key])

    async def test_explicit_zero_is_not_missing(self):
        self.db.group(CID,daily_budget='0')
        send=await self.visual();send.assert_not_awaited()
        self.assertIn('установлен в $0',self.net.sends()[-1]['text']);self.assertFalse(self.net.images())

    async def test_free_price_does_not_invent_six_cent_cost(self):
        self.db.group(CID,daily_budget='0')
        for m in self.net.models:
            if m['id']==n.DEFAULTS['image_model']:m['pricing']={'prompt':'0','completion':'0','image_output':'0'}
        self.net.image_response={'choices':[{'message':{'images':[{'image_url':{'url':f.DATA}}]}}], 'usage':{'cost':0}}
        send=await self.visual();send.assert_awaited_once()
        self.assertEqual(self.app.brain.costs(CID)['day'],0)

    async def test_invalid_limit_fails_closed_no_secrets_in_logs(self):
        secret=self.app.brain.key
        for value in ('NaN','-1',secret,False):
            self.db.group(CID,daily_budget=value)
            with self.assertLogs('nexora',level='WARNING') as logs:
                with self.assertRaises(n.BudgetFault) as caught:await n.generate_image(self.app.brain,CID,'Банан',[])
            self.assertEqual(caught.exception.code,'invalid_limit')
            self.assertNotIn(secret,'\n'.join(logs.output))
        self.assertFalse(self.net.images())

    async def test_unknown_model_price_units_not_guessed(self):
        model=f.model('unknown/image',True)
        with self.assertRaises(n.Fault) as caught:n.image_reservation(model,'Банан',[])
        self.assertEqual(caught.exception.code,'unknown_price')

    async def test_multi_intent_request_uses_corrected_image_budget(self):
        self.charge(.2)
        send=await self.visual('@NexoraTestBot Я нормально. Можешь сделать картинку банана?')
        send.assert_awaited_once();self.assertFalse(self.net.sends())
        self.assertEqual(len(self.net.images()),1);self.assertEqual(len(self.net.captions()),1)

    async def test_api_json_error_retains_external_key_limit_no_paid_retries(self):
        self.net.image_response={'error':{'code':402,'message':'DO NOT LOG '+self.app.token,'metadata':{'limit_source':'openrouter_key_limit'}}}
        with self.assertLogs('nexora',level='WARNING') as logs:send=await self.visual()
        send.assert_not_awaited();self.assertEqual(len(self.net.images()),1)
        self.assertIn('OpenRouter:402','\n'.join(logs.output));self.assertIn('openrouter_key_limit','\n'.join(logs.output))
        self.assertNotIn(self.app.token,'\n'.join(logs.output))
        self.assertIn('лимита API-ключа',self.net.sends()[-1]['text'])
        self.assertEqual(float(self.db.one('SELECT cost FROM usage')['cost']),0)

    async def test_http402_metadata_preserved_and_unknown_source_not_invented(self):
        for source in ('openrouter_in_flight_budget','unknown_secret_'+self.app.brain.key,{'bad':'value'}):
            body=json.dumps({'error':{'code':402,'message':self.app.token,'metadata':{'limit_source':source}}}).encode()
            exc=n.urllib.error.HTTPError('https://openrouter.ai/api/v1/chat/completions',402,'private',{},io.BytesIO(body))
            with patch.object(n.urllib.request,'urlopen',side_effect=exc) as opened,self.assertLogs('nexora',level='WARNING') as logs:
                with self.assertRaises(n.Fault) as caught:await n.HTTP().call('https://openrouter.ai/api/v1/chat/completions',{},self.app.brain.key)
            fault=caught.exception;self.assertEqual(fault.code,'402');self.assertNotIsInstance(fault,n.BudgetFault)
            self.assertEqual(opened.call_count,1);self.assertNotIn(self.app.token,'\n'.join(logs.output));self.assertNotIn(self.app.brain.key,'\n'.join(logs.output))
            if isinstance(source,str) and source=='openrouter_in_flight_budget':self.assertIn('выполняющихся',n.external_budget_message(fault))
            else:self.assertIn('точный источник не указан',n.external_budget_message(fault))

    async def test_uncertain_old_reserve_preserved_and_shown_to_owner(self):
        self.charge(.30,estimated=1,state='error')
        before=self.db.one('SELECT * FROM usage')
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):await n.owner_diagnostics(self.app,UID)
        text=self.net.sends()[-1]['text'];self.assertIn('неизвестное $0.3000',text)
        self.assertEqual(self.db.one('SELECT * FROM usage'),before)
        self.assertAlmostEqual(self.app.brain.costs()['day_uncertain'],.30)

    async def test_two_groups_cannot_overbook_shared_application_budget(self):
        for cid in (CID,CID-1):self.db.group(cid,'Group',image_model='google/gemini-3.1-flash-image-preview')
        started,release=asyncio.Event(),asyncio.Event();original=self.net.call
        async def held(url,data=None,*a,**kw):
            if data and data.get('modalities'):
                started.set();await release.wait()
            return await original(url,data,*a,**kw)
        self.net.call=held
        first=asyncio.create_task(n.generate_image(self.app.brain,CID,'Банан',[]))
        try:
            await asyncio.wait_for(started.wait(),2)
            with self.assertRaises(n.BudgetFault) as caught:await n.generate_image(self.app.brain,CID-1,'Банан',[])
            self.assertEqual(caught.exception.scope,'app')
            self.assertEqual(len(self.db.all("SELECT * FROM usage WHERE state='reserved'")),1)
        finally:
            release.set();await first
        self.assertEqual(len(self.net.images()),1)

    async def test_failure_keeps_uncertain_reserve_and_no_automatic_replay(self):
        self.net.error=n.Fault('HTTP','timeout',operation='OpenRouter.chat')
        send=await self.visual();send.assert_not_awaited()
        self.assertEqual(len(self.net.images()),1)
        self.assertGreater(self.app.brain.costs()['day_uncertain'],0)

    async def test_estimation_cap_and_safe_budget_error_ring(self):
        model=next(m for m in self.net.models if m['id']==n.DEFAULTS['image_model'])
        model=copy.deepcopy(model);model['pricing']['request']='.30'
        self.assertGreater(n.image_reservation(model,'Банан',[])[0],.4)
        n.SERVICE_ERRORS.clear();handler=n.ServiceErrors()
        fault=n.BudgetFault('group','day','image',.1,.1,.08,'spent_limit',cid=CID)
        handler.handle(logging.LogRecord('nexora',logging.WARNING,'',1,'Budget denied: %s',(fault.diagnostic(),),None))
        self.assertIn('limit_reached',n.SERVICE_ERRORS[-1])


if __name__=='__main__':unittest.main()
