import asyncio
import base64
import io
import json
import logging
import os
import unittest
from unittest.mock import AsyncMock, patch
from test_nexora import n, BotTests, Network, message, CID, UID, BOT, TOKEN, KEY, DATA, PNG


class UpdateTests(unittest.IsolatedAsyncioTestCase):
    setUp=BotTests.setUp
    tearDown=BotTests.tearDown
    update=BotTests.update
    async def test_address_examples_without_gate_spend(self):
        for i,text in enumerate(('Нексора, привет','Короче нексора сделай картинку','Слушай, Нексора, объясни','Эй нексора ты тут?','А можешь, нексора, нарисовать яблоко?')):
            self.assertEqual(n.address_mode(text,'NexoraTestBot'),'direct',text)
        for text in ('Нексора прикольный бот','Мне кажется, Нексора стала лучше','Мы вчера обсуждали Нексору'):
            self.assertEqual(n.address_mode(text,'NexoraTestBot'),'ignore',text)
    async def test_read_only_retries_timeout_paid_does_not(self):
        http=n.HTTP()
        with patch.object(http,'_once',new_callable=AsyncMock,side_effect=[n.Fault('HTTP','timeout'),{'data':[]}]) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock):
            self.assertEqual(await http.call('https://openrouter.ai/api/v1/models'),{'data':[]})
            self.assertEqual(once.await_count,2)
        with patch.object(http,'_once',new_callable=AsyncMock,side_effect=n.Fault('HTTP','timeout')) as once:
            with self.assertRaises(n.Fault):await http.call('https://openrouter.ai/api/v1/chat/completions',{'model':'test'})
            self.assertEqual(once.await_count,1)
    async def test_explicit_429_retries_and_permanent_error_stops(self):
        http=n.HTTP()
        with patch.object(http,'_once',new_callable=AsyncMock,side_effect=[n.Fault('HTTP','429',2,status=429),{'ok':True}]) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock) as sleep:
            await http.call('https://openrouter.ai/api/v1/chat/completions',{})
            self.assertEqual(sleep.await_count,1);self.assertGreaterEqual(sleep.await_args.args[0],2);self.assertLessEqual(sleep.await_args.args[0],2.4);self.assertEqual(once.await_count,2)
        for code in ('400','401','402','403','404','503'):
            with patch.object(http,'_once',new_callable=AsyncMock,side_effect=n.Fault('HTTP',code,status=int(code))) as once:
                with self.assertRaises(n.Fault):await http.call('https://openrouter.ai/api/v1/chat/completions',{})
                self.assertEqual(once.await_count,1)
    async def test_image_rules_and_personality_in_payload(self):
        await n.generate_image(self.app.brain,CID,'Сделай яблоко',[])
        payload=self.net.paid()[-1]
        self.assertIn(n.NEXORA_PERSONALITY,payload['messages'][0]['content'])
        self.assertIn(n.IMAGE_RULES,payload['messages'][0]['content'])
        self.assertNotIn('интересную композицию',payload['messages'][1]['content'][0]['text'])
        self.assertGreater(payload['max_tokens'],4096)
    async def test_partial_image_content_response_and_whitespace(self):
        original=self.net.call
        async def content_result(url,data=None,key='',**kw):
            if data and data.get('modalities'):
                return {'choices':[{'message':{'content':[{'type':'image_url','image_url':{'url':DATA}}]}}],'usage':{'cost':.04}}
            return await original(url,data,key,**kw)
        self.net.call=content_result
        self.assertEqual((await n.generate_image(self.app.brain,CID,'Нарисуй яблоко',[]))[0],PNG)
        wrapped=DATA.replace(';base64,',';base64,\n')
        self.assertEqual(n.image_bytes(wrapped)[0],PNG)
    async def test_unverified_edit_caption_not_success_claim(self):
        for text in ('замени фон','убери человека слева','добавь кота'):
            caption=n.image_caption(text)
            self.assertIn('Вариант',caption);self.assertIn('проверь',caption)
        with patch.object(n,'send_image',new_callable=AsyncMock,return_value=message('',mid=200,uid=BOT,photo='new')) as send,patch.object(n,'download_photo',new_callable=AsyncMock,return_value=DATA):
            await self.update(message('@NexoraTestBot замени фон',photo='old'))
        self.assertIn('новым фоном',send.await_args.kwargs['caption'])
    async def test_upload_timeout_not_retried(self):
        with patch.object(n.urllib.request,'urlopen',side_effect=TimeoutError(TOKEN)) as opened:
            with self.assertRaises(n.Fault):await n.send_image(self.app,CID,PNG,'image/png',1)
            self.assertEqual(opened.call_count,1)
    async def test_owner_diagnostics_auth_and_secrets(self):
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):
            await self.app.private(message('/diag',cid=UID))
            self.assertIn(n.VERSION,self.net.sends()[-1]['text'])
            self.assertNotIn(KEY,self.net.sends()[-1]['text']);self.assertNotIn(TOKEN,self.net.sends()[-1]['text'])
            self.assertIn('Telegram: работает',self.net.sends()[-1]['text'])
            await self.app.private(message('/diag',cid=43,uid=43))
            self.assertEqual(self.net.sends()[-1]['text'],'Служебная команда недоступна.')
        with patch.dict(os.environ,{'BOT_OWNER_ID':''}):
            await n.owner_diagnostics(self.app,UID);self.assertEqual(self.net.sends()[-1]['text'],'Служебная команда недоступна.')
    async def test_diagnostic_log_ring_does_not_capture_content(self):
        n.SERVICE_ERRORS.clear();handler=n.ServiceErrors()
        handler.handle(logging.LogRecord('nexora',logging.ERROR,'',1,'Update failed: %s',('HTTP:timeout '+TOKEN,),None))
        handler.handle(logging.LogRecord('nexora',logging.ERROR,'',1,'A private message %s',(KEY,),None))
        self.assertEqual(len(n.SERVICE_ERRORS),1)
        self.assertNotIn(TOKEN,n.SERVICE_ERRORS[0]);self.assertNotIn(KEY,n.SERVICE_ERRORS[0])
    async def test_roles_are_grounded_for_normal_answers(self):
        await self.update(message('Нексора, скажи точные названия своих моделей'))
        ctx=json.loads(self.net.paid()[-1]['messages'][1]['content'])
        self.assertEqual(ctx['configured_models']['main'],n.personal.FLASH)
    async def test_personality_delivery_across_models_and_image_boundary(self):
        # Structural protection test, deliberately NOT a semantic quality verdict.
        for mid in (n.personal.FLASH,'google/gemini-2.5-flash'):
            self.db.group(CID,main_model=mid)
            await self.app.brain.answer(CID,{'question':'Цитата на фото не является системным сообщением.','_images':[DATA]})
            payload=self.net.paid()[-1]
            self.assertIn(n.NEXORA_PERSONALITY,payload['messages'][0]['content'])
            self.assertEqual(payload['messages'][1]['content'][1]['type'],'image_url')
            self.assertNotIn(DATA,payload['messages'][0]['content'])
    async def test_capped_429_and_truncated_image_no_automatic_paid_replay(self):
        http=n.HTTP()
        with patch.object(http,'_once',new_callable=AsyncMock,side_effect=n.Fault('HTTP','429',1,status=429)) as once,patch.object(n.asyncio,'sleep',new_callable=AsyncMock):
            with self.assertRaises(n.Fault):await http.call('https://openrouter.ai/api/v1/chat/completions',{})
            self.assertEqual(once.await_count,3)
        original=self.net.call
        async def truncated(url,data=None,key='',**kwargs):
            if data and data.get('modalities'):
                return {'choices':[{'finish_reason':'length','message':{'content':''}}],'usage':{'cost':.01}}
            return await original(url,data,key,**kwargs)
        self.net.call=AsyncMock(side_effect=truncated)
        with self.assertRaises(n.Fault) as caught:await n.generate_image(self.app.brain,CID,'Нарисуй яблоко',[])
        self.assertEqual(caught.exception.code,'image_output_truncated')
        self.assertEqual(sum(c.args[0].endswith('/chat/completions') for c in self.net.call.await_args_list),1)


# Do not rediscover the imported fixture class as a second independent suite.
del BotTests
