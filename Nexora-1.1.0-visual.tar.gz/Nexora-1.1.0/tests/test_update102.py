"""Interface/command regression tests with simulated Telegram and OpenRouter."""
import asyncio
import ast
import json
import os
from pathlib import Path
import unittest
from unittest.mock import AsyncMock, patch
from test_nexora import n, BotTests, message, CID, UID, BOT


class InterfaceTests(unittest.IsolatedAsyncioTestCase):
    setUp = BotTests.setUp
    tearDown = BotTests.tearDown
    update = BotTests.update

    def screen(self):
        return self.net.sends()[-1]

    def labels(self):
        return [b['text'] for row in self.screen()['reply_markup']['inline_keyboard'] for b in row]

    async def tap(self, label, update_id=None):
        button = next(b for row in self.screen()['reply_markup']['inline_keyboard'] for b in row if b['text'] == label)
        if update_id is None:
            update_id = max([r['id'] for r in self.db.all('SELECT id FROM single_seen')] or [0])+1
        await self.app.handle({'update_id': update_id, 'callback_query': {
            'id': str(update_id), 'from': {'id': UID}, 'data': button['callback_data'],
            'message': {'chat': {'id': UID, 'type': 'private'}, 'message_id': self.screen().get('message_id', self.net.counter)}}})

    async def group_screen(self):
        await self.app.panel(UID, {'v': 'group', 'c': CID})

    def insert_memory(self, cid=CID):
        self.db.c.execute("INSERT INTO memories(chat_id,kind,value,fingerprint,subject_ids,sources,confidence,status,created,event_date,valid_until,embedding_model) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (cid,'event','Обсудили дизайн','test-memory','[]','[]',.95,'confirmed',n.time.time(),'2026-10-26',n.time.time()+86400,''))

    async def test_first_repeat_start_each_sends_one_visible_menu(self):
        for i, text in enumerate(('/start','/start','/start payload'),1):
            before=len(self.net.sends())
            await self.update(message(text,mid=i,cid=UID),i)
            self.assertEqual(len(self.net.sends()),before+1)
            self.assertNotIn('message_id',self.screen(),'/start must send here, not edit an old message')
            self.assertEqual(self.screen()['text'],'Nexora\n\nВыберите раздел.')
            self.assertEqual(self.labels(),['Мои группы','Добавить в группу','Справка'])
        self.assertFalse(self.net.paid())

    async def test_start_after_buttons_and_old_button_does_not_revive_old_panel(self):
        await self.update(message('/start',cid=UID),1)
        old=self.screen()['reply_markup']['inline_keyboard'][0][0]['callback_data']
        old_id=self.net.counter
        await self.tap('Мои группы')
        await self.update(message('/start',mid=3,cid=UID),3)
        new_id=self.net.counter
        self.assertNotEqual(new_id,old_id)
        await self.app.handle({'update_id':4,'callback_query':{'id':'old','from':{'id':UID},'data':old,'message':{'chat':{'id':UID},'message_id':old_id}}})
        self.assertEqual(self.db.one('SELECT message_id FROM single_panel WHERE uid=?',(UID,))['message_id'],new_id)
        self.assertEqual(self.screen()['message_id'],new_id)
        await self.update(message('/start',mid=5,cid=UID),5)
        self.assertNotIn('message_id',self.screen())

    async def test_duplicate_start_update_not_duplicate_menu(self):
        m=message('/start',cid=UID)
        await self.update(m,20); await self.update(m,20)
        self.assertEqual(len(self.net.sends()),1)

    async def test_edited_private_start_does_not_send_another_menu(self):
        m=message('/start',cid=UID)
        await self.update(m,1)
        await self.app.handle({'update_id':2,'edited_message':m})
        self.assertEqual(len(self.net.sends()),1)

    async def test_start_group_including_reply_ignored(self):
        for i,text in enumerate(('/start','/start@NexoraTestBot','/start anything'),1):
            await self.update(message(text,mid=i,reply=message('Ответ',uid=BOT)),i)
        self.assertFalse(self.net.sends()); self.assertFalse(self.net.paid())

    async def test_navigation_all_main_sections_edit_one_panel(self):
        await self.update(message('/start',cid=UID))
        panel_id=self.net.counter
        await self.tap('Мои группы'); await self.tap('Group')
        self.assertEqual(self.screen()['text'],'Настройки группы: Group')
        for label,title in (('Память','Память'),('Приватность','Приватность'),('Характер и инициативность','Поведение'),('Изображения и лимиты','Изображения'),('Модели','Модель общения'),('Общие настройки','Общие настройки')):
            await self.tap(label)
            self.assertTrue(self.screen()['text'].startswith(title))
            self.assertEqual(self.screen()['message_id'],panel_id)
            await self.tap('← Назад')
            self.assertEqual(self.screen()['text'],'Настройки группы: Group')
        await self.tap('← Назад'); self.assertTrue(self.screen()['text'].startswith('Мои группы'))
        await self.tap('← Назад'); self.assertEqual(self.screen()['text'],'Nexora\n\nВыберите раздел.')
        self.assertEqual(sum(u.endswith('/sendMessage') for u,d,k in self.net.calls),1)

    async def test_memory_and_privacy_distinct_compact(self):
        await self.group_screen(); await self.tap('Память')
        self.assertIn('Воспоминания',self.labels()); self.assertIn('Очистить память',self.labels())
        self.assertNotIn('Срок хранения',self.labels()); self.assertNotIn('Включить архив',self.labels())
        self.assertNotIn('OpenRouter',self.screen()['text'])
        await self.tap('Перейти в приватность')
        self.assertIn('Включить архив',self.labels()); self.assertIn('Срок хранения',self.labels())
        self.assertNotIn('Воспоминания',self.labels()); self.assertNotIn('OpenRouter',self.screen()['text'])
        await self.tap('Как используются данные')
        self.assertIn('OpenRouter',self.screen()['text']); self.assertIn('временно',self.screen()['text'])
        await self.tap('← Назад'); self.assertTrue(self.screen()['text'].startswith('Приватность'))

    async def test_archive_confirm_back_and_retention_persistence(self):
        await self.app.panel(UID,{'v':'privacy','c':CID})
        await self.tap('Включить архив')
        self.assertFalse(self.db.group(CID)[1]['archive'])
        await self.tap('← Назад'); self.assertFalse(self.db.group(CID)[1]['archive'])
        await self.tap('Включить архив'); await self.tap('Подтвердить')
        self.assertTrue(self.db.group(CID)[1]['archive']); self.assertIn('Сохранено.',self.screen()['text'])
        await self.tap('Срок хранения'); await self.tap('90 дней')
        self.assertEqual(self.db.group(CID)[1]['retention_days'],90)
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertTrue(self.db.group(CID)[1]['archive']);self.assertEqual(self.db.group(CID)[1]['retention_days'],90)

    async def test_memory_clear_requires_confirm_and_preserves_history(self):
        self.insert_memory(); self.insert_memory(CID-1)
        self.db.group(CID,archive=True)
        await self.update(message('Решили сохранить историю обсуждения проекта'))
        await self.app.panel(UID,{'v':'memory','c':CID})
        await self.tap('Очистить память')
        self.assertEqual(len(self.db.all('SELECT * FROM memories WHERE chat_id=?',(CID,))),1)
        await self.tap('← Назад'); self.assertTrue(self.db.all('SELECT * FROM memories WHERE chat_id=?',(CID,)))
        await self.tap('Очистить память'); await self.tap('Очистить')
        self.assertFalse(self.db.all('SELECT * FROM memories WHERE chat_id=?',(CID,)))
        self.assertTrue(self.db.all('SELECT * FROM memories WHERE chat_id=?',(CID-1,)))
        self.assertTrue(self.db.all('SELECT * FROM messages WHERE chat_id=?',(CID,)))

    async def test_full_group_data_clear_still_available_separate_confirm(self):
        self.insert_memory();self.db.group(CID,archive=True)
        await self.update(message('Решили сохранить важную историю проекта'))
        await self.app.panel(UID,{'v':'privacy','c':CID})
        await self.tap('Как используются данные');await self.tap('Очистить данные группы')
        self.assertTrue(self.db.all('SELECT * FROM messages'))
        await self.tap('Удалить данные')
        self.assertFalse(self.db.all('SELECT * FROM messages'));self.assertFalse(self.db.all('SELECT * FROM memories'))
        self.assertTrue(self.db.group(CID)[1]['archive'])

    async def test_personal_navigation_optout_erase_confirm(self):
        self.db.c.execute('INSERT INTO participants VALUES(?,?,?)',(CID,UID,'{"nickname":"Лёша"}'))
        await self.app.panel(UID,{'v':'privacy','c':CID});await self.tap('Мои данные')
        await self.tap('Запретить новую запись');self.assertTrue(self.db.opted(UID))
        await self.tap('Удалить мои данные')
        self.assertTrue(self.db.all('SELECT * FROM participants'))
        await self.tap('← Назад');await self.tap('Удалить мои данные');await self.tap('Подтверждаю удаление')
        self.assertFalse(self.db.all('SELECT * FROM participants'));self.assertTrue(self.db.opted(UID))
        await self.tap('← Назад'); self.assertTrue(self.screen()['text'].startswith('Приватность'))

    async def test_fact_delete_confirmation_and_back(self):
        self.insert_memory();await self.app.panel(UID,{'v':'browse','c':CID})
        await self.tap('✓ Обсудили дизайн');await self.tap('Удалить запись')
        self.assertTrue(self.db.all('SELECT * FROM memories'))
        await self.tap('← Назад');await self.tap('Удалить запись');await self.tap('Удалить')
        self.assertFalse(self.db.all('SELECT * FROM memories'))

    async def test_compact_models_back_to_same_role_and_selection(self):
        await self.group_screen();await self.tap('Модели')
        self.assertIn('каждый участник',self.screen()['text'])
        self.assertEqual(self.labels(),['← Назад'])
        await self.tap('← Назад');self.assertIn('Настройки группы',self.screen()['text'])

    async def test_admin_revoked_between_screen_and_action_no_change(self):
        await self.app.panel(UID,{'v':'privacy','c':CID});await self.tap('Включить архив')
        self.net.status='member';await self.tap('Подтвердить')
        self.assertFalse(self.db.group(CID)[1]['archive']);self.assertIn('администраторам',self.screen()['text'])
        self.net.status='administrator';await self.update(message('/start',mid=90,cid=UID),90)
        self.assertEqual(self.screen()['text'],'Nexora\n\nВыберите раздел.')

    async def test_old_version_callback_cannot_change_settings(self):
        token='old-version'
        self.db.c.execute('INSERT INTO single_cb VALUES(?,?,?,?)',(token,UID,json.dumps({'op':'toggle','c':CID,'key':'initiative','_ver':'n100'}),n.time.time()+900))
        await self.app.handle({'update_id':1,'callback_query':{'id':'old','from':{'id':UID},'data':'j:'+token,'message':{'chat':{'id':UID},'message_id':10}}})
        self.assertTrue(self.db.group(CID)[1]['initiative']);self.assertIn('Меню обновилось',self.screen()['text'])

    async def test_diag_private_owner_only_and_no_menu_link(self):
        await self.update(message('/start',cid=UID));self.assertNotIn('Диагностика',self.labels())
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID+1)}):
            await self.update(message('/diag',cid=UID),2)
            self.assertEqual(self.screen()['text'],'Служебная команда недоступна.')
        with patch.dict(os.environ,{'BOT_OWNER_ID':str(UID)}):
            await self.update(message('/diag',cid=UID),3)
            self.assertIn('Nexora '+n.VERSION,self.screen()['text']);self.assertIn('База данных: доступна',self.screen()['text'])

    async def test_edit_failure_recovers_once_and_start_failure_logs_safely(self):
        await self.app.panel(UID)
        call=self.net.call
        async def unavailable(url,*args,**kw):
            if url.endswith('/editMessageText'):raise n.Fault('Telegram','400')
            return await call(url,*args,**kw)
        self.net.call=unavailable
        before=len([u for u,d,k in self.net.calls if u.endswith('/sendMessage')])
        await self.app.panel(UID,{'v':'help'})
        self.assertEqual(len([u for u,d,k in self.net.calls if u.endswith('/sendMessage')]),before+1)
        async def broken(url,*args,**kw):raise n.Fault('HTTP','timeout',operation='Telegram.sendMessage')
        self.net.call=broken
        with self.assertLogs('nexora',level='ERROR') as logs:
            await self.update(message('/start',cid=UID),22)
        self.assertIn('HTTP:timeout','\n'.join(logs.output));self.assertNotIn(self.app.token,'\n'.join(logs.output))

    async def test_help_details_back_navigation(self):
        await self.update(message('/start',cid=UID))
        await self.tap('Справка')
        for label,title in (('Работа в группе','Работа в группе'),('Как используются данные','Как используются данные'),('Мои данные','Мои данные')):
            await self.tap(label);self.assertTrue(self.screen()['text'].startswith(title))
            await self.tap('← Назад')
            self.assertIn('Позовите меня',self.screen()['text'])
        await self.tap('← Назад');self.assertEqual(self.screen()['text'],'Nexora\n\nВыберите раздел.')

    async def test_start_received_while_group_image_work_pending(self):
        started=asyncio.Event(); received=asyncio.Event();release=asyncio.Event()
        original_call=self.net.call
        slow_update={'update_id':100,'message':message('Нексора, нарисуй кота')}
        start_update={'update_id':101,'message':message('/start',cid=UID)}
        polled=[]
        async def slow_group(m):
            started.set();await release.wait()
        async def call(url,data=None,*args,**kw):
            if url.endswith('/getUpdates'):
                polled.append(dict(data))
                if len(polled)==1:return {'ok':True,'result':[slow_update]}
                if not received.is_set():return {'ok':True,'result':[slow_update,start_update]}
                await asyncio.sleep(.01)
                return {'ok':True,'result':[]}
            result=await original_call(url,data,*args,**kw)
            if url.endswith('/sendMessage') and data['chat_id']==UID:received.set()
            return result
        self.net.call=call
        with patch.object(self.app,'group_message',side_effect=slow_group):
            running=asyncio.create_task(self.app.run())
            try:
                await asyncio.wait_for(started.wait(),2)
                await asyncio.wait_for(received.wait(),3)
                self.assertFalse(release.is_set())
                self.assertEqual(self.screen()['text'],'Nexora\n\nВыберите раздел.')
                self.assertEqual(polled[1]['offset'],100,'unfinished update must not be acknowledged')
                self.assertEqual(len(self.net.sends()),1,'redelivery must not duplicate /start')
            finally:
                release.set();running.cancel();await asyncio.gather(running,return_exceptions=True)

    async def test_existing_database_rows_preserved_on_reopen(self):
        self.db.group(CID,archive=True,humor='meme',main_model='google/gemini-2.5-flash-lite',retention_days=90)
        self.insert_memory()
        await self.update(message('Решили сохранить подробности проекта и его название'))
        self.db.c.execute('INSERT INTO participants VALUES(?,?,?)',(CID,UID,'{"nickname":"Лёша"}'))
        tables=('groups','memories','messages','participants','usage','privacy','dialogues','nexora_images')
        before={t:self.db.all(f'SELECT * FROM {t}') for t in tables}
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        for table in tables:
            self.assertEqual(before[table],self.db.all(f'SELECT * FROM {table}'),table)
        self.assertEqual(self.db.group(CID)[1]['humor'],'meme')
        self.assertEqual(self.db.group(CID)[1]['main_model'],'google/gemini-2.5-flash-lite')


# The imported fixture is not another suite.
del BotTests


if __name__=='__main__':unittest.main()
