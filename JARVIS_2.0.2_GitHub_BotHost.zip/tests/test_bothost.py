"""Deployment regressions. Real SQLite, Python/aiogram startup; no real Telegram calls."""

import asyncio
import subprocess
import sys
from decimal import Decimal
from pathlib import Path

import pytest
from aiogram import Dispatcher
from aiogram.types import Update
from conftest import ADMIN, CHAT, archive, make_message
from sqlalchemy import select, text

import main
from ai import AIError, BudgetError
from config import DEFAULT_DATABASE_URL, Settings
from database import Database, Usage
from runtime_check import check_runtime


@pytest.fixture
def clean_env(monkeypatch):
    # Host aliases should be tested independently of a developer's real environment.
    for name in (
        "TELEGRAM_BOT_TOKEN",
        "BOT_TOKEN",
        "API_TOKEN",
        "OPENROUTER_API_KEY",
        "DATABASE_URL",
        "BOT_OWNER_ID",
        "DEFAULT_MAIN_MODEL",
        "DEFAULT_BACKGROUND_MODEL",
        "DEFAULT_EMBEDDING_MODEL",
    ):
        monkeypatch.delenv(name, raising=False)


@pytest.mark.parametrize("name", ["BOT_TOKEN", "API_TOKEN", "TELEGRAM_BOT_TOKEN"])
def test_host_token_aliases_and_empty_defaults(clean_env, monkeypatch, name):
    monkeypatch.setenv(name, "fixture-token")
    monkeypatch.setenv("BOT_OWNER_ID", "")
    monkeypatch.setenv("DATABASE_URL", "")
    settings = Settings(_env_file=None)
    assert settings.telegram_bot_token.get_secret_value() == "fixture-token"
    assert settings.database_url == DEFAULT_DATABASE_URL and settings.bot_owner_id == 0
    assert not settings.openrouter_api_key.get_secret_value()


def test_empty_primary_token_does_not_hide_host_alias(clean_env, monkeypatch):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "")
    monkeypatch.setenv("BOT_TOKEN", "fixture-token")
    assert Settings(_env_file=None).telegram_bot_token.get_secret_value() == "fixture-token"


@pytest.mark.parametrize(
    "source,expected",
    [
        ("postgres://u:p@db.example/db", "postgresql+asyncpg://u:p@db.example/db"),
        ("postgresql://u:p@db.example/db", "postgresql+asyncpg://u:p@db.example/db"),
        ("sqlite:///./data/test.db", "sqlite+aiosqlite:///./data/test.db"),
        ("", DEFAULT_DATABASE_URL),
    ],
)
def test_database_url_normalization(source, expected, clean_env):
    assert Settings(_env_file=None, database_url=source).database_url == expected


def test_postgres_sslmode_adapted_without_changing_credentials(env):
    cfg = env.config.model_copy(
        update={"database_url": "postgresql+asyncpg://u:p@db.example/test?sslmode=require"}
    )
    db = Database(cfg)
    assert db.pg and "sslmode" not in db.engine.url.query
    assert db.engine.url.password == "p" and db.engine.url.host == "db.example"


async def test_start_without_openrouter_or_models_or_owner(env, monkeypatch):
    settings = Settings(
        _env_file=None, telegram_bot_token=env.bot.token, database_url=env.config.database_url
    )
    assert not settings.default_main_model and not settings.openrouter_api_key.get_secret_value()
    monkeypatch.setattr(main, "Settings", lambda: settings)
    monkeypatch.setattr(main, "Bot", lambda token: env.bot)
    seen = []

    async def poll(self, bot, **kwargs):
        assert "message" in kwargs["allowed_updates"]
        await self.feed_update(
            bot, Update(update_id=909090, message=make_message(bot, "/start", private=True))
        )
        seen.extend(x for x in env.telegram.requests if type(x).__name__ == "SendMessage")

    monkeypatch.setattr(Dispatcher, "start_polling", poll)
    await main.run()
    assert seen and "панель управления" in seen[-1].text and "Ключ OpenRouter" in seen[-1].text
    assert seen[-1].reply_markup.inline_keyboard
    assert not env.http.requests


async def test_paid_ai_without_key_is_explicit_and_does_not_reserve(env):
    from pydantic import SecretStr

    await env.ai.catalog()
    env.config.openrouter_api_key = SecretStr("")
    with pytest.raises(AIError, match="key_not_configured"):
        await env.ai.generate(CHAT, env.values, {}, {"question": "2+2"})
    async with env.db.sessions() as session:
        assert not await session.scalar(select(Usage))


async def test_real_sqlite_wal_fts_russian_edit_and_erasure(env):
    if env.db.pg:
        pytest.skip("SQLite-specific regression")
    await archive(env, 1, "Согласовали синий дизайн интерфейса")
    async with env.db.sessions() as session:
        assert await session.scalar(text("PRAGMA journal_mode")) == "wal"
    assert [r.message_id for r in await env.db.search(CHAT, "дизайну")] == [1]
    await env.db.edit_message(CHAT, 1, "Решили обсуждать аккумулятор")
    assert not await env.db.search(CHAT, "дизайн")
    assert [r.message_id for r in await env.db.search(CHAT, "аккумулятора")] == [1]
    # Punctuation/operators cannot become raw SQL or FTS grammar.
    await env.db.search(CHAT, '"; DROP TABLE messages; -- NOT ()*')
    assert await env.db.messages(CHAT)
    await env.db.erase_user(ADMIN)
    assert not await env.db.search(CHAT, "аккумулятор")


async def test_two_sqlite_connections_cannot_claim_same_batch(env):
    if env.db.pg:
        pytest.skip("SQLite-specific regression")
    await archive(env, 1, "Рабочая очередь для фонового анализа")
    other = Database(env.config)
    try:
        claims = await asyncio.gather(
            env.db.claim_batch(CHAT, force=True), other.claim_batch(CHAT, force=True)
        )
        assert sum(bool(c) for c in claims) == 1
    finally:
        await other.close()


async def test_two_sqlite_connections_budget_and_callback_atomicity(env):
    if env.db.pg:
        pytest.skip("SQLite-specific regression")
    other = Database(env.config)
    try:
        values = env.values | {"daily_budget": "0.01"}
        outcomes = await asyncio.gather(
            env.db.reserve(CHAT, "main", "fixture/main", Decimal(".006"), values),
            other.reserve(CHAT, "main", "fixture/main", Decimal(".006"), values),
            return_exceptions=True,
        )
        assert sum(isinstance(x, BudgetError) for x in outcomes) == 1
        token = (await env.db.panel(ADMIN, [{"op": "clear", "chat": CHAT}]))[0]
        clicks = await asyncio.gather(env.db.consume_panel(token, ADMIN), other.consume_panel(token, ADMIN))
        assert sum(bool(x) for x in clicks) == 1
    finally:
        await other.close()


async def test_restart_keeps_settings_preferences_memory_archive_queue_and_budget(env):
    await archive(env, 1, "Согласовали дизайн интерфейса")
    values = await env.db.settings(CHAT, main_model="fixture/second", background_model="fixture/bg-second")
    await env.db.preferences(CHAT, ADMIN, {"nickname": "Ожет"})
    group, _ = await env.db.group(CHAT)
    await env.db.save_memories(
        CHAT,
        [
            {
                "kind": "decision",
                "value": "Синий дизайн",
                "subject_ids": [],
                "sources": [{"message_id": 1, "user_id": ADMIN}],
                "confidence": 0.95,
                "event_date": "",
            }
        ],
        group.epoch,
    )
    memory = (await env.db.memories(CHAT, status=None))[0]
    await env.db.memory_action(CHAT, memory.id, True)
    await env.db.reserve(CHAT, "background", "fixture/bg-second", Decimal(".001"), values)
    other = Database(env.config)
    try:
        await other.initialize()
        assert (await other.group(CHAT))[1]["main_model"] == "fixture/second"
        assert (await other.preferences(CHAT, ADMIN))["nickname"] == "Ожет"
        assert (await other.memories(CHAT))[0].value == "Синий дизайн"
        assert (await other.messages(CHAT))[0].queue_state == "pending"
        assert Decimal((await other.expenses(CHAT, "UTC"))["today"]) == Decimal(".001")
        assert len(await other.search(CHAT, "дизайн")) == 1
    finally:
        await other.close()


async def test_new_database_directory_created_without_compose(tmp_path, clean_env):
    target = tmp_path / "persistent" / "data" / "jarvis.db"
    db = Database(Settings(_env_file=None, database_url=f"sqlite+aiosqlite:///{target}"))
    try:
        await db.initialize()
        assert target.is_file()
        await db.ensure_group(CHAT, "Standalone")
        assert (await db.group(CHAT))[0].title == "Standalone"
    finally:
        await db.close()


def test_runtime_check_and_main_import_in_this_interpreter():
    assert check_runtime(verbose=False)["SQLAlchemy"] == "2.0.54"
    result = subprocess.run(
        [sys.executable, "main.py", "--check"], capture_output=True, text=True, timeout=20
    )
    assert result.returncode == 0, result.stderr
    assert "runtime OK" in result.stdout and "FTS5 + JSON" in result.stdout


def test_docker_install_and_command_use_identical_venv():
    root = Path(__file__).resolve().parents[1]
    docker = (root / "Dockerfile").read_text()
    assert "FROM python:3.11-slim" in docker
    assert "/opt/venv/bin/python -m pip install" in docker
    assert '/opt/venv/bin/python", "/app/main.py' in docker
    assert "/opt/jarvis-build/runtime_check.py" in docker
    assert "aiosqlite==" in (root / "requirements.txt").read_text()
