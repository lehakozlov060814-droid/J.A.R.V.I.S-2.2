"""Offline group intelligence and durable image quotas."""
import asyncio
import json
import unittest
from unittest.mock import AsyncMock,patch
import test_nexora as f
import test_update103 as multi
n=f.n
CID,UID,BOT=f.CID,f.UID,f.BOT

class GroupTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    def reaction(self,kind):
        m=f.message('',reply=f.message('67',mid=90,uid=BOT));m.pop('text');m[kind]={'file_id':'x'};return m
    async def test_direct_calls(self):
        for i,t in enumerate(('Нексора, привет','Эй, Нексора, сколько 34 + 33?','@NexoraTestBot привет','/nexora привет'),1):
            self.app.rate.clear();await self.update(f.message(t,mid=i),i)
        self.assertEqual(len(self.net.paid()),4)
    async def test_third_person_no_calls_even_initiative_ready(self):
        self.db.c.execute('INSERT INTO nexora_activity(chat_id,day,messages) VALUES(?,?,99)',(CID,n.quota_day()))
        for i,t in enumerate(('Надо Нексору обновить','У неё опять баг','Мне кажется, она слишком часто отвечает','Её надо улучшить','Надо исправить её реакцию на всё подряд и доработать генерацию изображений'),1):
            await self.update(f.message(t,mid=i),i)
        self.assertFalse(self.net.paid());self.assertFalse(self.net.sends())
    async def test_meaningful_replies(self):
        for i,t in enumerate(('А почему именно так?','О Господи, это дама','Ты ошиблась'),1):
            self.app.rate.clear();await self.update(f.message(t,mid=i,reply=f.message('67',mid=90,uid=BOT)),i)
        self.assertEqual(len(self.net.paid()),3)
    async def test_thanks_can_silently_close_conversation(self):
        await self.update(f.message('Спасибо!',reply=f.message('67',uid=BOT)))
        self.assertFalse(self.net.paid())
    async def test_gif_sticker_emoji_are_free_to_ignore(self):
        for i,kind in enumerate(('animation','sticker'),1):await self.update(self.reaction(kind),i)
        await self.update(f.message('😂',reply=f.message('67',uid=BOT)),3)
        self.assertFalse(self.net.paid());self.assertFalse(self.net.sends())
    async def test_unsupported_media_honest_without_model(self):
        m=self.reaction('animation');m['caption']='Нексора, что на этой картинке?'
        await self.update(m)
        self.assertFalse(self.net.paid());self.assertIn('формат',self.net.sends()[-1]['text'])
    async def test_banana_not_in_math_context(self):
        cfg=self.db.group(CID)[1]
        self.db.put(f.message('Ого, банан',mid=10,uid=43),cfg,invoked=True)
        parent=f.message('34+33',mid=11,uid=UID)
        await self.update(f.message('@NexoraTestBot реши',mid=12,reply=parent))
        ctx=json.loads(self.net.paid()[-1]['messages'][1]['content'])
        self.assertNotIn('банан',json.dumps(ctx,ensure_ascii=False))
        ids=[x['id'] for x in ctx['sources']];self.assertEqual(ids[:2],[12,11])
    async def test_reply_beats_group_history_and_old_flat_session(self):
        cfg=self.db.group(CID)[1]
        for mid,text in ((10,'банан'),(11,'34+33'),(12,'67')):self.db.put(f.message(text,mid=mid,uid=BOT if mid==12 else UID),cfg,invoked=True)
        self.db.c.execute('INSERT INTO dialogues VALUES(?,?,?,?,?)',(CID,12,UID,'[10,11,12]',n.time.time()+7200))
        m=f.message('А почему именно так?',mid=13,reply=f.message('67',mid=12,uid=BOT))
        await self.update(m)
        ctx=json.loads(self.net.paid()[-1]['messages'][1]['content'])
        self.assertNotIn('банан',json.dumps(ctx,ensure_ascii=False));self.assertEqual(ctx['direct_reply_id'],12)
    async def test_storage_distinguishes_media(self):
        cfg=self.db.group(CID,archive=True)[1]
        for i,kind in enumerate(('animation','sticker','video','photo'),1):
            m=f.message('',mid=i);m[kind]=[{'file_id':'x'}] if kind=='photo' else {'file_id':'x'};self.db.put(m,cfg)
            self.assertEqual(self.db.one('SELECT kind FROM messages WHERE message_id=?',(i,))['kind'],kind)
    async def test_policy_admin_and_persistence(self):
        n.image_policy(self.db,CID);self.db.c.execute('UPDATE image_policy SET daily_cap=3 WHERE chat_id=?',(CID,))
        with self.assertRaises(n.Fault):await self.app.operate(UID,{'c':CID,'op':'image_policy','key':'daily_cap','value':3})
        self.assertEqual(n.image_policy(self.db,CID)['daily_cap'],3)
        self.net.status='member'
        with self.assertRaises(n.Fault):await self.app.operate(UID,{'c':CID,'op':'image_policy','key':'enabled','value':False})
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(n.image_policy(self.db,CID)['daily_cap'],3)
    async def test_policy_menu_real_stats(self):
        n.reserve_image(self.db,CID,UID,7,'generate');n.finish_image(self.db,CID,7,'done')
        await self.app.panel(UID,{'v':'image_limits','c':CID})
        self.assertIn('персональную квоту',self.net.sends()[-1]['text']);self.assertNotIn('Осталось: 4',self.net.sends()[-1]['text'])
    async def test_quota_and_duplicate_atomic(self):
        for mid in range(5):n.reserve_image(self.db,CID,UID,mid,'generate')
        with self.assertRaises(n.Fault):n.reserve_image(self.db,CID,43,6,'generate')
        with self.assertRaises(n.Fault):n.reserve_image(self.db,CID,UID,0,'generate')
        self.assertEqual(n.quota_stats(self.db,CID),{'used':0,'held':5})
    async def test_user_quota_and_independent_groups(self):
        n.image_policy(self.db,CID);self.db.c.execute('UPDATE image_policy SET user_cap=2 WHERE chat_id=?',(CID,))
        for mid in (1,2):n.reserve_image(self.db,CID,UID,mid,'edit');n.finish_image(self.db,CID,mid,'done')
        with self.assertRaises(n.Fault) as caught:n.reserve_image(self.db,CID,UID,3,'generate')
        self.assertEqual(caught.exception.code,'user_image_limit')
        n.reserve_image(self.db,CID,43,4,'generate');n.reserve_image(self.db,CID-1,UID,1,'generate')
    async def test_failed_releases_and_day_reset(self):
        for mid in range(6):n.reserve_image(self.db,CID,UID,mid,'generate');n.finish_image(self.db,CID,mid,'failed')
        self.assertEqual(n.quota_stats(self.db,CID)['used'],0)
        for mid in range(10,15):n.reserve_image(self.db,CID,UID,mid,'generate')
        with patch.object(n,'quota_day',return_value='2099-01-01'):
            n.reserve_image(self.db,CID,UID,20,'generate');self.assertEqual(n.quota_stats(self.db,CID)['held'],1)
    async def test_restart_uncertain_hold_and_migration_preserves_existing(self):
        n.reserve_image(self.db,CID,UID,1,'generate')
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(self.db.one('SELECT state FROM image_jobs')['state'],'uncertain')
        # Simulate upgrade from pre-quota schema, retain stored settings and usage.
        self.db.c.execute('DELETE FROM single_meta WHERE key="quota105"');self.db.c.execute('DELETE FROM image_policy')
        before=self.db.group(CID)[1];n.prepare_store(self.db)
        self.assertIsNone(n.image_policy(self.db,CID)['daily_cap']);self.assertEqual(self.db.group(CID)[1],before)
    async def test_unlimited_does_not_remove_money_protection(self):
        n.image_policy(self.db,CID);self.db.c.execute('UPDATE image_policy SET daily_cap=NULL WHERE chat_id=?',(CID,))
        self.db.group(CID,daily_budget='0')
        await self.update(f.message('@NexoraTestBot Нарисуй кота'))
        self.assertFalse([x for x in self.net.paid() if x.get('modalities')]);self.assertEqual(n.quota_stats(self.db,CID)['held'],0)
    async def test_real_workflow_success_duplicate_and_upload_failure(self):
        with patch.object(n,'send_image',new_callable=AsyncMock,side_effect=n.Fault('Telegram','timeout')) as send:
            await self.update(f.message('@NexoraTestBot Нарисуй кота'))
            await self.update(f.message('@NexoraTestBot Нарисуй кота'))
        send.assert_awaited_once();self.assertEqual(n.quota_stats(self.db,CID)['used'],1)
        self.assertEqual(len([p for p in self.net.paid() if p.get('modalities')]),1)
    async def test_generation_failure_releases_quota_billing_stays(self):
        old=self.net.call
        async def missing(url,data=None,*args,**kw):
            if data and data.get('modalities'):
                self.net.calls.append((url,data,''));return {'choices':[{'message':{'content':'not an image'}}],'usage':{'cost':.04}}
            return await old(url,data,*args,**kw)
        self.net.call=missing
        await self.update(f.message('@NexoraTestBot Нарисуй кота'))
        self.assertEqual(n.quota_stats(self.db,CID),{'used':0,'held':0});self.assertAlmostEqual(self.app.brain.costs()['day'],.04)
    async def test_new_policy_defaults_and_disable(self):
        self.assertEqual(n.image_policy(self.db,CID)['daily_cap'],5)
        self.db.c.execute('UPDATE image_policy SET enabled=0 WHERE chat_id=?',(CID,))
        await self.update(f.message('@NexoraTestBot Нарисуй кота'));self.assertFalse(self.net.paid())
    async def test_text_parts_json_accepted_without_replay(self):
        old=self.net.call
        async def parts(url,data=None,*args,**kw):
            result=await old(url,data,*args,**kw)
            if url.endswith('/chat/completions'):
                result['choices'][0]['message']['content']=[{'type':'text','text':'{"answer":"67"}'}]
            return result
        self.net.call=parts
        await self.update(f.message('@NexoraTestBot 34+33'))
        self.assertEqual(self.net.sends()[-1]['text'],'67');self.assertEqual(len(self.net.paid()),1)

    async def test_concurrent_quota_reservations_cannot_overbook(self):
        async def attempt(mid):
            try:
                n.reserve_image(self.db,CID,mid,mid,'generate');return True
            except n.Fault:return False
        result=await asyncio.gather(*(attempt(mid) for mid in range(10)))
        self.assertEqual(sum(result),5);self.assertEqual(n.quota_stats(self.db,CID)['held'],5)


if __name__=='__main__':unittest.main()
