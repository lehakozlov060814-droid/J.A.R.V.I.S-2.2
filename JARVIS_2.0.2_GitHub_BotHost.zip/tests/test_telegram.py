import json

import pytest
from aiogram import Dispatcher
from aiogram.types import CallbackQuery, Update
from conftest import ADMIN, BOT_ID, CHAT, archive, make_message

from ai import AIError
from main import Deduplicate, invocation, question_text, require_admin, split_text


@pytest.mark.parametrize(
    "text,expected",
    [
        ("@JarvisFixtureBot реши", True),
        ("@jarvisfixturebot кто прав?", True),
        ("/jarvis что происходит?", True),
        ("/jarvis@JarvisFixtureBot 2+2", True),
        ("/jarvis@OtherBot вопрос", False),
        ("Привет всем", False),
        ("@JarvisFixtureBotOther не тебе", False),
    ],
)
def test_invocation_variants(env, text, expected):
    assert invocation(make_message(env.bot, text), BOT_ID, "JarvisFixtureBot") is expected


async def test_reply_invocation_and_photo_caption(env):
    bot_reply = make_message(env.bot, "4, сэр.", uid=BOT_ID, is_bot=True)
    message = make_message(env.bot, "Почему?", mid=2, reply=bot_reply)
    assert invocation(message, BOT_ID, "JarvisFixtureBot")
    assert invocation(make_message(env.bot, "@JarvisFixtureBot реши", photo=True), BOT_ID, "JarvisFixtureBot")
    assert question_text(make_message(env.bot, "/jarvis@JarvisFixtureBot 2+2"), "JarvisFixtureBot") == "2+2"


async def test_group_handler_actual_pipeline_and_continuation(env):
    original = make_message(env.bot, "2+2", uid=43, mid=10)
    call = make_message(env.bot, "@JarvisFixtureBot реши", mid=11, reply=original)
    await env.app.group_message(call)
    sends = [x for x in env.telegram.requests if type(x).__name__ == "SendMessage"]
    assert sends[-1].text == "4, сэр."
    records = await env.db.messages(CHAT)
    assert {10, 11}.issubset({r.message_id for r in records})
    sent = make_message(env.bot, "4, сэр.", mid=env.telegram.counter, uid=BOT_ID, is_bot=True)
    assert await env.db.dialogue(CHAT, ADMIN, sent.message_id)
    # Follow-up comes from same user and a distinct Telegram update, rate gate reset for the fixture.
    async with env.db.transaction() as s:
        from sqlalchemy import delete

        from database import Rate

        await s.execute(delete(Rate))
    await env.app.group_message(make_message(env.bot, "А почему?", mid=12, reply=sent))
    posts = [json.loads(r.content) for r in env.http.requests if r.method == "POST"]
    context = json.loads(posts[-1]["messages"][1]["content"])
    assert context["question"] == "А почему?" and context["sources"]["session"]


async def test_non_called_message_does_not_spend_tokens(env):
    await env.app.group_message(make_message(env.bot, "Обычная содержательная переписка без вызова"))
    assert not env.http.requests


async def test_personal_preference_saves_only_current_user(env):
    await env.app.group_message(make_message(env.bot, "/jarvis Называй меня Ожет"))
    assert (await env.db.preferences(CHAT, ADMIN))["nickname"] == "Ожет"
    assert not await env.db.preferences(CHAT, 43)
    assert not env.http.requests


async def test_no_vision_does_not_claim_to_see_image(env):
    await env.app.group_message(make_message(env.bot, "/jarvis что на фото?", photo=True))
    sends = [m for m in env.telegram.requests if type(m).__name__ == "SendMessage"]
    assert "не поддерживает изображения" in sends[-1].text
    assert not [r for r in env.http.requests if r.method == "POST"]


@pytest.mark.parametrize("status,allowed", [("creator", True), ("administrator", True), ("member", False)])
async def test_administrator_authority(env, status, allowed):
    env.telegram.status = status
    if allowed:
        await require_admin(env.bot, CHAT, ADMIN)
    else:
        with pytest.raises(PermissionError):
            await require_admin(env.bot, CHAT, ADMIN)


async def test_owner_has_no_group_content_bypass(env):
    env.telegram.status = "member"
    with pytest.raises(PermissionError):
        await env.app.screen(make_message(env.bot, private=True), ADMIN, {"view": "memory", "chat": CHAT})
    await env.app.screen(make_message(env.bot, private=True), ADMIN, {"view": "service"})
    last = env.telegram.requests[-1]
    assert "Общие расходы" in last.text and "Fixture group" not in last.text


@pytest.mark.parametrize(
    "view",
    [
        "home",
        "groups",
        "help",
        "personal",
        "personal_memories",
        "erase_confirm",
        "group",
        "models",
        "catalog",
        "filters",
        "character",
        "memory",
        "browse",
        "archive_confirm",
        "clear_confirm",
        "privacy",
        "background",
        "queue",
        "run_confirm",
        "costs",
        "general",
        "diagnostics",
        "personality",
    ],
)
async def test_real_panel_screens_have_valid_owned_callbacks(env, view):
    action = {"view": view}
    if view not in {"home", "groups", "help", "personal", "personal_memories", "erase_confirm"}:
        action["chat"] = CHAT
    if view in {"catalog", "filters"}:
        action["role"] = "main"
    if view == "archive_confirm":
        action["value"] = True
    await env.app.screen(make_message(env.bot, private=True), ADMIN, action)
    last = env.telegram.requests[-1]
    assert last.text and len(last.text) <= 4000
    assert last.reply_markup.inline_keyboard
    for row in last.reply_markup.inline_keyboard:
        data = row[0].callback_data
        assert len(data.encode()) <= 64
        assert await env.db.consume_panel(data[2:], 999) is None


async def test_lost_rights_rechecked_on_every_click_and_input(env):
    target = make_message(env.bot, private=True)
    await env.app.screen(target, ADMIN, {"view": "group", "chat": CHAT})
    callback_data = env.telegram.requests[-1].reply_markup.inline_keyboard[0][0].callback_data
    env.telegram.status = "member"
    cb = CallbackQuery.model_validate(
        {
            "id": "fixture-callback",
            "from": {"id": ADMIN, "is_bot": False, "first_name": "A"},
            "chat_instance": "fixture",
            "data": callback_data,
            "message": make_message(env.bot, private=True, chat_id=ADMIN, uid=BOT_ID, is_bot=True).model_dump(
                mode="json", exclude_none=True
            ),
        },
        context={"bot": env.bot},
    )
    await env.app.callback(cb)
    assert "администраторам" in env.telegram.requests[-1].text
    await env.db.input_state(ADMIN, {"chat": CHAT, "kind": "daily_budget"})
    await env.app.private(make_message(env.bot, "999", private=True))
    assert (await env.db.group(CHAT))[1]["daily_budget"] == "0.50"


async def test_callbacks_are_single_use_bound_and_stale(env):
    tokens = await env.db.panel(ADMIN, [{"op": "clear", "chat": CHAT}])
    assert not await env.db.consume_panel(tokens[0], 43)
    assert await env.db.consume_panel(tokens[0], ADMIN)
    assert not await env.db.consume_panel(tokens[0], ADMIN)
    old = await env.db.panel(ADMIN, [{"view": "group", "chat": CHAT}])
    await env.db.panel(ADMIN, [{"view": "home"}])
    assert not await env.db.consume_panel(old[0], ADMIN)


async def test_apply_model_and_failed_check_do_not_change_selection(env):
    target = make_message(env.bot, private=True)
    await env.app.operate(
        target, ADMIN, {"op": "apply_model", "chat": CHAT, "role": "main", "model": "fixture/second"}
    )
    assert (await env.db.group(CHAT))[1]["main_model"] == "fixture/second"
    env.http.status = 429
    with pytest.raises(AIError):
        await env.app.operate(
            target, ADMIN, {"op": "test", "chat": CHAT, "role": "main", "model": "fixture/main"}
        )
    assert (await env.db.group(CHAT))[1]["main_model"] == "fixture/second"


async def test_archive_notification_must_succeed_before_enabling(env):
    env.telegram.deny_notice = True
    from aiogram.exceptions import TelegramForbiddenError

    with pytest.raises(TelegramForbiddenError):
        await env.app.operate(
            make_message(env.bot, private=True), ADMIN, {"op": "archive", "chat": CHAT, "value": True}
        )
    assert not (await env.db.group(CHAT))[1]["archive"]
    env.telegram.deny_notice = False
    await env.app.operate(
        make_message(env.bot, private=True), ADMIN, {"op": "archive", "chat": CHAT, "value": True}
    )
    assert (await env.db.group(CHAT))[1]["archive"]
    assert any(
        "Память J.A.R.V.I.S. включена" in (getattr(m, "text", "") or "") for m in env.telegram.requests
    )


async def test_private_is_control_panel_and_input_cancel_works(env):
    await env.app.private(make_message(env.bot, "Просто поболтаем?", private=True))
    assert not env.http.requests and "панель управления" in env.telegram.requests[-1].text
    await env.db.input_state(ADMIN, {"chat": CHAT, "kind": "daily_budget"})
    await env.app.screen(make_message(env.bot, private=True), ADMIN, {"view": "home"})
    assert not await env.db.input_state(ADMIN)


async def test_budget_settings_validation_and_persistence(env):
    await env.db.input_state(ADMIN, {"chat": CHAT, "kind": "daily_budget"})
    await env.app.private(make_message(env.bot, "NaN", private=True))
    assert (await env.db.group(CHAT))[1]["daily_budget"] == "0.50"
    await env.app.private(make_message(env.bot, "0,25", private=True))
    assert (await env.db.group(CHAT))[1]["daily_budget"] == "0.25"
    assert not await env.db.input_state(ADMIN)


async def test_dispatcher_deduplicates_real_updates(env):
    dp = Dispatcher()
    dp.update.outer_middleware(Deduplicate(env.db))
    dp.include_router(env.app.router)
    update = Update(update_id=12345, message=make_message(env.bot))
    await dp.feed_update(env.bot, update)
    await dp.feed_update(env.bot, update)
    assert len([r for r in env.http.requests if r.method == "POST"]) == 1


async def test_private_memory_hides_personal_records(env):
    await archive(env, 1, "Сведения о человеке")
    group, _ = await env.db.group(CHAT)
    await env.db.save_memories(
        CHAT,
        [
            {
                "kind": "nickname",
                "value": "Скрытое прозвище",
                "subject_ids": [43],
                "sources": [{"message_id": 1, "user_id": 43}],
                "confidence": 1,
                "event_date": "",
            }
        ],
        group.epoch,
    )
    await env.app.screen(make_message(env.bot, private=True), ADMIN, {"view": "browse", "chat": CHAT})
    assert "Скрытое прозвище" not in env.telegram.requests[-1].text


def test_telegram_unicode_length():
    parts = split_text("😅" * 5000)
    assert "".join(parts) == "😅" * 5000
    assert all(len(p.encode("utf-16-le")) // 2 <= 4096 for p in parts)


async def test_vision_downloads_bytes_without_sending_telegram_token(env):
    await env.db.settings(CHAT, main_model="fixture/vision")
    await env.app.group_message(make_message(env.bot, "/jarvis что на фото?", photo=True))
    post = [r for r in env.http.requests if r.method == "POST"][-1]
    payload = json.loads(post.content)
    image_url = payload["messages"][1]["content"][1]["image_url"]["url"]
    assert image_url.startswith("data:image/jpeg;base64,")
    assert "api.telegram.org" not in str(post.content) and env.bot.token not in str(post.content)


async def test_database_failure_returns_short_response_without_llm(env, monkeypatch):
    from sqlalchemy.exc import OperationalError

    async def broken(*args, **kwargs):
        raise OperationalError("fixture", {}, Exception("must not leak"))

    monkeypatch.setattr(env.db, "receipt", broken)

    async def handler(*args):
        raise AssertionError("Handler must not run")

    update = Update(update_id=555, message=make_message(env.bot))
    await Deduplicate(env.db)(handler, update, {})
    last = env.telegram.requests[-1]
    assert "хранилище временно недоступно" in last.text
    assert "must not leak" not in last.text and not env.http.requests
