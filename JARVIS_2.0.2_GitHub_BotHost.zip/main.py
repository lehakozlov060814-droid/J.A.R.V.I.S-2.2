"""Telegram handlers and the private InlineKeyboard control panel."""

import asyncio
import base64
import contextlib
import io
import json
import logging
import re
import sys
import time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zoneinfo import ZoneInfo

from runtime_check import check_runtime

# Detect a stale/wrong interpreter before third-party imports produce an unhelpful traceback.
if __name__ == "__main__":
    try:
        check_runtime()
    except Exception as exc:
        raise SystemExit(f"JARVIS 2.0.2 runtime check: {type(exc).__name__}: {exc}") from None

from aiogram import BaseMiddleware, Bot, Dispatcher, F, Router
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import CommandStart
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    ChatMemberUpdated,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    ReplyParameters,
    Update,
)
from sqlalchemy import func, select
from sqlalchemy.exc import SQLAlchemyError

from ai import AIError, BudgetError, OpenRouter
from config import Settings
from database import Database, Group, Usage
from memory import MemoryEngine, meaningful, preference_request

log = logging.getLogger("jarvis")

NOTICE = (
    "Память J.A.R.V.I.S. включена администратором. Бот сохраняет новые доступные "
    "сообщения этой группы, ищет по ним и отправляет выбранные фрагменты через OpenRouter "
    "провайдеру выбранной модели. Фоновый анализ создаёт кандидаты воспоминаний. "
    "Старой истории до добавления бота у него нет. В личке: /start → Личные данные — "
    "экспорт своих данных, удаление и отказ от сохранения. /privacy — правила. "
)


def invocation(message: Message, bot_id: int, username: str) -> bool:
    body = message.text or message.caption or ""
    command = re.match(r"^/jarvis(?:@([\w]+))?(?:\s|$)", body, re.I)
    if command:
        return not command[1] or command[1].lower() == username.lower()
    if re.search(rf"(?<!\w)@{re.escape(username)}(?!\w)", body, re.I):
        return True
    if (
        message.reply_to_message
        and message.reply_to_message.from_user
        and message.reply_to_message.from_user.id == bot_id
    ):
        return True
    return any(
        entity.type == "text_mention" and entity.user and entity.user.id == bot_id
        for entity in (message.entities or message.caption_entities or [])
    )


def question_text(message: Message, username: str) -> str:
    body = message.text or message.caption or ""
    body = re.sub(
        rf"^/jarvis(?:@{re.escape(username)})?\s*|@{re.escape(username)}\b", "", body, flags=re.I
    ).strip()
    return body or ("Опиши изображение." if message.photo else "Что скажете об этом?")


async def require_admin(bot: Bot, chat_id: int, user_id: int):
    # Fail closed. No BOT_OWNER_ID bypass and no cached permanent authorization.
    try:
        member = await bot.get_chat_member(chat_id, user_id)
    except TelegramAPIError:
        raise PermissionError(
            "Не удалось проверить права. Убедитесь, что бот — администратор группы."
        ) from None
    if member.status == "creator":
        return
    if member.status != "administrator" or not getattr(member, "can_manage_chat", False):
        raise PermissionError("Настройки доступны действующим администраторам с правом управления группой.")


def split_text(text: str, maximum=3900) -> list[str]:
    # Telegram length is UTF-16 code units. 1900 Unicode code points are safe even for emoji.
    maximum = min(maximum, 1900)
    chunks = []
    while text:
        cut = len(text) if len(text) <= maximum else text.rfind("\n", 0, maximum)
        if cut < maximum // 2 and len(text) > maximum:
            cut = maximum
        chunks.append(text[:cut])
        text = text[cut:].lstrip("\n")
    return chunks or ["Сэр, ответ оказался пуст. Попробуйте уточнить запрос."]


class Deduplicate(BaseMiddleware):
    def __init__(self, database):
        self.db = database

    async def __call__(self, handler, event: Update, data):
        try:
            if not await self.db.receipt(event.update_id):
                return
            return await handler(event, data)
        except SQLAlchemyError:
            log.error("Database temporarily unavailable while processing update")
            with contextlib.suppress(TelegramAPIError):
                if event.callback_query:
                    await event.callback_query.answer(
                        "База данных временно недоступна. Попробуйте позже.", show_alert=True
                    )
                elif event.message:
                    body = event.message.text or event.message.caption or ""
                    if event.message.chat.type == "private" or body.startswith("/jarvis") or "@" in body:
                        await event.message.reply(
                            "Сэр, хранилище временно недоступно. Попробуйте чуть позже."
                        )
        except Exception:
            with contextlib.suppress(SQLAlchemyError):
                await self.db.release_receipt(event.update_id)
            raise


class App:
    def __init__(self, config: Settings, db: Database, ai: OpenRouter, bot: Bot, bot_id: int, username: str):
        self.config, self.db, self.ai, self.bot = config, db, ai, bot
        self.bot_id, self.username = bot_id, username
        self.memory = MemoryEngine(db, ai, config)
        self.router = Router()
        self.router.message.register(self.private_start, CommandStart(), F.chat.type == "private")
        self.router.message.register(self.private, F.chat.type == "private")
        self.router.callback_query.register(self.callback)
        self.router.message.register(self.group_message, F.chat.type.in_({"group", "supergroup"}))
        self.router.edited_message.register(self.edited, F.chat.type.in_({"group", "supergroup"}))
        self.router.my_chat_member.register(self.membership)

    async def render(
        self, target: Message, user_id: int, text: str, buttons: list[tuple[str, dict]], edit=False
    ):
        tokens = await self.db.panel(user_id, [action for _, action in buttons])
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=label[:60], callback_data="j:" + token)]
                for (label, _), token in zip(buttons, tokens)
            ]
        )
        if edit:
            try:
                await target.edit_text(
                    text[:4000],
                    reply_markup=keyboard,
                    parse_mode=None,
                    link_preview_options={"is_disabled": True},
                )
                return
            except TelegramBadRequest as exc:
                if "message is not modified" in str(exc):
                    return
                if "message to edit not found" not in str(exc) and "message can't be edited" not in str(exc):
                    raise
        await target.answer(
            text[:4000], reply_markup=keyboard, parse_mode=None, link_preview_options={"is_disabled": True}
        )

    async def private_start(self, message: Message):
        await self.db.input_state(message.from_user.id, consume=True)
        await self.screen(message, message.from_user.id, {"view": "home"})

    async def screen(self, target: Message, uid: int, action: dict, edit=False):
        view = action.get("view", "home")
        cid = action.get("chat")
        group = values = None
        if cid is not None:
            await require_admin(self.bot, cid, uid)
            group, values = await self.db.group(cid)
            if not group.active:
                raise ValueError("Бот больше не присутствует в группе")

        def dest(name, **extra):
            return {"view": name, **({"chat": cid} if cid is not None else {}), **extra}

        back = (
            [("Назад", dest("group")), ("Главная", {"view": "home"})]
            if cid
            else [("Главная", {"view": "home"})]
        )
        text, buttons = "", []
        if view == "home":
            await self.db.input_state(uid, consume=True)
            text = (
                "Приветствую, сэр.\n\nСистемы J.A.R.V.I.S. к вашим услугам. "
                "В личке находится панель управления; общаюсь я в группах."
            )
            if not self.config.openrouter_api_key.get_secret_value():
                text += "\n\nКлюч OpenRouter пока не задан на сервере. Панель доступна; ИИ-ответы заработают после настройки OPENROUTER_API_KEY."
            buttons = [
                ("Мои группы", {"view": "groups", "page": 0}),
                ("Личные данные", {"view": "personal"}),
                ("Справка", {"view": "help"}),
            ]
            if uid == self.config.bot_owner_id:
                buttons.append(("Обслуживание", {"view": "service"}))
        elif view == "service":
            if uid != self.config.bot_owner_id:
                raise PermissionError("Нет служебного доступа")
            async with self.db.sessions() as session:
                groups = await session.scalar(select(func.count()).select_from(Group))
                costs = await session.scalar(select(func.coalesce(func.sum(Usage.cost), 0)))
            text = (
                f"Обслуживание\nБД: соединение работает\nИзвестных групп: {groups}\n"
                f"Общие расходы за всё время: ${costs}\nКлюч OpenRouter: "
                f"{'настроен' if self.config.openrouter_api_key.get_secret_value() else 'не настроен'}\n"
                "Служебный доступ не открывает содержимое групп или личных данных."
            )
            buttons = back
        elif view == "help":
            text = (
                "Добавьте бота в группу и назначьте администратором для надёжной проверки прав. "
                "В BotFather /setprivacy → Disable позволяет получать обычные сообщения; "
                "после изменения пере-добавьте бота. Архив изначально выключен.\n\n"
                "В группе: /jarvis вопрос, @" + self.username + " или ответ на моё сообщение. "
                "Можно ответить на чужое сообщение и позвать меня. /privacy — правила.\n\n"
                "Для модели: Мои группы → Группа → Модели ИИ. "
                "Ключ OpenRouter задаётся только в .env на сервере. "
                "Включение архива уведомляет группу. Подтверждайте кандидаты памяти в панели; "
                "персональные записи подтверждает сам участник. "
                "Поиск в личке ищет сжатую групповую память, не выдаёт полный архив."
            )
            buttons = back
        elif view == "groups":
            allowed = []
            for item in await self.db.groups():
                try:
                    await require_admin(self.bot, item.id, uid)
                    allowed.append(item)
                except PermissionError:
                    continue
            page = max(0, int(action.get("page", 0)))
            text = (
                "Выберите группу."
                if allowed
                else "Доступных групп пока нет. Добавьте бота в группу и откройте панель от имени её действующего администратора."
            )
            buttons = [(g.title, {"view": "group", "chat": g.id}) for g in allowed[page * 8 : (page + 1) * 8]]
            if page:
                buttons.append(("←", {"view": "groups", "page": page - 1}))
            if len(allowed) > (page + 1) * 8:
                buttons.append(("→", {"view": "groups", "page": page + 1}))
            buttons += [("Главная", {"view": "home"})]
        elif view == "group":
            text = (
                f"J.A.R.V.I.S. — Управление\nГруппа: {group.title}\n\n"
                f"Основная модель: {values['main_model'] or 'автовыбор при первом запросе'}\n"
                f"Фоновая модель: {values['background_model'] or 'автовыбор при первом анализе'}\n"
                f"Архив: {'включён' if values['archive'] else 'выключен'}\n"
                f"Фоновый анализ: {'включён' if values['background'] else 'выключен'}"
            )
            buttons = [
                (label, dest(name))
                for label, name in [
                    ("Модели ИИ", "models"),
                    ("Память", "memory"),
                    ("Характер", "character"),
                    ("Расходы", "costs"),
                    ("Фоновый анализ", "background"),
                    ("Общие настройки", "general"),
                    ("Диагностика", "diagnostics"),
                ]
            ]
            buttons += [("Назад", {"view": "groups"}), ("Главная", {"view": "home"})]
        elif view == "models":
            text = (
                f"Модели ИИ\nОсновная: {values['main_model'] or 'автовыбор при первом запросе'}\n"
                f"Фоновая: {values['background_model'] or 'автовыбор при первом анализе'}\n"
                f"Эмбеддинги: {values['embedding_model'] or 'не выбрана'}\n"
                "Смена модели сохраняет личность, настройки и память."
            )
            buttons = [
                (label, dest("catalog", role=role, page=0))
                for label, role in [
                    ("Изменить основную", "main"),
                    ("Изменить фоновую", "background"),
                    ("Изменить эмбеддинги", "embedding"),
                ]
            ]
            buttons += [
                ("Проверить подключение", dest("test_confirm", role="main")),
                ("Тест личности", dest("personality")),
                ("Сбросить модели", dest("reset_confirm")),
            ] + back
        elif view == "catalog":
            role, page = action.get("role", "main"), max(0, int(action.get("page", 0)))
            catalog = await self.ai.catalog(refresh=action.get("refresh", False))
            favorites = await self.db.favorites(uid)
            query, feature = action.get("query", ""), action.get("filter", "all")
            models = [
                m
                for m in catalog.values()
                if m.compatible(role)
                and query.lower() in (m.name + m.id).lower()
                and (feature != "vision" or m.vision)
                and (feature != "structured" or "structured_outputs" in m.parameters)
                and (feature != "favorites" or m.id in favorites)
                and (feature != "free" or m.pricing.get("prompt") == "0")
            ]
            models.sort(key=lambda m: m.name.lower())
            text = f"Каталог: {role}. Найдено {len(models)}; страница {page + 1}.\n"
            for m in models[page * 4 : (page + 1) * 4]:
                text += "\n" + m.describe() + "\n"
                buttons.append((m.name, dest("model", role=role, model=m.id)))
            common = {"role": role, "query": query, "filter": feature}
            if page:
                buttons.append(("← Предыдущая", dest("catalog", page=page - 1, **common)))
            if len(models) > (page + 1) * 4:
                buttons.append(("Следующая →", dest("catalog", page=page + 1, **common)))
            buttons += [
                ("Поиск по названию", {"op": "input", "chat": cid, "kind": "model_search", "role": role}),
                ("Фильтры", dest("filters", role=role)),
                ("Обновить каталог", dest("catalog", role=role, refresh=True)),
                ("Назад", dest("models")),
                ("Главная", {"view": "home"}),
            ]
        elif view == "filters":
            text = "Фильтр каталога"
            buttons = [
                (label, dest("catalog", role=action["role"], filter=feature))
                for label, feature in [
                    ("Все совместимые", "all"),
                    ("Vision", "vision"),
                    ("Structured output", "structured"),
                    ("Избранное", "favorites"),
                    ("Бесплатный вход", "free"),
                ]
            ] + back
        elif view == "model":
            model = await self.ai.model(action["model"], action["role"])
            text = model.describe() + "\n\nУстановить модель? Применение не вызывает платный API."
            if action["role"] == "main" and not model.vision:
                text += "\nИзображения этой моделью анализироваться не будут."
            buttons = [
                ("Применить", {"op": "apply_model", "chat": cid, "role": action["role"], "model": model.id}),
                ("Короткий тест (платно)", dest("test_confirm", role=action["role"], model=model.id)),
                (
                    "★ Добавить/убрать избранное",
                    {"op": "favorite", "chat": cid, "role": action["role"], "model": model.id},
                ),
                ("Отмена", dest("models")),
                ("Главная", {"view": "home"}),
            ]
        elif view == "reset_confirm":
            text = "Вернуть три модели к значениям из .env? Память и характер сохранятся."
            buttons = [("Сбросить", {"op": "reset", "chat": cid}), ("Отмена", dest("models"))]
        elif view == "test_confirm":
            role = action.get("role", "main")
            model = await self.ai.model(action.get("model") or values[role + "_model"], role)
            text = (
                model.describe() + f"\n\nПлатный тест подключения. На запрос резервируется не более "
                f"${self.config.max_request_usd}. При превышении оценки тест заблокируется. "
                "Выбор модели не изменится."
            )
            buttons = [
                ("Запустить тест", {"op": "test", "chat": cid, "role": role, "model": model.id})
            ] + back
        elif view == "personality":
            text = (
                "Тест личности: 36 сценариев. Модель получит тот же системный характер. "
                "Автоматические проверки стиля эвристические; примеры нужны для вашей оценки. "
                f"Каждый запрос — до ${self.config.max_request_usd} по внутренней резервации. "
                "Общие бюджеты действуют. Полный тест может быть дорогим."
            )
            buttons = [
                ("3 примера (платно)", {"op": "personality", "chat": cid, "count": 3}),
                ("Все 36 (платно)", {"op": "personality", "chat": cid, "count": 36}),
            ] + back
        elif view == "character":
            text = (
                f"Характер\nЮмор: {values['humor']}\nМат: {values['profanity']}\n"
                f"Манера: {values['tone']}\nДлина: {values['length']}\nБазовый образ Джарвиса сохраняется."
            )
            buttons = [
                (label, dest("choose", key=key))
                for label, key in [
                    ("Стиль юмора", "humor"),
                    ("Манера общения", "tone"),
                    ("Длина ответов", "length"),
                ]
            ]
            buttons += [
                (
                    "Переключить мат",
                    {
                        "op": "set",
                        "chat": cid,
                        "key": "profanity",
                        "value": not values["profanity"],
                        "return": "character",
                    },
                )
            ] + back
        elif view == "choose":
            choices = {
                "humor": [
                    ("Сдержанный", "reserved"),
                    ("Классический Джарвис", "classic"),
                    ("Более мемный", "meme"),
                ],
                "tone": [
                    ("Официальная", "formal"),
                    ("Сбалансированная", "balanced"),
                    ("Разговорная", "casual"),
                ],
                "length": [
                    ("Очень короткие", "short"),
                    ("Адаптивные", "adaptive"),
                    ("Подробные", "detailed"),
                ],
            }
            key = action["key"]
            text = "Выберите значение."
            buttons = [
                (label, {"op": "set", "chat": cid, "key": key, "value": value, "return": "character"})
                for label, value in choices[key]
            ] + back
        elif view == "memory":
            stats = await self.db.stats(cid)
            text = (
                f"Память\nАрхив: {values['archive']}\nСообщений: {stats['messages']}\n"
                f"Записей (включая кандидаты): {stats['memory_total']}\nСобытий: {stats['memories'].get('event', 0)}\n"
                f"Мемов: {stats['memories'].get('meme', 0)}\nОчередь: {stats['queue']}\n"
                f"Последний анализ: {self.when(group.last_background)}\nХранение: {values['retention_days']} дней.\n"
                "Полный архив в личке не выдаётся. Персональные записи видны только их владельцу."
            )
            buttons = [
                ("Просмотр памяти", dest("browse", page=0)),
                ("Поиск по памяти", {"op": "input", "chat": cid, "kind": "memory_search"}),
                (
                    "Выключить архив" if values["archive"] else "Включить архив",
                    dest("archive_confirm", value=not values["archive"]),
                ),
                ("Фоновая обработка", dest("background")),
                ("Срок хранения", {"op": "input", "chat": cid, "kind": "retention_days"}),
                ("Очистка памяти", dest("clear_confirm")),
                ("Приватность", dest("privacy")),
            ] + back
        elif view == "browse":
            items = [
                m
                for m in await self.db.memories(cid, status=None, query=action.get("query", ""), limit=5000)
                if not m.subject_ids
            ]
            page = max(0, int(action.get("page", 0)))
            text = f"Групповая память: {len(items)} записей. Новые кандидаты требуют подтверждения.\n"
            for item in items[page * 3 : (page + 1) * 3]:
                text += f"\n#{item.id} [{item.kind}, {item.status}, {item.confidence:.0%}] {item.value}\n"
                text += (
                    "Источники: "
                    + ", ".join(x.get("link") or f"message {x['message_id']}" for x in item.sources)
                    + "\n"
                )
                if item.status == "pending":
                    buttons.append(
                        (
                            f"Подтвердить #{item.id}",
                            {"op": "memory", "chat": cid, "id": item.id, "approve": True},
                        )
                    )
                buttons.append(
                    (f"Удалить #{item.id}", {"op": "memory", "chat": cid, "id": item.id, "approve": False})
                )
            if page:
                buttons.append(("←", dest("browse", page=page - 1, query=action.get("query", ""))))
            if len(items) > (page + 1) * 3:
                buttons.append(("→", dest("browse", page=page + 1, query=action.get("query", ""))))
            buttons += [("Назад", dest("memory")), ("Главная", {"view": "home"})]
        elif view == "archive_confirm":
            value = action["value"]
            text = (
                NOTICE + f"\nСрок хранения: {values['retention_days']} дней. Включить?"
                if value
                else "Остановить новое архивирование и фоновую очередь? Уже сохранённая история останется до срока хранения или очистки."
            )
            buttons = [
                ("Подтвердить", {"op": "archive", "chat": cid, "value": value}),
                ("Отмена", dest("memory")),
            ]
        elif view == "clear_confirm":
            text = "Удалить архив, сжатую память, очередь и сессии этой группы? Операция необратима. Финансовый учёт останется."
            buttons = [("Удалить данные группы", {"op": "clear", "chat": cid}), ("Отмена", dest("memory"))]
        elif view == "privacy":
            text = (
                "Архивирование включается администратором с уведомлением группы. Доступная история "
                "может использоваться в ответах внутри самой группы. Личные сообщения не архивируются. "
                "Персональные данные и отказ от записи: Главная → Личные данные. "
                "Данные запросов передаются через OpenRouter выбранному провайдеру; его политика хранения действует отдельно. "
                "Удаление здесь не удаляет уже отправленные сообщения Telegram и резервные копии сервера. "
                "Приватный режим поиска и полный архив в личке отсутствуют."
            )
            buttons = [("Мои персональные данные", {"view": "personal"})] + back
        elif view == "background":
            stats = await self.db.stats(cid)
            costs = await self.db.expenses(cid, values["timezone"])
            background_cost = sum(
                (Decimal(costs["today_by_purpose"].get(p, "0")) for p in ("background", "embedding")),
                Decimal(0),
            )
            text = (
                f"Фоновый анализ: {values['background']}\nМодель: {values['background_model']}\n"
                f"Последний анализ: {self.when(group.last_background)}\nОчередь: {stats['queue']}\n"
                f"Фон и эмбеддинги сегодня: ${background_cost}\nПериод: {values['interval_minutes']} мин. "
                f"или порог {values['threshold']} сообщений\nБюджет фона/сутки: ${values['background_budget']}\n"
                "Анализ требует включённого архива. Время/порог — альтернативные условия запуска."
            )
            buttons = [
                (
                    "Включить/выключить",
                    {
                        "op": "set",
                        "chat": cid,
                        "key": "background",
                        "value": not values["background"],
                        "return": "background",
                    },
                ),
                ("Изменить модель", dest("catalog", role="background")),
                ("Периодичность", {"op": "input", "chat": cid, "kind": "interval_minutes"}),
                ("Порог сообщений", {"op": "input", "chat": cid, "kind": "threshold"}),
                ("Бюджет фона", {"op": "input", "chat": cid, "kind": "background_budget"}),
                ("Запустить сейчас", dest("run_confirm")),
                ("Состояние очереди", dest("queue")),
            ] + back
        elif view == "queue":
            stats = await self.db.stats(cid)
            text = (
                "Очередь\n"
                + json.dumps(stats["queue"], ensure_ascii=False)
                + "\npending — ожидает, processing — в работе, done — обработано, "
                "failed — 3 ошибки, overflow — не вошло в очередь. "
                "После перезапуска незавершённая аренда освобождается через 5 минут."
            )
            buttons = [("Повторить failed/overflow", {"op": "retry_queue", "chat": cid})] + back
        elif view == "run_confirm":
            text = (
                f"Запустить одну фоновую пачку до 60 сообщений? Максимальная внутренняя "
                f"резервация запроса ${self.config.max_request_usd}; зависит от цены модели и объёма. "
                "Бюджеты действуют. Архив должен быть включён."
            )
            buttons = [("Запустить", {"op": "run", "chat": cid})] + back
        elif view == "costs":
            costs = await self.db.expenses(cid, values["timezone"])
            avg = Decimal(costs["month"]) / costs["requests"] if costs["requests"] else Decimal(0)
            text = (
                f"Расходы ({values['timezone']})\nСегодня: ${costs['today']}\n"
                f"7 календарных дней: ${costs['week']}\nМесяц: ${costs['month']}\n"
                f"Запросов за месяц: {costs['requests']}; средний ${avg:.6f}\n"
                f"Токены: вход {costs['input_tokens']}; выход {costs['output_tokens']}\n"
                f"По назначению за месяц: {costs['by_purpose']}\n"
                f"Приблизительных: {costs['estimated']}; в работе: {costs['reserved']}\n"
                f"Лимит день/месяц/фон: ${values['daily_budget']} / ${values['monthly_budget']} / ${values['background_budget']}\n"
                "Оценки и незавершённые резервации входят в суммы. Внутренний лимит не гарантирует итоговый счёт провайдера."
            )
            buttons = [
                (label, {"op": "input", "chat": cid, "kind": key})
                for label, key in [
                    ("Дневной лимит", "daily_budget"),
                    ("Месячный лимит", "monthly_budget"),
                    ("Фоновый лимит", "background_budget"),
                ]
            ] + back
        elif view == "general":
            text = (
                f"Общие настройки\nЧасовой пояс: {values['timezone']}\nСемантический поиск: {values['semantic']}\n"
                "Лексический поиск и Reply работают без эмбеддингов. Семантика индексирует только подтверждённую сжатую память и расходует API-бюджет."
            )
            buttons = [
                ("Часовой пояс", {"op": "input", "chat": cid, "kind": "timezone"}),
                (
                    "Включить/выключить семантику",
                    {
                        "op": "set",
                        "chat": cid,
                        "key": "semantic",
                        "value": not values["semantic"],
                        "return": "general",
                    },
                ),
            ] + back
        elif view == "diagnostics":
            stats = await self.db.stats(cid)
            text = (
                f"Диагностика\nБД: доступна\nГруппа активна: {group.active}\n"
                f"Каталог кэширован: {len(self.ai.cache)} моделей\n"
                f"Последняя ошибка: {group.diagnostic or 'нет'}\nОчередь: {stats['queue']}\n"
                f"Эпоха данных: {group.epoch}\nПроверка ключа/модели — отдельный платный тест. "
                "Полные технические классы ошибок доступны в логах без содержимого запросов."
            )
            buttons = [("Тест подключения", dest("test_confirm", role="main"))] + back
        elif view == "personal":
            data = await self.db.personal_data(uid)
            text = (
                f"Ваши данные\nОтказ от сохранения: {data['opted_out']}\n"
                f"Сохранено ваших сообщений: {len(data['messages'])}\n"
                f"Предпочтения: {data['preferences']}\n"
                "Удаление также включает отказ от дальнейшего сохранения во всех группах. "
                "Для надёжного удаления производных данных очищается сжатая память и сессии затронутых групп."
            )
            buttons = [
                ("Экспорт моих данных JSON", {"op": "export_personal"}),
                ("Мои кандидаты памяти", {"view": "personal_memories"}),
                ("Удалить данные / отказаться", {"view": "erase_confirm"}),
                ("Снова разрешить сохранение", {"op": "opt_in"}),
            ] + back
        elif view == "personal_memories":
            data = await self.db.personal_data(uid)
            text = "Персональные записи, относящиеся только к вам:\n"
            page = max(0, int(action.get("page", 0)))
            for item in data["memories"][page * 4 : (page + 1) * 4]:
                text += f"\n#{item['id']} [{item['status']}] {item['value']}\n"
                if item["status"] == "pending":
                    buttons.append(
                        (f"Подтвердить #{item['id']}", {"op": "personal_memory", "id": item["id"]})
                    )
            if page:
                buttons.append(("←", {"view": "personal_memories", "page": page - 1}))
            if len(data["memories"]) > (page + 1) * 4:
                buttons.append(("→", {"view": "personal_memories", "page": page + 1}))
            buttons += [("Назад", {"view": "personal"}), ("Главная", {"view": "home"})]
        elif view == "erase_confirm":
            text = (
                "Удалить ваши сообщения, предпочтения и производную память затронутых групп, "
                "затем запретить дальнейшее сохранение? Уже отправленные ответы Telegram и копии сервера останутся вне этой операции."
            )
            buttons = [("Удалить и запретить", {"op": "erase"}), ("Отмена", {"view": "personal"})]
        else:
            raise ValueError("Экран устарел. Откройте /start")
        await self.render(target, uid, text, buttons, edit)

    @staticmethod
    def when(timestamp):
        return (
            time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(timestamp)) if timestamp else "ещё не запускался"
        )

    async def callback(self, callback: CallbackQuery):
        if (
            not callback.message
            or callback.message.chat.type != "private"
            or not (callback.data or "").startswith("j:")
        ):
            await callback.answer("Откройте /start в личке", show_alert=True)
            return
        uid = callback.from_user.id
        action = await self.db.consume_panel(callback.data[2:], uid)
        if not action:
            await callback.answer("Кнопка устарела или уже нажата. Откройте /start.", show_alert=True)
            return
        await callback.answer()
        try:
            if action.get("op"):
                await self.operate(callback.message, uid, action)
            else:
                await self.screen(callback.message, uid, action, edit=True)
        except (PermissionError, ValueError, BudgetError, AIError) as exc:
            if action.get("chat"):
                await self.db.diagnostic(
                    action["chat"], str(exc) if isinstance(exc, AIError) else type(exc).__name__
                )
            await self.render(callback.message, uid, str(exc), [("Главная", {"view": "home"})], edit=True)
        except TelegramForbiddenError:
            await self.render(
                callback.message,
                uid,
                "Нет доступа к группе или личным сообщениям.",
                [("Главная", {"view": "home"})],
                edit=True,
            )

    async def operate(self, target: Message, uid: int, action: dict):
        op, cid = action["op"], action.get("chat")
        if cid is not None:
            await require_admin(self.bot, cid, uid)
            group, values = await self.db.group(cid)
            if not group.active:
                raise ValueError("Бот удалён из группы")
        next_view = "group"
        if op == "apply_model":
            model = await self.ai.model(action["model"], action["role"])
            await self.db.settings(cid, **{action["role"] + "_model": model.id})
            next_view = "models"
        elif op == "favorite":
            await self.db.favorites(uid, action["model"])
            return await self.screen(
                target, uid, {"view": "model", **{k: action[k] for k in ("chat", "role", "model")}}, edit=True
            )
        elif op == "reset":
            defaults = self.config.group_defaults()
            await self.db.settings(
                cid, **{key: defaults[key] for key in ("main_model", "background_model", "embedding_model")}
            )
            next_view = "models"
        elif op == "set":
            key = action["key"]
            if key not in {"humor", "tone", "length", "profanity", "background", "semantic"}:
                raise ValueError("Недопустимая настройка")
            if key == "semantic" and action["value"]:
                await self.ai.model(values["embedding_model"], "embedding")
            await self.db.settings(cid, **{key: action["value"]})
            next_view = action["return"]
        elif op == "archive":
            # Notify first; failure cannot silently enable recording. Values are only stored after successful notice.
            await self.bot.send_message(
                cid,
                NOTICE + f"Срок хранения: {values['retention_days']} дней."
                if action["value"]
                else "Новое архивирование J.A.R.V.I.S. выключено. Сохранённые данные доступны до истечения срока или очистки.",
            )
            await self.db.settings(cid, archive=action["value"])
            next_view = "memory"
        elif op == "clear":
            await self.db.clear(cid)
            next_view = "memory"
        elif op == "memory":
            await self.db.memory_action(cid, action["id"], action["approve"])
            next_view = "browse"
        elif op == "personal_memory":
            await self.db.personal_memory(uid, action["id"])
            next_view = "personal_memories"
        elif op == "run":
            # This runs in a separate aiogram update task; normal group requests are not blocked.
            if not await self.db.rate_allowed(f"manual:{cid}", 30):
                raise ValueError("Анализ уже запускался недавно")
            await self.render(
                target,
                uid,
                "Обрабатываю одну пачку. Параллельные запуски защищены арендой в БД.",
                [("Главная", {"view": "home"})],
                edit=True,
            )
            await self.memory.process(cid, force=True)
            next_view = "background"
        elif op == "retry_queue":
            await self.db.retry_failed(cid)
            self.memory.wakeup.set()
            next_view = "queue"
        elif op == "input":
            await self.db.input_state(uid, action)
            prompts = {
                "model_search": "Введите название или часть ID модели.",
                "memory_search": "Введите текст для поиска в сжатой групповой памяти.",
                "retention_days": "Срок хранения: целое число дней от 1 до 365.",
                "interval_minutes": "Период анализа: число минут от 1 до 1440.",
                "threshold": "Порог: число сообщений от 1 до 200.",
                "daily_budget": "Дневной лимит группы в USD (например 0.50).",
                "monthly_budget": "Месячный лимит группы в USD.",
                "background_budget": "Дневной бюджет фона и эмбеддингов в USD.",
                "timezone": "Введите часовой пояс IANA, например Asia/Yakutsk.",
            }
            return await self.render(
                target,
                uid,
                prompts[action["kind"]] + "\nОтмена: /cancel",
                [("Отмена", {"view": "home"})],
                edit=True,
            )
        elif op == "test":
            if not await self.db.rate_allowed(f"test:{cid}", 30):
                raise ValueError("Подождите 30 секунд между тестами")
            if action["role"] == "embedding":
                vectors = await self.ai.embed(
                    cid, values | {"embedding_model": action["model"]}, ["Проверка подключения"]
                )
                text = f"Подключение работает. Размерность: {len(vectors[0])}. Настройки не изменены."
            else:
                result = await self.ai.generate(
                    cid,
                    values,
                    {},
                    {"question": "Сколько 2+2?", "archive_enabled": False},
                    purpose="test",
                    model_id=action["model"],
                )
                text = "Ответ теста: " + result.answer + "\nНастройки не изменены."
            return await self.render(
                target,
                uid,
                text,
                [("Назад", {"view": "models", "chat": cid}), ("Главная", {"view": "home"})],
                edit=True,
            )
        elif op == "personality":
            if not await self.db.rate_allowed(f"personality:{cid}", 300):
                raise ValueError("Тест уже запускался в последние 5 минут")
            await self.render(
                target,
                uid,
                "Тестирую личность. Каждый пример учитывается в расходах.",
                [("Главная", {"view": "home"})],
                edit=True,
            )
            scenarios = json.loads((Path(__file__).parent / "tests/personality_scenarios.json").read_text())
            report = []
            for scenario in scenarios[: action["count"]]:
                await require_admin(self.bot, cid, uid)
                result = await self.ai.generate(
                    cid,
                    values,
                    {},
                    {"question": scenario["input"], "archive_enabled": False},
                    purpose="test",
                    extraction=False,
                )
                report.append(
                    {
                        **scenario,
                        "answer": result.answer,
                        "boilerplate_found": bool(
                            re.search(
                                r"отличный вопрос|как искусственный интеллект|надеюсь, я помог",
                                result.answer,
                                re.I,
                            )
                        ),
                    }
                )
            await target.answer_document(
                BufferedInputFile(
                    json.dumps(report, ensure_ascii=False, indent=2).encode(), "jarvis_personality_test.json"
                ),
                caption="Примеры ответов выбранной модели; совпадение характера оценивайте по содержанию.",
            )
            next_view = "models"
        elif op == "export_personal":
            data = await self.db.personal_data(uid)
            await target.answer_document(
                BufferedInputFile(
                    json.dumps(data, ensure_ascii=False, indent=2).encode(), "jarvis_my_data.json"
                )
            )
            next_view = "personal"
        elif op == "erase":
            await self.db.erase_user(uid)
            next_view = "personal"
        elif op == "opt_in":
            await self.db.opt_in(uid)
            next_view = "personal"
        else:
            raise ValueError("Действие устарело")
        await self.screen(
            target, uid, {"view": next_view, **({"chat": cid} if cid is not None else {})}, edit=True
        )

    async def private(self, message: Message):
        uid = message.from_user.id
        if (message.text or "").lower() == "/cancel":
            await self.db.input_state(uid, consume=True)
            return await self.screen(message, uid, {"view": "home"})
        state = await self.db.input_state(uid)
        if not state:
            return await self.screen(message, uid, {"view": "home"})
        try:
            cid, kind = state["chat"], state["kind"]
            await require_admin(self.bot, cid, uid)
            value = (message.text or "").strip()
            if kind == "model_search":
                await self.db.input_state(uid, consume=True)
                return await self.screen(
                    message,
                    uid,
                    {"view": "catalog", "chat": cid, "role": state["role"], "query": value[:100]},
                )
            if kind == "memory_search":
                await self.db.input_state(uid, consume=True)
                return await self.screen(message, uid, {"view": "browse", "chat": cid, "query": value[:100]})
            if kind in {"daily_budget", "monthly_budget", "background_budget"}:
                number = Decimal(value.replace(",", "."))
                if not number.is_finite() or not 0 <= number <= 1000:
                    raise ValueError("Введите конечную сумму от 0 до 1000 USD")
                parsed, screen = str(number), "costs"
            elif kind == "timezone":
                ZoneInfo(value)
                parsed, screen = value, "general"
            else:
                ranges = {"retention_days": (1, 365), "interval_minutes": (1, 1440), "threshold": (1, 200)}
                low, high = ranges[kind]
                parsed = int(value)
                if not low <= parsed <= high:
                    raise ValueError(f"Допустимо от {low} до {high}")
                screen = "memory" if kind == "retention_days" else "background"
            await self.db.settings(cid, **{kind: parsed})
            await self.db.input_state(uid, consume=True)
            await self.screen(message, uid, {"view": screen, "chat": cid})
        except (ValueError, InvalidOperation, KeyError, PermissionError, AIError) as exc:
            await message.answer(f"Не удалось применить: {exc}. Попробуйте ещё раз или /cancel.")

    async def store(self, message: Message, invoked=False, requester_id=None, expected_epoch=None):
        if not message.from_user:
            return
        body = message.text or message.caption or ("[Фотография]" if message.photo else "")
        return await self.db.store_message(
            message.chat.id,
            message.message_id,
            message.from_user.id,
            message.date.timestamp(),
            body,
            "photo" if message.photo else "text",
            message.reply_to_message.message_id if message.reply_to_message else None,
            {"username": message.chat.username},
            invoked,
            meaningful(body) and not message.from_user.is_bot,
            requester_id=requester_id,
            expected_epoch=expected_epoch,
        )

    async def group_message(self, message: Message):
        await self.db.ensure_group(message.chat.id, message.chat.title or str(message.chat.id))
        uid = message.from_user.id if message.from_user else 0
        body = message.text or message.caption or ""
        if body.split(" ")[0].split("@")[0] == "/privacy":
            _, settings = await self.db.group(message.chat.id)
            return await message.reply(
                f"Архив: {'включён' if settings['archive'] else 'выключен'}. " + NOTICE
            )
        if not uid or (message.from_user and message.from_user.is_bot):
            return
        invoked = invocation(message, self.bot_id, self.username)
        await self.store(message, invoked)
        if not invoked:
            return
        if not await self.db.rate_allowed(f"ask:{message.chat.id}:{uid}", 5):
            return await message.reply("Сэр, дайте мне несколько секунд на предыдущий запрос.")
        try:
            group, settings = await self.db.group(message.chat.id)
            query = question_text(message, self.username)
            request = preference_request(query)
            if request:
                if await self.db.is_opted_out(uid):
                    return await message.reply(
                        "Вы запретили сохранение данных. Разрешить его можно в личке → Личные данные."
                    )
                await self.db.preferences(message.chat.id, uid, request)
                return await message.reply(
                    "Принято. Буду учитывать это обращение."
                    if "nickname" in request
                    else "Принято. Учту вашу манеру общения."
                )
            reply = message.reply_to_message
            if reply and reply.from_user and not await self.db.is_opted_out(reply.from_user.id):
                await self.store(reply, invoked=True)
            context = await self.memory.context(
                message.chat.id, uid, query, reply.message_id if reply else None, message.message_id, settings
            )
            if await self.db.is_opted_out(uid):
                preferences = {}
            else:
                preferences = await self.db.preferences(message.chat.id, uid)
            image_message = message if message.photo else reply if reply and reply.photo else None
            image_data = None
            if image_message:
                if (
                    image_message != message
                    and image_message.from_user
                    and await self.db.is_opted_out(image_message.from_user.id)
                ):
                    return await message.reply(
                        "Автор запретил обработку своих сохранённых данных. Попросите его прислать изображение для разбора самостоятельно."
                    )
                model = await self.ai.model(settings["main_model"])
                if not model.vision:
                    return await message.reply(
                        "Текущая модель не поддерживает изображения. Администратор может выбрать vision-модель в личке; текстовые вопросы работают."
                    )
                photo = image_message.photo[-1]
                if (photo.file_size or 0) > 8 * 1024 * 1024:
                    return await message.reply("Изображение слишком велико. Пришлите фотографию до 8 МБ.")
                buffer = io.BytesIO()
                try:
                    await self.bot.download(photo, destination=buffer)
                except TelegramAPIError:
                    raise AIError("image_download_failed") from None
                if buffer.tell() > 8 * 1024 * 1024:
                    return await message.reply("Изображение слишком велико. Пришлите фотографию до 8 МБ.")
                image_data = "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode()
            result = await self.ai.generate(
                message.chat.id, settings, preferences, context, image_data=image_data
            )
            fresh_group, _ = await self.db.group(message.chat.id)
            if fresh_group.epoch != context["epoch"]:
                return await message.reply(
                    "Данные группы изменились во время запроса. Повторите обращение, сэр."
                )
            chain_ids = [m["id"] for values in context["sources"].values() for m in values] + [
                message.message_id
            ]
            for chunk in split_text(result.answer):
                sent = await message.answer(
                    chunk,
                    reply_parameters=ReplyParameters(message_id=message.message_id),
                    parse_mode=None,
                    link_preview_options={"is_disabled": True},
                )
                if not await self.db.is_opted_out(uid):
                    await self.store(sent, invoked=True, requester_id=uid, expected_epoch=context["epoch"])
                    await self.db.save_dialogue(
                        message.chat.id,
                        uid,
                        sent.message_id,
                        chain_ids + [sent.message_id],
                        expected_epoch=context["epoch"],
                    )
            sources = [
                m for values in context["sources"].values() for m in values if m["user_id"] != self.bot_id
            ]
            if not await self.db.is_opted_out(uid):
                sources += [
                    {
                        "id": message.message_id,
                        "user_id": uid,
                        "text": query,
                        "date": message.date.isoformat(),
                        "link": "",
                    }
                ]
            candidates = self.memory.validate_candidates(result.memories, sources, settings)
            await self.db.save_memories(
                message.chat.id, await self.memory.deduplicate(message.chat.id, candidates), context["epoch"]
            )
        except BudgetError:
            await self.db.diagnostic(message.chat.id, "budget_exceeded")
            await message.reply(
                "Сэр, установленный лимит расходов не позволяет выполнить этот запрос. Администратор может проверить раздел «Расходы»."
            )
        except AIError as exc:
            await self.db.diagnostic(message.chat.id, str(exc))
            specific = {
                "no_compatible_default_model": "Сэр, в каталоге не нашлось подходящей модели в пределах бюджета. Администратор может выбрать её в моей личной панели.",
                "key_not_configured": "Сэр, сначала задайте OPENROUTER_API_KEY в переменных окружения сервера. Личная панель уже доступна.",
                "model_not_configured": "Сэр, сначала выберите основную модель в моей личной панели.",
                "no_balance": "Сэр, вычислительный центр сообщает об исчерпании баланса. Администратору стоит проверить OpenRouter.",
                "invalid_key": "Ключ вычислительного центра отклонён. Администратору нужно проверить конфигурацию сервера.",
                "context_too_large": "Контекст не помещается в окно модели. Пришлите более короткий фрагмент или выберите другую модель.",
            }
            await message.reply(
                specific.get(
                    exc.code,
                    "Сэр, связь с вычислительным центром временно нарушена. Попробуйте чуть позже. Диагностика доступна администратору.",
                )
            )
        except TelegramForbiddenError:
            await self.db.set_active(message.chat.id, False)

    async def edited(self, message: Message):
        await self.db.edit_message(message.chat.id, message.message_id, message.text or message.caption or "")

    async def membership(self, event: ChatMemberUpdated):
        if event.chat.type not in {"group", "supergroup"}:
            return
        if event.new_chat_member.status in {"left", "kicked"}:
            await self.db.set_active(event.chat.id, False)
        else:
            await self.db.ensure_group(event.chat.id, event.chat.title or str(event.chat.id))


async def run():
    settings = Settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    for logger in ("httpx", "httpcore", "aiohttp", "sqlalchemy.engine"):
        logging.getLogger(logger).setLevel(logging.WARNING)
    if not settings.telegram_bot_token.get_secret_value():
        raise SystemExit("Задайте BOT_TOKEN (либо TELEGRAM_BOT_TOKEN/API_TOKEN) в переменных BotHost.")
    if not settings.openrouter_api_key.get_secret_value():
        log.warning("OPENROUTER_API_KEY не задан: личная панель и /start работают; ИИ-запросы выключены.")
    db, bot = Database(settings), Bot(settings.telegram_bot_token.get_secret_value())
    ai = OpenRouter(settings, db)
    worker = None
    try:
        await db.initialize()
        log.info(
            "JARVIS 2.0.2 GitHub/BotHost: database=%s ready; Python=%s",
            "PostgreSQL" if db.pg else "SQLite/WAL/FTS5",
            sys.version.split()[0],
        )
        me = await bot.get_me()
        # Make the chosen polling mode explicit; retain pending updates after a prior webhook.
        await bot.delete_webhook(drop_pending_updates=False)
        log.info("Telegram verified: @%s; polling mode configured", me.username)
        app = App(settings, db, ai, bot, me.id, me.username)
        dispatcher = Dispatcher()
        dispatcher.update.outer_middleware(Deduplicate(db))
        dispatcher.include_router(app.router)

        @dispatcher.errors()
        async def errors(event):
            # Intentionally do not log exception strings, Telegram payloads or raw HTTP bodies.
            log.error("Update failed: %s", type(event.exception).__name__)
            if isinstance(event.exception, SQLAlchemyError):
                with contextlib.suppress(TelegramAPIError):
                    if event.update.message:
                        await event.update.message.reply(
                            "Сэр, хранилище временно недоступно. Попробуйте чуть позже."
                        )
            return True

        worker = asyncio.create_task(app.memory.worker(), name="jarvis-memory-worker")
        log.info("J.A.R.V.I.S. started")
        await dispatcher.start_polling(
            bot,
            allowed_updates=dispatcher.resolve_used_update_types(),
            tasks_concurrency_limit=32,
            close_bot_session=False,
        )
    finally:
        if worker:
            worker.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await worker
        await ai.close()
        await bot.session.close()
        await db.close()


if __name__ == "__main__":
    try:
        if "--check" not in sys.argv:
            asyncio.run(run())
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as exc:
        # Do not expose tokens or a database URL through an unhandled startup traceback.
        raise SystemExit(
            f"Не удалось запустить J.A.R.V.I.S.: {type(exc).__name__}. Проверьте .env, доступ к БД и API."
        ) from None
