"""Environment defaults; live per-group overrides belong to the selected database."""

from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

from pydantic import AliasChoices, Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

DEFAULT_DATABASE_URL = "sqlite+aiosqlite:///" + str(Path(__file__).resolve().parent / "data" / "jarvis.db")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore", env_ignore_empty=True, populate_by_name=True
    )
    telegram_bot_token: SecretStr = Field(
        default=SecretStr(""), validation_alias=AliasChoices("BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "API_TOKEN")
    )
    openrouter_api_key: SecretStr = SecretStr("")
    bot_owner_id: int = 0
    database_url: str = DEFAULT_DATABASE_URL
    default_main_model: str = ""
    default_background_model: str = ""
    default_embedding_model: str = ""
    default_language: str = "ru"
    default_timezone: str = "UTC"
    background_analysis_enabled: bool = True
    daily_budget_usd: Decimal = Field(Decimal("0.50"), ge=0)
    monthly_budget_usd: Decimal = Field(Decimal("10"), ge=0)
    background_daily_budget_usd: Decimal = Field(Decimal("0.10"), ge=0)
    max_request_usd: Decimal = Field(Decimal("0.05"), gt=0)
    request_timeout: int = Field(60, ge=5, le=120)
    context_tokens: int = Field(6000, ge=512, le=30000)
    queue_max_size: int = Field(2000, ge=10)
    transient_hours: int = Field(2, ge=1, le=24)
    log_level: str = "INFO"

    @classmethod
    def settings_customise_sources(
        cls, settings_cls, init_settings, env_settings, dotenv_settings, file_secret_settings
    ):
        # Normalize aliases separately in each source BEFORE merging. Otherwise an old .env's
        # differently named alias may beat the host's actual environment variable.
        def canonical(source):
            def read():
                data = dict(source())
                names = ("BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "API_TOKEN", "telegram_bot_token")
                selected = next((data[n] for n in names if n in data and str(data[n]).strip()), None)
                for name in names:
                    data.pop(name, None)
                if selected is not None:
                    data["BOT_TOKEN"] = selected
                return data

            return read

        return tuple(
            canonical(source)
            for source in (init_settings, env_settings, dotenv_settings, file_secret_settings)
        )

    @field_validator("telegram_bot_token", "openrouter_api_key", mode="before")
    @classmethod
    def trim_credentials(cls, value):
        value = value.get_secret_value() if isinstance(value, SecretStr) else str(value or "")
        return value.strip()

    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, value):
        value = str(value or "").strip() or DEFAULT_DATABASE_URL
        for prefix in ("postgres://", "postgresql://"):
            if value.startswith(prefix):
                value = "postgresql+asyncpg://" + value[len(prefix) :]
                break
        if value.startswith("sqlite://"):
            value = "sqlite+aiosqlite://" + value[len("sqlite://") :]
        if not value.startswith(("sqlite+aiosqlite://", "postgresql+asyncpg://")):
            raise ValueError("DATABASE_URL: требуется SQLite/aiosqlite или PostgreSQL/asyncpg")
        return value

    @field_validator("default_timezone")
    @classmethod
    def timezone_exists(cls, value: str) -> str:
        ZoneInfo(value)
        return value

    def group_defaults(self) -> dict:
        return {
            "main_model": self.default_main_model,
            "background_model": self.default_background_model,
            "embedding_model": self.default_embedding_model,
            "archive": False,
            "background": self.background_analysis_enabled,
            "semantic": False,
            "retention_days": 90,
            "humor": "classic",
            "profanity": False,
            "tone": "balanced",
            "length": "adaptive",
            "interval_minutes": 30,
            "threshold": 20,
            "daily_budget": str(self.daily_budget_usd),
            "monthly_budget": str(self.monthly_budget_usd),
            "background_budget": str(self.background_daily_budget_usd),
            "timezone": self.default_timezone,
        }
