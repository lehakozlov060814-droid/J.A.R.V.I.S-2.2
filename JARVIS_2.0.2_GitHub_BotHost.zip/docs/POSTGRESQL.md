# Необязательный PostgreSQL / собственный VPS

На BotHost этот путь не нужен: штатный запуск использует SQLite. Этот раздел сохранён для существующих установок PostgreSQL.

## Быстрый запуск на VPS через Compose

Этот раздел — для собственного VPS. На BotHost используйте [BOTHOST.md](../BOTHOST.md).

1. Распакуйте проект на VPS и перейдите в папку `JARVIS`.
2. Установите Docker Engine и Compose plugin, если они ещё не установлены.
3. Создайте конфигурацию:

   ```bash
   cp .env.example .env
   chmod 600 .env
   nano .env
   ```

4. Заполните существующие `BOT_TOKEN`, `OPENROUTER_API_KEY` и добавьте две переменные БД из примера ниже.
   Сгенерировать пароль из безопасных для URL символов:

   ```bash
   openssl rand -hex 24
   ```

   Подставьте **один и тот же результат** в `POSTGRES_PASSWORD` и в пароль
   `DATABASE_URL`. В Compose адрес БД — `db`, не `localhost`; `docker-compose.yml` явно задаёт его контейнеру бота:

   ```dotenv
   POSTGRES_PASSWORD=ваш_случайный_пароль_из_hex
   DATABASE_URL=postgresql+asyncpg://jarvis:ваш_случайный_пароль_из_hex@db:5432/jarvis
   ```

   `DEFAULT_MAIN_MODEL`, `DEFAULT_BACKGROUND_MODEL`, `DEFAULT_EMBEDDING_MODEL`
   можно оставить пустыми: настоящие ID выбираются из каталога в Telegram.
   При пустой основной/фоновой модели действует автовыбор из живого каталога в пределах бюджета.
   Ключи храните на сервере; бот не принимает их через переписку. Без ключа OpenRouter личная панель и `/start` доступны, но ИИ-запросы не выполняются.

5. Запустите:

   ```bash
   docker compose up -d --build
   docker compose logs --tail=100 bot
   ```

6. Добавьте бота в группу. Откройте его личку, отправьте `/start`, выберите группу,
   основную и фоновую модели. При желании включите архив.

Публичный веб-сервер, домен и входящие порты боту не нужны: используется long polling.
PostgreSQL в Compose не публикует порт в интернет. На сервере нужен исходящий доступ к
Telegram, OpenRouter и Docker Registry. Этот проект не содержит VPN или обхода сетевых блокировок.

## Обслуживание

Логи и состояние:

```bash
docker compose ps
docker compose logs -f --tail=100 bot
docker compose logs --tail=100 db
```

В Telegram «Диагностика» показывает последний код ошибки без тела запросов и ключей.
401 обычно означает отклонённый ключ, 402 — баланс, 429 — ограничение частоты.
Если БД недоступна, бот не тратит API на запрос, который не сможет учесть.

Обычный перезапуск:

```bash
docker compose restart bot
```

Данные переживают перезапуск в именованном томе `postgres_data`. Не используйте
`docker compose down -v`, если не хотите удалить базу.

Резервная копия (храните её отдельно от сервера):

```bash
mkdir -p backups
chmod 700 backups
docker compose exec -T db pg_dump -U jarvis -d jarvis -Fc > backups/jarvis.dump
chmod 600 backups/jarvis.dump
```

Восстановление в уже запущенную БД этой же схемы:

```bash
docker compose stop bot
docker compose exec -T db pg_restore -U jarvis -d jarvis --clean --if-exists --no-owner < backups/jarvis.dump
docker compose start bot
```

Сохраните отдельно `.env`: дамп не включает ключи API. После восстановления старого
дампа примените последующие удаления пользователей. Сам проект не выполняет
автоматическую отправку копий или расписание резервирования.

Обновление: сделайте дамп, замените файлы проекта, сохраните свой `.env` и выполните:

```bash
docker compose up -d --build
docker compose logs --tail=100 bot
```

При локальном запуске без Docker установите Python 3.11+ и зависимости. Можно использовать SQLite либо внешний PostgreSQL:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Для SQLite удалите старый `DATABASE_URL` из окружения и `.env`: по умолчанию используется `data/jarvis.db` рядом с кодом; либо задайте свой абсолютный путь. Для PostgreSQL задайте адрес реального сервера в `DATABASE_URL`. Хост `db` существует только в сети Compose. При смене URL выбирается другая база; существующие записи автоматически между разными базами не переносятся.

