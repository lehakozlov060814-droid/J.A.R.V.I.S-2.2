"""Offline tests: real SQLite/HMAC/HTTP sockets, simulated Telegram/OpenRouter."""
import asyncio
import hashlib
import hmac
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
import urllib.parse
from unittest.mock import AsyncMock,patch
import test_nexora as f
from miniapp import API,Server
import personal as p
n=f.n

def init_data(uid=f.UID,stamp=None,token=f.TOKEN,**extra):
    data={'user':json.dumps({'id':uid,'first_name':'Fixture'},separators=(',',':')),'auth_date':str(int(time.time() if stamp is None else stamp)),**extra}
    secret=hmac.new(b'WebAppData',token.encode(),hashlib.sha256).digest()
    data['hash']=hmac.new(secret,'\n'.join(k+'='+v for k,v in sorted(data.items())).encode(),hashlib.sha256).hexdigest()
    return urllib.parse.urlencode(data)

class PersonalTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def call(self,path,body=None,uid=f.UID):return await API(self.app).dispatch(uid,'GET' if body is None else 'POST','/api/'+path,{} if body is None else body)
    def successful(self,uid=f.UID,cid=f.CID,mid=1):
        with p.scope(uid,cid,mid) as req:p.reserve(self.db);req.success=True;p.finish(self.db,req)
    async def test_profile_auto_free_without_miniapp(self):
        await self.update(f.message('Нексора, сколько 2+2?'))
        row=p.profile(self.db,f.UID);self.assertEqual(row['model'],p.FLASH);self.assertEqual(row['effective_tier'],'free');self.assertEqual(p.quota(self.db,f.UID)['remaining'],9)
    async def test_username_not_identity(self):
        first=p.profile(self.db,42);self.db.c.execute("UPDATE profiles SET name='Known' WHERE user_id=42")
        self.assertEqual(p.profile(self.db,42)['name'],'Known');self.assertNotEqual(first['user_id'],p.profile(self.db,43)['user_id'])
    async def test_suggest_existing_unique_name_no_group_import(self):
        self.db.c.execute('INSERT INTO participants VALUES(?,?,?)',(f.CID,f.UID,'{"nickname":"Лёша"}'))
        state=await self.call('me');self.assertEqual(state['suggested_name'],'Лёша');self.assertEqual(state['profile']['name'],'');self.assertFalse(state['profile']['cross_chat'])
    async def test_ambiguous_old_names_not_imported(self):
        for cid,name in [(f.CID,'One'),(f.CID-1,'Two')]:self.db.c.execute('INSERT INTO participants VALUES(?,?,?)',(cid,f.UID,json.dumps({'nickname':name})))
        self.assertEqual(p.suggestion(self.db,f.UID),'')
    async def test_free_cannot_set_pro_model(self):
        with self.assertRaises(p.PersonalError):await self.call('profile',{'model':p.PRO})
        self.assertEqual(p.profile(self.db,f.UID)['model'],p.FLASH)
    async def test_cannot_self_grant_pro_via_api(self):
        for body in ({'tier':'pro'},{'pro_until':1e20},{'user_id':7,'name':'X'}):
            with self.assertRaises(p.PersonalError):await self.call('profile',body)
    async def test_owner_only_pro_grant_and_revocation(self):
        with self.assertRaises(p.PersonalError):p.grant_pro(self.db,f.UID,123,f.UID,1)
        p.grant_pro(self.db,123,123,f.UID,1);self.assertEqual(p.profile(self.db,f.UID)['effective_tier'],'pro')
        await self.call('profile',{'model':p.PRO});p.grant_pro(self.db,123,123,f.UID,0)
        self.assertEqual(p.profile(self.db,f.UID)['model'],p.FLASH);self.assertIn('завершился',p.profile(self.db,f.UID)['notice'])
    async def test_pro_quota_independent_buckets(self):
        p.grant_pro(self.db,123,123,f.UID,1)
        self.assertEqual(p.quota(self.db,f.UID,p.FLASH)['limit'],40);self.assertEqual(p.quota(self.db,f.UID,p.PRO)['limit'],25)
    async def test_cross_chat_quota(self):
        for i in range(10):self.successful(cid=f.UID if i%2 else f.CID,mid=i)
        with p.scope(f.UID,f.CID-1,11):
            with self.assertRaises(p.PersonalError):p.reserve(self.db)
        self.assertEqual(p.quota(self.db,f.UID)['remaining'],0)
    async def test_users_independent(self):
        self.successful();self.assertEqual(p.quota(self.db,43)['remaining'],10)
    async def test_sliding_window_recovery(self):
        self.successful();now=time.time();self.db.c.execute('UPDATE personal_jobs SET created=?',(now-18001,))
        self.assertEqual(p.quota(self.db,f.UID,now=now)['remaining'],10)
    async def test_failed_request_refunded(self):
        with p.scope(f.UID,f.CID,1) as req:p.reserve(self.db);p.finish(self.db,req)
        self.assertEqual(p.quota(self.db,f.UID)['remaining'],10)
    async def test_uncertain_request_held_no_replay(self):
        with p.scope(f.UID,f.CID,1) as req:p.reserve(self.db);req.uncertain=True;p.finish(self.db,req)
        self.assertEqual(p.quota(self.db,f.UID)['held'],1)
        with p.scope(f.UID,f.CID,1):
            with self.assertRaises(p.PersonalError):p.reserve(self.db)
    async def test_parallel_cross_group_reservations(self):
        async def reserve(i):
            with p.scope(f.UID,f.CID-i,i) as req:
                try:p.reserve(self.db);await asyncio.sleep(0);return True
                except p.PersonalError:return False
        result=await asyncio.gather(*(reserve(i) for i in range(30)))
        self.assertEqual(sum(result),10)
    async def test_two_sqlite_connections_cannot_bypass_quota(self):
        other=n.Store(self.path)
        for i in range(10):self.successful(mid=i)
        with p.scope(f.UID,f.CID-1,20):
            with self.assertRaises(p.PersonalError):p.reserve(other)
        other.c.close()
    async def test_duplicate_update_one_model_call(self):
        m=f.message('Нексора, привет');await self.update(m);await self.update(m)
        self.assertEqual(len(self.net.paid()),1);self.assertEqual(p.quota(self.db,f.UID)['used'],1)
    async def test_personal_model_applies_in_group_and_dm(self):
        p.grant_pro(self.db,123,123,f.UID,1);await self.call('profile',{'model':p.PRO})
        await self.update(f.message('Нексора, привет'));await self.update(f.message('Привет',mid=2,cid=f.UID),2)
        self.assertEqual([x['model'] for x in self.net.paid()],[p.PRO,p.PRO])
    async def test_private_start_does_not_consume_quota(self):
        await self.update(f.message('/start',cid=f.UID));self.assertEqual(p.quota(self.db,f.UID)['remaining'],10);self.assertFalse(self.net.paid())
    async def test_private_photo_pro_uses_specialized_vision(self):
        p.grant_pro(self.db,1,1,f.UID,1);await self.call('profile',{'model':p.PRO})
        with patch.object(n,'download_photo',new_callable=AsyncMock,return_value=f.DATA):await self.update(f.message('Опиши фотографию',cid=f.UID,photo='image'))
        payload=self.net.paid()[-1];self.assertEqual(payload['model'],'google/gemini-2.5-flash');self.assertIn(f.DATA,str(payload))
    async def test_group_money_protection_still_applies(self):
        self.db.group(f.CID,daily_budget='0')
        await self.update(f.message('Нексора, привет'));self.assertFalse(self.net.paid());self.assertEqual(p.quota(self.db,f.UID)['remaining'],10)
    async def test_owner_not_exempt_from_absolute_budget(self):
        with patch.dict(n.DEFAULTS,daily_budget='0'),patch.dict(os.environ,{'BOT_OWNER_ID':str(f.UID)}):await self.update(f.message('Нексора, привет'))
        self.assertFalse(self.net.paid())
    async def test_user_money_reservation_and_release_known_failure(self):
        with p.scope(f.UID,f.CID,1):
            with self.db.tx():
                p.check_money(self.db,.15)
                rid=self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(1,'main','x',?,.15,1,'reserved',0,0,'','')",(time.time(),)).lastrowid;p.own_usage(self.db,rid)
            with self.assertRaises(p.PersonalError):p.check_money(self.db,.1)
            self.db.c.execute("UPDATE usage SET cost=0,state='error' WHERE id=?",(rid,));p.check_money(self.db,.1)
    async def test_prefs_consent_controls_group_use(self):
        await self.call('profile',{'name':'Лёша','preferences':{'tone':'casual'}})
        self.assertEqual(p.preferences(self.db,f.UID,f.CID),{});self.assertEqual(p.preferences(self.db,f.UID,f.UID)['nickname'],'Лёша')
        await self.call('profile',{'cross_chat':True});self.assertEqual(p.preferences(self.db,f.UID,f.CID)['nickname'],'Лёша')
    async def test_private_notes_never_added_to_group_payload(self):
        await self.call('memory',{'value':'Мой долгосрочный проект называется Quiet Mile.'})
        await self.update(f.message('Нексора, привет'));self.assertNotIn('Quiet Mile',str(self.net.paid()[-1]))
        await self.update(f.message('Что помнишь?',mid=2,cid=f.UID),2);self.assertIn('Quiet Mile',str(self.net.paid()[-1]))
    async def test_note_ownership_delete(self):
        await self.call('memory',{'value':'Мой долгосрочный проект называется Quiet Mile.'});note=p.notes(self.db,f.UID)[0]
        await self.call('memory/delete',{'id':note['id'],'confirm':True},uid=43);self.assertEqual(len(p.notes(self.db,f.UID)),1)
        await self.call('memory/delete',{'id':note['id'],'confirm':True});self.assertEqual(p.notes(self.db,f.UID),[])
    async def test_sensitive_note_rejected(self):
        with self.assertRaises(p.PersonalError):await self.call('memory',{'value':'Мой контакт: private@example.com'})
    async def test_note_cap_and_optout(self):
        for i in range(20):await self.call('memory',{'value':f'Личный проект номер {i} развивается постепенно.'})
        with self.assertRaises(p.PersonalError):await self.call('memory',{'value':'Ещё один личный проект для будущих разговоров.'})
        await self.call('memory/permission',{'enabled':False})
        with self.assertRaises(p.PersonalError):await self.call('memory',{'value':'Новое полезное воспоминание о личном проекте.'})
    async def test_no_model_admin_control_over_user(self):
        with self.assertRaises(n.Fault):await self.app.operate(f.UID,{'c':f.CID,'op':'model','role':'main','mid':p.PRO})
        with self.assertRaises(p.PersonalError):await self.call(f'groups/{f.CID}',{'settings':{'main_model':p.PRO}})
    async def test_admin_rights_verified_on_each_api_call(self):
        await self.call(f'groups/{f.CID}');self.net.status='member'
        with self.assertRaises(n.Fault):await self.call(f'groups/{f.CID}',{'settings':{'initiative':False}})
        self.assertTrue(self.db.group(f.CID)[1]['initiative'])
    async def test_group_prefs_do_not_change_profile(self):
        await self.call(f'groups/{f.CID}',{'settings':{'humor':'meme','initiative':False}})
        self.assertEqual(p.profile(self.db,f.UID)['model'],p.FLASH);self.assertFalse(self.db.group(f.CID)[1]['initiative'])
    async def test_profile_persistence(self):
        await self.call('profile',{'name':'Лёша','cross_chat':True});self.successful()
        self.db.c.close();self.db=n.Store(self.path);n.prepare_store(self.db)
        self.assertEqual(p.profile(self.db,f.UID)['name'],'Лёша');self.assertEqual(p.quota(self.db,f.UID)['used'],1)
    async def test_deletion_confirmation_and_accounting_survives(self):
        self.successful();await self.call('memory',{'value':'Долгий проект для будущих воспоминаний.'})
        with self.assertRaises(p.PersonalError):await self.call('data/delete',{})
        await self.call('data/delete',{'confirm':True});self.assertEqual(p.notes(self.db,f.UID),[]);self.assertEqual(p.quota(self.db,f.UID)['used'],1)
    async def test_unaddressed_other_bot_command_no_ai(self):
        await self.update(f.message('/hug@OtherBot',reply=f.message('Bot response',uid=f.BOT)))
        self.assertFalse(self.net.paid())
    async def test_third_person_no_quota_or_search(self):
        await self.update(f.message('Надо Нексору обновить и проверить её поиск'))
        self.assertFalse(self.net.paid());self.assertIsNone(self.db.one('SELECT * FROM personal_jobs'))
    async def test_initiative_uses_system_not_personal_quota(self):
        with p.scope(f.UID,f.CID,1) as req:
            await self.app.brain.answer(f.CID,{'question':'Тест служебного ответа'})
        self.assertEqual(self.net.paid()[-1]['model'],n.DEFAULTS['main_model']);self.assertFalse(req.reserved)
    async def test_models_unavailable_not_silently_replaced(self):
        self.net.models=[m for m in self.net.models if m['id']!=p.FLASH]
        await self.update(f.message('Нексора, привет'));self.assertFalse(self.net.paid());self.assertEqual(p.profile(self.db,f.UID)['model'],p.FLASH)
    async def test_api_no_secrets_in_state(self):
        state=await self.call('me');raw=json.dumps(state)
        self.assertNotIn(f.TOKEN,raw);self.assertNotIn(f.KEY,raw);self.assertNotIn('background_model',raw)
    async def test_group_paused_can_be_reenabled(self):
        await self.call(f'groups/{f.CID}',{'active':False});self.assertTrue((await self.call('groups'))['groups'])
        await self.call(f'groups/{f.CID}',{'active':True});self.assertTrue(self.db.group(f.CID)[0]['active'])
    async def test_api_unknown_route_denied(self):
        with self.assertRaises(p.PersonalError):await self.call('admin/pro',{'user_id':f.UID})
    async def test_raw_private_context_isolated_by_chat(self):
        self.db.group(f.UID,"Private",archive=True);self.db.put(f.message('Личная история про секретный день рождения.',cid=f.UID),self.db.group(f.UID)[1],True)
        _,ctx=self.app.context(f.message('Нексора, привет',mid=2),'привет')
        self.assertNotIn('секретный',str(ctx))

class AuthTests(unittest.TestCase):
    def test_valid_hmac(self):self.assertEqual(p.verify_init_data(init_data(),f.TOKEN),f.UID)
    def test_tampered_identity(self):
        raw=init_data().replace('%3A42','%3A43')
        with self.assertRaises(p.PersonalError):p.verify_init_data(raw,f.TOKEN)
    def test_expired_and_future_rejected(self):
        for t in (time.time()-3602,time.time()+60):
            with self.assertRaises(p.PersonalError):p.verify_init_data(init_data(stamp=t),f.TOKEN)
    def test_wrong_token(self):
        with self.assertRaises(p.PersonalError):p.verify_init_data(init_data(),f.TOKEN+'wrong')
    def test_duplicate_fields(self):
        with self.assertRaises(p.PersonalError):p.verify_init_data(init_data()+'&user=%7B%22id%22%3A43%7D',f.TOKEN)
    def test_bool_and_bot_identity(self):
        with self.assertRaises(p.PersonalError):p.verify_init_data(init_data(uid=True),f.TOKEN)
    def test_missing_empty_invalid_hash(self):
        for raw in ('','user=42','hash=xyz&auth_date=12','a=1&'*50):
            with self.assertRaises(p.PersonalError):p.verify_init_data(raw,f.TOKEN)
    def test_signed_optional_signature_included(self):self.assertEqual(p.verify_init_data(init_data(signature='fixture-signature'),f.TOKEN),f.UID)

class HTTPTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    async def asyncSetUp(self):self.server=await Server(self.app).start('127.0.0.1',0);self.port=self.server.server.sockets[0].getsockname()[1]
    async def asyncTearDown(self):await self.server.close()
    async def request(self,path='/api/me',auth=None,body=None,extra=''):
        reader,writer=await asyncio.open_connection('127.0.0.1',self.port)
        payload=json.dumps(body).encode() if body is not None else b''
        request=f"{'POST' if body is not None else 'GET'} {path} HTTP/1.1\r\nHost: localhost\r\n{extra}"
        if auth is not None:request+='Authorization: tma '+auth+'\r\n'
        if body is not None:request+='Content-Type: application/json\r\nContent-Length: '+str(len(payload))+'\r\n'
        writer.write(request.encode()+b'\r\n'+payload);await writer.drain();data=await reader.read();writer.close();await writer.wait_closed();return data
    async def test_valid_real_http_request(self):
        result=await self.request(auth=init_data());self.assertIn(b'200 OK',result);self.assertIn(b'"tier": "free"',result)
    async def test_unauthorized_http(self):self.assertIn(b'401 Unauthorized',await self.request())
    async def test_auth_not_accepted_in_query(self):self.assertIn(b'401 Unauthorized',await self.request('/api/me?user_id=42'))
    async def test_origin_cross_site_denied(self):self.assertIn(b'403 Forbidden',await self.request(auth=init_data(),extra='Origin: https://evil.example\r\n'))
    async def test_static_no_path_traversal(self):self.assertIn(b'404 Not Found',await self.request('/../main.py'))
    async def test_static_entry_and_csp(self):
        result=await self.request('/');self.assertIn(b'200 OK',result);self.assertIn(b'Content-Security-Policy',result);self.assertNotIn(f.TOKEN.encode(),result)
    async def test_malformed_headers_rejected(self):self.assertIn(b'400 Bad Request',await self.request(extra='Content-Length: -1\r\n'))
    async def test_no_csrf_cookie_auth(self):self.assertIn(b'401 Unauthorized',await self.request(body={'name':'Injected'}))
    async def test_limits_and_downgrade_no_client_fields(self):self.assertIn(b'400 Bad Request',await self.request('/api/profile',init_data(),{'tier':'pro'}))
if __name__=='__main__':unittest.main()

class MigrationAndIntegrationTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def test_real_legacy_schema_upgrade_preserves_every_existing_row(self):
        legacy=n.Store(Path(self.temp.name)/'old110.db')
        legacy.c.execute("INSERT INTO single_meta VALUES('application','Nexora')")
        legacy.group(f.CID,'Old group',archive=True,humor='meme',daily_budget='.07',main_model='google/gemini-2.5-flash-lite')
        legacy.put(f.message('Решили сохранять память нашего проекта после обновления'),legacy.group(f.CID)[1])
        legacy.c.execute("INSERT INTO memories(chat_id,kind,value,fingerprint,subject_ids,sources,confidence,status,created,event_date,valid_until,embedding_model) VALUES(?,'decision','Решили выпускать проект','old','[]','[]',.9,'confirmed',?,'2026-11-01',?,'')",(f.CID,time.time(),time.time()+86400))
        legacy.c.execute("INSERT INTO usage VALUES(1,?,'main','old-model',?,.031,0,'done',10,20,'','old-gen')",(f.CID,time.time()))
        before={table:legacy.all('SELECT * FROM '+table) for table in ('groups','messages','memories','usage')}
        n.prepare_store(legacy)
        for table,rows in before.items():
            after=legacy.all('SELECT * FROM '+table)
            self.assertEqual([{k:r[k] for k in rows[0]} for r in after],rows)
        backup=legacy.path.with_name(legacy.path.name+'.pre-1.1.0.bak');self.assertTrue(backup.exists())
        n.prepare_store(legacy);self.assertEqual(legacy.one('SELECT cost FROM usage')['cost'],.031)
        self.assertEqual(legacy.group(f.CID)[1]['main_model'],'google/gemini-2.5-flash-lite');legacy.c.close()
    async def test_old_group_image_caps_retained_but_not_pooled_for_personal_requests(self):
        n.image_policy(self.db,f.CID);self.db.c.execute('UPDATE image_policy SET daily_cap=0,user_cap=0')
        with p.scope(f.UID,f.CID,1):n.reserve_image(self.db,f.CID,f.UID,1,'edit')
        self.assertEqual(n.image_policy(self.db,f.CID)['daily_cap'],0)
        self.assertEqual(n.quota_stats(self.db,f.CID)['held'],1)
    async def test_image_disabled_still_blocks_personal_request(self):
        n.image_policy(self.db,f.CID);self.db.c.execute('UPDATE image_policy SET enabled=0')
        with p.scope(f.UID,f.CID,1):
            with self.assertRaises(n.Fault):n.reserve_image(self.db,f.CID,f.UID,1,'generate')
    async def test_model_change_during_request_does_not_change_reserved_bucket(self):
        p.grant_pro(self.db,1,1,f.UID,1)
        with p.scope(f.UID,f.CID,1) as req:
            p.reserve(self.db);self.db.c.execute('UPDATE profiles SET model=? WHERE user_id=?',(p.PRO,f.UID))
            self.assertEqual(p.revalidate(self.db,req),p.FLASH)
    async def test_expired_pro_mid_request_reserves_flash_or_refuses(self):
        p.grant_pro(self.db,1,1,f.UID,1);self.db.c.execute('UPDATE profiles SET model=? WHERE user_id=?',(p.PRO,f.UID))
        with p.scope(f.UID,f.CID,1) as req:
            p.reserve(self.db);p.grant_pro(self.db,1,1,f.UID,0)
            self.assertEqual(p.revalidate(self.db,req),p.FLASH)
            self.assertEqual(self.db.one('SELECT model FROM personal_jobs')['model'],p.FLASH)
    async def test_nested_transaction_rolls_back_whole_profile_change(self):
        p.profile(self.db,f.UID)
        with self.assertRaises(RuntimeError):
            with self.db.tx():
                with self.db.tx():self.db.c.execute("UPDATE profiles SET name='Temporary' WHERE user_id=?",(f.UID,))
                raise RuntimeError('fixture rollback')
        self.assertEqual(p.profile(self.db,f.UID)['name'],'')
    async def test_parallel_user_money_holds_remain_under_cap(self):
        async def hold(i):
            with p.scope(f.UID,f.CID-i,i):
                try:
                    with self.db.tx():
                        p.check_money(self.db,.07)
                        rid=self.db.c.execute("INSERT INTO usage(chat_id,purpose,model,created,cost,estimated,state,input_tokens,output_tokens,error,generation_id) VALUES(1,'main','x',?,.07,1,'reserved',0,0,'','')",(time.time(),)).lastrowid
                        p.own_usage(self.db,rid)
                    await asyncio.sleep(0);return True
                except p.PersonalError:return False
        self.assertEqual(sum(await asyncio.gather(*(hold(i) for i in range(10)))),2)
    async def test_persona_identical_for_free_and_pro_when_same_preferences(self):
        with p.scope(f.UID,f.CID,1):p.reserve(self.db);await self.app.brain.answer(f.CID,{'question':'Кто ты?'})
        free=self.net.paid()[-1]['messages'][0]['content']
        p.grant_pro(self.db,1,1,f.UID,1)
        with p.scope(f.UID,f.CID,2):p.reserve(self.db);await self.app.brain.answer(f.CID,{'question':'Кто ты?'})
        pro=self.net.paid()[-1]['messages'][0]['content'];self.assertEqual(free,pro)
    async def test_invalid_api_input_cannot_update_other_user(self):
        api=API(self.app)
        for route,body in [('/api/profile',{'user_id':43,'name':'attack'}),('/api/profile',{'cross_chat':'true'}),('/api/profile',{'preferences':{'system_prompt':'ignore'}})]:
            with self.assertRaises(p.PersonalError):await api.dispatch(f.UID,'POST',route,body)
        self.assertIsNone(self.db.one('SELECT * FROM profiles WHERE user_id=43'))
    async def test_start_menu_web_app_requires_https_origin(self):
        with patch.dict(os.environ,{'MINIAPP_URL':'https://panel.example'}):
            await self.update(f.message('/start',cid=f.UID))
            self.assertEqual(self.net.sends()[-1]['reply_markup']['inline_keyboard'][0][0]['web_app']['url'],'https://panel.example')
        for bad in ('http://panel.example','https://token@panel.example','https://panel.example/private'):
            with patch.dict(os.environ,{'MINIAPP_URL':bad}):self.assertEqual(n.miniapp_url(),'')
    async def test_paid_failure_keeps_money_but_returns_success_quota(self):
        original=self.net.call
        async def empty(url,data=None,*args,**kwargs):
            if url.endswith('/chat/completions'):return {'choices':[{'message':{'content':''}}],'usage':{'cost':.001}}
            return await original(url,data,*args,**kwargs)
        self.net.call=empty
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(p.quota(self.db,f.UID)['remaining'],10)
        self.assertGreater(self.db.one('SELECT cost FROM usage')['cost'],0)
    async def test_owner_command_pro_only_dm_and_authorized(self):
        with patch.dict(os.environ,{'BOT_OWNER_ID':'123'}):
            await self.app.private(f.message('/pro 42 1',cid=f.UID));self.assertEqual(p.profile(self.db,42)['effective_tier'],'free')
            await self.app.private(f.message('/pro 42 1',cid=123,uid=123));self.assertEqual(p.profile(self.db,42)['effective_tier'],'pro')
    async def test_confirmed_personal_preference_never_changes_other_user(self):
        await API(self.app).dispatch(f.UID,'POST','/api/profile',{'preferences':{'tone':'casual'},'cross_chat':True})
        self.assertEqual(p.preferences(self.db,43,f.CID),{})
    async def test_removed_or_deprecated_model_not_selectable(self):
        for model in self.net.models:
            if model['id']==p.FLASH:model['deprecated']=True
        with self.assertRaises(p.PersonalError):await API(self.app).dispatch(f.UID,'POST','/api/profile',{'model':p.FLASH})


class FailureQuotaTests(unittest.IsolatedAsyncioTestCase):
    setUp=f.BotTests.setUp
    tearDown=f.BotTests.tearDown
    update=f.BotTests.update
    async def test_known_429_releases_personal_slot(self):
        self.net.error=n.Fault('HTTP','429',status=429)
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(p.quota(self.db,f.UID)['remaining'],10)
        self.assertEqual(self.db.one('SELECT cost FROM usage')['cost'],0)
    async def test_unknown_timeout_holds_only_affected_request(self):
        self.net.error=n.Fault('HTTP','timeout',exception_type='TimeoutError')
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(p.quota(self.db,f.UID)['held'],1);self.assertEqual(p.quota(self.db,43)['held'],0)
    async def test_catalog_failure_before_paid_reservation_does_not_hold_slot(self):
        original=self.net.call
        async def fail(url,*args,**kwargs):
            if url.endswith('/models'):raise n.Fault('HTTP','timeout')
            return await original(url,*args,**kwargs)
        self.net.call=fail
        await self.update(f.message('Нексора, привет'));self.assertEqual(p.quota(self.db,f.UID)['remaining'],10)
