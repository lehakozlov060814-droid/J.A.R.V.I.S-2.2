"""Offline regressions plus real loopback SSE transport (no paid providers)."""
import asyncio
import contextlib
import io
import json
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
import live
import telegram_context as tc
import personal as p
import miniapp
import test_nexora as f
n=f.n

class ParserTests(unittest.TestCase):
    def test_prefix_never_exposes_json_memories_or_reasoning(self):
        s=json.dumps({'memories':[{'value':'private'}],'answer':'Привет!\nДа, «кот» 😺'},ensure_ascii=True)
        previous=''
        for i in range(len(s)+1):
            out=live.answer_prefix(s[:i])
            self.assertTrue('Привет!\nДа, «кот» 😺'.startswith(out),repr(out))
            self.assertTrue(out.startswith(previous))
            previous=out
        self.assertEqual(previous,'Привет!\nДа, «кот» 😺')
        self.assertEqual(live.answer_prefix('not JSON'), '')
        self.assertEqual(live.answer_prefix('{"x":"answer"'), '')
    def test_sse_comments_crlf_multiline(self):
        raw=b': heartbeat\r\nevent: message\r\ndata: {"choices":[],\r\ndata: "usage":{"cost":0.01}}\r\n\r\ndata: [DONE]\r\n\r\n'
        items=list(live.events(io.BytesIO(raw),threading.Event()))
        self.assertEqual(items[0]['usage']['cost'],.01);self.assertEqual(items[-1],'[DONE]')
    def test_sse_malformed_truncated_and_oversize(self):
        for raw in (b'data: nope\n\n', b'data: {}\n\n',b'data: '+b'a'*262145):
            with self.subTest(size=len(raw)),self.assertRaises(ValueError):
                list(live.events(io.BytesIO(raw),threading.Event()))
    def test_reasoning_and_other_choices_not_exposed(self):
        c=live.Completion();c.feed({'choices':[{'index':1,'delta':{'content':'wrong'}},{'index':0,'delta':{'reasoning':'secret','content':'ok'}}]})
        self.assertEqual(c.text,'ok')
        with self.assertRaises(ValueError):c.feed('[DONE]')
        c.feed({'choices':[{'finish_reason':'stop'}]});c.feed('[DONE]')
    def test_truncated_completion_not_persisted_as_success(self):
        with self.assertRaises(ValueError):live.Completion().feed({'choices':[{'finish_reason':'length'}]})
    def test_preview_utf16_limit(self):
        self.assertEqual(len(live.clip('😺'*2000).encode('utf-16-le'))//2,3200)

class RoutingTests(unittest.TestCase):
    def test_clear_local_activation_without_llm(self):
        bot=f.message('old',uid=f.BOT)
        cases=[('Нексора, объясни мем','direct'),('Проверь дату выхода гта 6','direct'),
               ('Ребята, вы это видели?','silent'),('@otherbot помоги','silent'),
               ('Ирис, профиль','silent'),('/ban@IrisBot','silent'),('!убить @player','silent'),
               ('убить @player','silent'),('Не отвечай, это для ребят','silent'),
               ('Надо улучшить Нексору','silent'),('Саша, посмотри сюда','ambiguous'),
               ('Надо обновить @NexoraTestBot','silent'),('Мы обсуждали Нексору','silent'),
               ('Я сегодня закончил работу над проектом','ambiguous'),('Спасибо','silent'),
               ('Нексора, объясни, что значит команда «убить» у Ирис?','direct')]
        for text,want in cases:
            with self.subTest(text=text):self.assertEqual(n.group_address(f.message(text,reply=bot), 'NexoraTestBot',f.BOT),want)
    def test_metadata_mentions_and_forwards(self):
        m=f.message('помоги',reply=f.message('old',uid=f.BOT))
        m['entities']=[{'type':'text_mention','user':{'id':123}}]
        self.assertEqual(n.group_address(m,'NexoraTestBot',f.BOT),'silent')
        m['entities'][0]['user']['id']=f.BOT
        self.assertEqual(n.group_address(m,'NexoraTestBot',f.BOT),'direct')
        m=f.message('Обычная чужая реплика',reply=f.message('old',uid=f.BOT));m['forward_origin']={'type':'hidden_user'}
        self.assertEqual(n.group_address(m,'NexoraTestBot',f.BOT),'silent')
    def test_real_danger_is_not_a_role_command(self):
        self.assertEqual(n.group_address(f.message('Нексора, мне угрожают и собираются меня избить'), 'NexoraTestBot',f.BOT),'direct')

class StreamNetwork(f.Network):
    def __init__(self):
        super().__init__();self.streams=[];self.behavior='success';self.started=asyncio.Event()
    async def stream(self,url,data,key,on_event):
        self.streams.append(data);self.started.set()
        if self.behavior=='reject':raise n.Fault('HTTP','429',status=429)
        content=json.dumps({'answer':'Живой ответ.','memories':[]},ensure_ascii=False)
        for i in range(1,len(content)+1):
            on_event({'id':'gen-local-test','usage':{},'choices':[{'message':{'content':content[:i]}}]})
            await asyncio.sleep(0)
        if self.behavior=='cancel':await asyncio.Event().wait()
        if self.behavior=='broken':raise n.Fault('HTTP','invalid_stream',operation='OpenRouter.chat',status=200)
        return {'id':'gen-local-test','usage':{'cost':.0002,'prompt_tokens':100,'completion_tokens':20},'choices':[{'message':{'content':content}}]}

class ExperienceTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=n.Store(Path(self.tmp.name)/'bot.db');n.prepare_store(self.db)
        self.net=StreamNetwork();self.app=n.Nexora(self.db,self.net,f.TOKEN,f.KEY);self.app.me,self.app.username=f.BOT,'NexoraTestBot';self.db.group(f.CID,'Group')
    def tearDown(self):self.db.c.close();self.tmp.cleanup()
    async def update(self,m,uid=1):await self.app.handle({'update_id':uid,'message':m})
    async def test_stream_used_one_paid_call_and_actual_cost(self):
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.net.streams),1);self.assertFalse(self.net.paid())
        self.assertTrue(self.net.streams[0]['stream']);self.assertEqual(self.net.streams[0]['stream_options'],{'include_usage':True})
        self.assertEqual(self.net.sends()[-1]['text'],'Живой ответ.')
        row=self.db.one("SELECT * FROM usage WHERE purpose='main'");self.assertEqual(row['cost'],.0002);self.assertEqual(row['estimated'],0)
        self.assertEqual(p.quota(self.db,f.UID)['used'],1)
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.net.streams),1)
    async def test_plain_transport_fallback_is_one_call_no_fake_stream(self):
        self.app.http=self.app.brain.http=f.Network()
        await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.app.http.paid()),1);self.assertNotIn('stream',self.app.http.paid()[0])
    async def test_streaming_can_be_disabled_without_replay(self):
        with patch.dict(n.os.environ,{'NEXORA_STREAMING':'0'}):await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.net.paid()),1);self.assertFalse(self.net.streams)
    async def test_broken_stream_does_not_retry_or_send_success(self):
        self.net.behavior='broken';await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.net.streams),1);self.assertNotIn('Живой ответ',self.net.sends()[-1]['text'])
        row=self.db.one("SELECT * FROM usage WHERE purpose='main'");self.assertEqual(row['state'],'error');self.assertGreater(row['cost'],0);self.assertEqual(row['generation_id'],'gen-local-test')
        self.assertEqual(p.quota(self.db,f.UID)['used'],0);self.assertEqual(p.quota(self.db,f.UID)['held'],1)
    async def test_rejected_request_releases_quota_and_budget(self):
        self.net.behavior='reject';await self.update(f.message('Нексора, привет'))
        self.assertEqual(len(self.net.streams),1);self.assertEqual(self.db.one('SELECT cost FROM usage')['cost'],0)
        self.assertEqual(p.quota(self.db,f.UID)['held'],0)
    async def test_native_stop_bypasses_chat_lock_and_keeps_uncertain_charge(self):
        self.net.behavior='cancel';task=asyncio.create_task(self.update(f.message('Привет',cid=f.UID)))
        await self.net.started.wait();await asyncio.sleep(.05)
        await self.app.handle({'update_id':2,'stopped_message_generation':{'chat':{'id':f.UID,'type':'private'},'draft_id':1}})
        await asyncio.wait_for(task,2)
        self.assertIn('Остановила',self.net.sends()[-1]['text']);self.assertEqual(len(self.net.streams),1)
        self.assertEqual(p.quota(self.db,f.UID)['used'],0);self.assertEqual(p.quota(self.db,f.UID)['held'],1)
        self.assertFalse(self.app.live_jobs)
    async def test_other_chat_cannot_stop_request(self):
        self.net.behavior='cancel';task=asyncio.create_task(self.update(f.message('Привет',cid=f.UID)))
        await self.net.started.wait();await asyncio.sleep(.05)
        await self.app.handle({'update_id':2,'stopped_message_generation':{'chat':{'id':43,'type':'private'},'draft_id':1}})
        self.assertFalse(task.done());task.cancel()
        with contextlib.suppress(asyncio.CancelledError):await task
    async def test_clear_silent_replies_no_quota_no_llm(self):
        for i,text in enumerate(['Ребята, идём играть?','!трахнуть @player','@IrisBot помоги','Не отвечай'],1):
            await self.update(f.message(text,mid=i,reply=f.message('old',uid=f.BOT)),i)
        self.assertFalse(self.net.paid());self.assertFalse(self.net.streams);self.assertFalse(self.db.all('SELECT * FROM personal_jobs'))
    async def test_ambiguous_reply_uses_existing_background_gate_with_metadata(self):
        await self.update(f.message('Саша, посмотри сюда',reply=f.message('old',uid=f.BOT)))
        self.assertEqual(len(self.net.paid()),1);self.assertFalse(self.net.streams)
        content=json.loads(self.net.paid()[0]['messages'][1]['content'])
        self.assertEqual(content['telegram']['reply_author_id'],f.BOT)
        self.assertEqual(self.net.paid()[0]['model'],n.DEFAULTS['background_model'])
    async def test_telegram_context_preserves_speakers_and_thread(self):
        _,cfg=self.db.group(f.CID)
        other=f.message('Проект кота',mid=8,uid=43);other['message_thread_id']=20;self.db.put(other,cfg,invoked=True)
        m=f.message('Нексора, расскажи про проект кота',mid=9);m['message_thread_id']=30;self.db.put(m,cfg,invoked=True)
        sources,context=self.app.context(m,m['text']);self.assertEqual([s['message_id'] for s in sources],[9])
        self.assertEqual(context['sources'][0]['speaker'],'participant')
    async def test_private_notes_relevant_bounded_and_never_group(self):
        for value in ('Я делаю проект Quiet Mile на Roblox','Я разрабатываю проект Nexora в Telegram','Предпочитаю рисовать карандашами'):
            self.db.c.execute('INSERT INTO personal_notes(user_id,value,created) VALUES(?,?,?)',(f.UID,value,time.time()))
        selected=p.context_notes(self.db,f.UID,'Помоги с проектом Quiet Mile')
        self.assertEqual(selected[0]['value'],'Я делаю проект Quiet Mile на Roblox')
        self.assertFalse(any('карандаш' in r['value'] for r in selected))
        await self.update(f.message('Нексора, привет'))
        content=json.loads(self.net.streams[-1]['messages'][1]['content']);self.assertNotIn('personal_notes',content)
    async def test_idempotent_personal_memory_save(self):
        api=miniapp.API(self.app)
        await api.dispatch(f.UID,'POST','/api/memory',{'value':'Я делаю проект Quiet Mile'})
        await api.dispatch(f.UID,'POST','/api/memory',{'value':'Я  делаю проект Quiet Mile'})
        self.assertEqual(len(p.notes(self.db,f.UID)),1)
    async def test_preview_throttle_final_edits_existing_message(self):
        progress=live.Progress(self.app,f.message('hello'))
        progress.preview=777
        sent=await progress.finish('Полный ответ')
        self.assertEqual(sent['message_id'],777)
        self.assertTrue(self.net.calls[-1][0].endswith('/editMessageText'))
    async def test_preview_budget_bounds_and_429_is_cosmetic(self):
        progress=live.Progress(self.app,f.message('hello'))
        # Unsupported fake transport is handled as cosmetic failure, never another LLM call.
        for _ in range(30):await progress.cosmetic('sendChatAction',chat_id=f.CID,action='typing')
        self.assertLessEqual(len(self.net.calls),20);self.assertFalse(self.net.streams)
    async def test_private_draft_method_failure_falls_back(self):
        progress=live.Progress(self.app,f.message('hello',cid=f.UID))
        async def unavailable(*a,**kw):raise n.Fault('Telegram','404')
        with patch.object(self.app,'tg',unavailable):await progress.cosmetic('sendMessageDraft',chat_id=f.UID,text='test',draft_id=1)
        self.assertFalse(progress.private)
    async def test_actual_draft_and_group_preview_paths(self):
        class PreviewNetwork(StreamNetwork):
            def __init__(self):super().__init__();self.preview_ready=asyncio.Event()
            async def call(self,url,data=None,key='',timeout=65):
                if url.endswith(('/sendChatAction','/sendMessageDraft','/deleteMessage')):
                    self.calls.append((url,data,key))
                    if url.endswith('/sendMessageDraft'):self.preview_ready.set()
                    return {'ok':True,'result':True}
                result=await super().call(url,data,key,timeout)
                if data.get('disable_notification'):self.preview_ready.set()
                return result
        self.app.http=self.net=PreviewNetwork()
        for cid in (f.UID,f.CID):
            self.net.preview_ready.clear()
            progress=live.Progress(self.app,f.message('Привет',cid=cid))
            progress.start();progress.delta('{"answer":"Настоящий фрагмент')
            await asyncio.wait_for(self.net.preview_ready.wait(),5)
            sent=await progress.finish('Полный ответ')
            await progress.close()
            self.assertTrue(sent['message_id'])
        drafts=[data for url,data,_ in self.net.calls if url.endswith('/sendMessageDraft')]
        self.assertEqual(len(drafts),1);self.assertEqual(drafts[0]['chat_id'],f.UID)
        self.assertTrue(drafts[0]['can_stop']);self.assertEqual(drafts[0]['text'],'Настоящий фрагмент')
        self.assertTrue(any(url.endswith('/editMessageText') and data['text']=='Полный ответ' for url,data,_ in self.net.calls))
    async def test_cosmetic_429_does_not_retry_or_fail_answer(self):
        progress=live.Progress(self.app,f.message('Привет'))
        async def limited(*args,**kw):raise n.Fault('Telegram','429',wait=25,status=429)
        with patch.object(self.app,'tg',side_effect=limited) as call:
            await progress.cosmetic('sendMessageDraft',chat_id=f.UID,text='test',draft_id=1)
            self.assertEqual(call.call_count,1)
        self.assertGreater(progress.next_update,time.monotonic()+20)
        self.assertTrue((await progress.finish('Итог'))['message_id'])
    async def test_final_response_stays_in_forum_topic(self):
        m=f.message('Нексора, привет');m['message_thread_id']=55
        await self.update(m)
        self.assertEqual(self.net.sends()[-1]['message_thread_id'],55)
    async def test_two_users_parallel_quota_separate_money_preserved(self):
        await asyncio.gather(self.update(f.message('Нексора, привет',cid=f.UID),1),self.update(f.message('Нексора, привет',cid=43,uid=43),2))
        self.assertEqual(p.quota(self.db,f.UID)['used'],1);self.assertEqual(p.quota(self.db,43)['used'],1)
        self.assertEqual(len(self.db.all("SELECT * FROM usage WHERE state='done'")),2)
        self.assertEqual(n.BUDGET_BASELINE['daily_budget'],.50)

class MemorySelectionTests(unittest.TestCase):
    def test_filters_candidate_expired_other_subject_dedup_and_size(self):
        rows=[{'value':'Релиз проекта Nexora в пятницу','created':time.time(),'id':1},
              {'value':'Релиз проекта Nexora в пятницу','created':time.time()-10,'id':2},
              {'value':'Nexora секрет другого участника','subject_ids':'[43]'},
              {'value':'Nexora старый факт','valid_until':time.time()-1},
              {'value':'Nexora догадка','status':'pending'},
              {'value':'Nexora '+'x'*3000},
              {'value':'Предпочитает рисовать карандашами'}]
        self.assertEqual([r['id'] for r in tc.select_memories(rows,'Когда релиз Nexora?',42)],[1])
    def test_inflections_and_topic_continuation(self):
        rows=[{'value':'Для проекта Quiet Mile выбрали Roblox'}]
        self.assertTrue(tc.select_memories(rows,'Помоги с проектом Quiet Mile',42))
        self.assertTrue(tc.select_memories(rows,'А дальше?',42,related='Проект Quiet Mile'))
    def test_memory_rejects_jokes_commands_third_party_and_hearsay(self):
        for text in ('!убить @user — решили играть', 'Решили в шутку, это рофл', 'Говорят, решили назначить админа', 'Саша предпочитает сохранять псевдоним', 'Цитата: «решили менять проект»'):
            with self.subTest(text=text):self.assertFalse(n.memory_source_eligible(text))
        self.assertTrue(n.memory_source_eligible('Договорились выпускать проект Nexora каждую пятницу'))
    def test_different_numbers_and_negations_are_not_collapsed(self):
        rows=[{'value':'Квота проекта 5 изображений'},{'value':'Квота проекта 6 изображений'},
              {'value':'Для проекта изображения разрешены'},{'value':'Для проекта изображения не разрешены'}]
        self.assertEqual(len(tc.select_memories(rows,'Какие квоты проекта?',42)),4)

class LoopbackTests(unittest.IsolatedAsyncioTestCase):
    async def exchange(self,handler,fn):
        server=ThreadingHTTPServer(('127.0.0.1',0),handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:return await fn(server,'http://127.0.0.1:'+str(server.server_port))
        finally:
            await asyncio.to_thread(server.shutdown);server.server_close()

    async def test_non_stream_json_fallback_is_not_replayed(self):
        class Handler(BaseHTTPRequestHandler):
            count=0
            def log_message(self,*args):pass
            def do_POST(self):
                type(self).count+=1
                self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers()
                self.wfile.write(b'{"choices":[{"message":{"content":"plain fallback"}}]}')
        async def check(server,url):
            seen=[];data=await n.HTTP().stream(url,{'stream':True},'',seen.append)
            self.assertEqual(data['choices'][0]['message']['content'],'plain fallback')
            self.assertFalse(seen);self.assertEqual(Handler.count,1)
        await self.exchange(Handler,check)

    async def test_429_retry_after_and_strict_attempt_limit(self):
        class Handler(BaseHTTPRequestHandler):
            count=0
            def log_message(self,*args):pass
            def do_POST(self):
                type(self).count+=1
                self.send_response(429);self.send_header('Retry-After','1');self.end_headers()
                self.wfile.write(b'{"error":{"code":429}}')
        async def check(server,url):
            with patch.object(n.asyncio,'sleep',new_callable=f.AsyncMock) as sleep:
                with self.assertRaises(n.Fault) as fault:await n.HTTP().stream(url,{'stream':True},'',lambda data:None)
            self.assertEqual(fault.exception.code,'429');self.assertEqual(Handler.count,3)
            self.assertEqual(sleep.await_count,2)
            self.assertTrue(all(call.args[0]>=1 for call in sleep.await_args_list))
        await self.exchange(Handler,check)

    async def test_long_retry_after_is_not_waited_or_repeated(self):
        class Handler(BaseHTTPRequestHandler):
            count=0
            def log_message(self,*args):pass
            def do_POST(self):
                type(self).count+=1
                self.send_response(429);self.send_header('Retry-After','61');self.end_headers()
                self.wfile.write(b'{}')
        async def check(server,url):
            with self.assertRaises(n.Fault) as fault:await n.HTTP().stream(url,{},'',lambda data:None)
            self.assertEqual(fault.exception.wait,61);self.assertEqual(Handler.count,1)
        await self.exchange(Handler,check)

    async def test_midstream_error_keeps_usage_and_never_replays(self):
        class Handler(BaseHTTPRequestHandler):
            count=0
            def log_message(self,*args):pass
            def do_POST(self):
                type(self).count+=1
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                self.wfile.write(b'data: {"id":"gen-partial","usage":{"cost":0.002},"error":{"code":429}}\n\n')
        async def check(server,url):
            seen=[]
            with self.assertRaises(n.Fault):await n.HTTP().stream(url,{},'',seen.append)
            self.assertEqual(Handler.count,1);self.assertEqual(seen[-1]['usage']['cost'],.002)
        await self.exchange(Handler,check)

    async def test_real_http_sse_transport_and_usage(self):
        first_received=threading.Event()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                request=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                self.server.seen=request
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                for index,item in enumerate([{'id':'gen-loopback','choices':[{'index':0,'delta':{'content':'{"answer":"Hello"'}}]},
                             {'id':'gen-loopback','choices':[{'delta':{'content':',"memories":[]}'},'finish_reason':'stop'}]},
                             {'choices':[],'usage':{'cost':.001,'prompt_tokens':10,'completion_tokens':20}}]):
                    self.wfile.write(('data: '+json.dumps(item)+'\n\n').encode());self.wfile.flush()
                    if index==0:self.server.incremental=first_received.wait(2)
                self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            seen=[]
            def received(data):seen.append(data);first_received.set()
            result=await n.HTTP().stream('http://127.0.0.1:'+str(server.server_port)+'/stream',{'stream':True},'',received)
            self.assertEqual(json.loads(result['choices'][0]['message']['content'])['answer'],'Hello')
            self.assertEqual(result['usage']['cost'],.001);self.assertGreaterEqual(len(seen),3)
            self.assertTrue(server.seen['stream'])
            self.assertTrue(server.incremental,'first fragment must arrive before server finishes')
        finally:
            await asyncio.to_thread(server.shutdown);server.server_close()


class ReleaseTests(unittest.TestCase):
    def test_runtime_is_stdlib_and_python311_syntax(self):
        import ast,sys
        own={'main','personal','miniapp','live','telegram_context'}
        for name in own:
            tree=ast.parse((Path(n.__file__).parent/(name+'.py')).read_text(),feature_version=(3,11))
            modules={node.names[0].name.split('.')[0] for node in ast.walk(tree) if isinstance(node,ast.Import)}|{node.module.split('.')[0] for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)}
            self.assertFalse(modules-sys.stdlib_module_names-own)
    def test_backend_files_are_unchanged_from_sol_release(self):
        # Visual-only pass intentionally updates web assets, never the Sol backend.
        import hashlib
        expected={'main.py': 'b402b8329c475e2a7f502afaaaf73a13ef243b5c1708944d6e431fd5c61c6a1c', 'personal.py': '5020bcaf85dde499e0f44b929aab1edc200a9babc3d2bbcf85431a505232d9b7', 'miniapp.py': '08e12a81e88072283897847af3d9ea2c8da5bfcc6cbb9c00ec33f8a030733fc1', 'live.py': '20b5e4bc2cfc86c266f3c5d080dcce8687b17bef0be81296dc2ddaae1689b2d6', 'telegram_context.py': 'dd2d87bcdba9fcfe833099a78a1b8c78e04c76160f716a33e74d9506a8d9dda3'}
        for name,value in expected.items():self.assertEqual(hashlib.sha256((Path(n.__file__).parent/name).read_bytes()).hexdigest(),value)

if __name__=='__main__':unittest.main()
